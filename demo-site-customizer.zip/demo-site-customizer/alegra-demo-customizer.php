<?php
/*
Plugin Name: WooCommerce Setup Customizer
Description: Customizes WooCommerce settings, creates a demo product, and updates the checkout page content upon plugin activation.
Version: 1.0
Author: Your Name
*/

function woocommerce_setup_customizer() {
    // Disable HPOS (High-Performance Order Storage)
    update_option('woocommerce_hpos_enabled', 'no');

    // Set store location
    update_option('woocommerce_store_address', '123 Demo Street');
    update_option('woocommerce_store_address_2', '');
    update_option('woocommerce_store_city', 'Demo City');
    update_option('woocommerce_store_postcode', '12345');
    update_option('woocommerce_default_country', 'US:CA'); // Country and state code

    // Set currency to USD
    update_option('woocommerce_currency', 'USD');

    // Disable WooCommerce setup wizard
    update_option('woocommerce_admin_disabled', true);

    // Enable Cash on Delivery payment method
    $cod_settings = get_option('woocommerce_cod_settings', array());
    $cod_settings['enabled'] = 'yes';
    update_option('woocommerce_cod_settings', $cod_settings);

    // Create a demo product
    $product_title = 'Demo Product';
    $product_price = '9.99'; // Set your desired price
    $product_description = 'This is a demo product. Lorem ipsum dolor sit amet, consectetur adipiscing elit.'; // Set your desired description

    $post_data = array(
        'post_title'    => $product_title,
        'post_content'  => $product_description,
        'post_status'   => 'publish',
        'post_type'     => 'product'
    );

    $product_id = wp_insert_post($post_data);

    if (!is_wp_error($product_id)) {
        // Add price custom field
        update_post_meta($product_id, '_price', $product_price);
    }

    // Update the checkout page content with the WooCommerce checkout shortcode
    $checkout_page_id = get_option('woocommerce_checkout_page_id');

    if ($checkout_page_id) {
        $checkout_content = '[woocommerce_checkout]';
        wp_update_post(array(
            'ID'           => $checkout_page_id,
            'post_content' => $checkout_content
        ));
    }
}

// Hook into the 'activate_' action to run the customizer function on plugin activation
register_activation_hook(__FILE__, 'woocommerce_setup_customizer');
