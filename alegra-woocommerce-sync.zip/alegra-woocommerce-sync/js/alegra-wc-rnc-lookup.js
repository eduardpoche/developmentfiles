jQuery(document).ready(function ($) {

    $('#wc_alegra_order_document_id').on('blur', function () {
        var input = $(this);
        var rncValue = this.value.trim();

        if (rncValue && alegraWcParams.performCheck) {
            // Proceed with AJAX call
            console.log('Consulting DGII is available...')
            input.prop('disabled', true);  // Disable the input
            input.after('<span id="rnc-loading-text">Consultando a DGII...</span>');

            $.ajax({
                url: alegraWcParams.ajaxurl,
                type: 'POST',
                data: {
                    'action': 'alegra_rnc_lookup',
                    'rnc': rncValue
                },
                success: function (response) {
                    console.log('DATA => ' + JSON.stringify(response));
                    if (response.success && response.data[0].RNC) {
                        $('#wc_alegra_order_razon_social').val(response.data[0].RazonSocial);
                        $('#wc_alegra_order_nombre_comercial').val(response.data[0].NombreComercial);
                        $('#wc_alegra_order_razon_social_field').show(); // Show only the Razón Social field)
                        $('#wc_alegra_order_nombre_comercial_field').show(); // Show only the Razón Social field)
                    } else {
                        $('#wc_alegra_order_razon_social').show(); // Show only the Razón Social field
                        $('#wc_alegra_order_nombre_comercial').hide(); // Hide Nombre Comercial field
                        alert('Error: ' + response.data.message);
                    }
                },
                error: function () {
                    alert('Error during RNC verification.');
                },
                complete: function () {
                    input.prop('disabled', false); // Re-enable the input
                    $('#rnc-loading-text').remove(); // Remove the loading text
                }
            });
        }
    });


    $('#wc_alegra_order_document_id').on('keypress', function (event) {
        if (event.which === 13) {  // Check if the Enter key was pressed
            event.preventDefault();  // Prevent the form from being submitted
            $(this).blur();  // Trigger the blur event to run the RNC verification
        }
    });


});