jQuery(document).ready(function ($) {

    if ($('#included_categories_for_alegra').length) {
        $('#included_categories_for_alegra').selectWoo();
    }



    $('#alegra_wc_force_sync_button, #alegra_wc_sync_button').on('click', function () {
        var button = $(this);

        // Block the button with a loading message
        button.block({
            message: null,
            overlayCSS: { backgroundColor: '#fff', opacity: 0.6 },
        });

        // Get product-specific data attributes from the button
        var post_id = button.data('post-id');
        var object_type = button.data('object-type');
        var sync_type = button.data('sync-type');
        var force_sync = button.data('force-sync');

        // Perform an AJAX request to trigger the sync task
        $.ajax({
            url: ajaxurl, // WordPress AJAX endpoint
            type: 'POST',
            data: {
                action: 'alegra_wc_sync_to_alegra', // AJAX action name
                post_id: post_id, // Pass the product ID to the AJAX callback
                object_type: object_type,
                sync_type: sync_type,
                force_sync: force_sync
            },
            success: function (response) {
                console.log(JSON.stringify(response));
                if (response.success) {
                    alert(response.data); // You can replace this with a more user-friendly message
                } else {
                    alert(response.data); // Handle the error case
                }
            },
            error: function (response) {
                alert('Ajax Call Sync to Alegra Failed' + JSON.stringify(response))
            },
            complete: function () {
                // Unblock the button after the request is complete
                button.unblock();
            }
        });
    });

    $('#alegra_wc_invoice_button').on('click', function () {
        var button = $(this);

        // Block the button with a loading message
        button.block({
            message: null,
            overlayCSS: { backgroundColor: '#fff', opacity: 0.6 },
        });

        // Get product-specific data attributes from the button
        var post_id = button.data('post-id');
        var alegra_invoice_id = button.data('invoice-id');
        var object_type = button.data('object-type');

        // Perform an AJAX request to trigger the sync task
        $.ajax({
            url: ajaxurl, // WordPress AJAX endpoint
            type: 'POST',
            data: {
                action: 'alegra_wc_get_alegra_invoice_pdf', // AJAX action name
                post_id: post_id, // Pass the product ID to the AJAX callback
                invoice_id: alegra_invoice_id, // Pass the product ID to the AJAX callback
                object_type: object_type
            },
            success: function (response) {
                if (response.success) {
                    console.log(JSON.stringify(response)); // You can replace this with a more user-friendly message
                    window.open(response.data, '_blank');
                } else {
                    console.log(JSON.stringify(response));
                    alert(response.data);
                }
            },
            error: function (response) {
                alert('Ajax Call Sync to Alegra Failed' + JSON.stringify(response))
            },
            complete: function () {
                // Unblock the button after the request is complete
                button.unblock();
            }
        });
    });

    $('#variable_product_options').on('click', '.alegra-inventory-adjustment-btn', function (e) {
        e.preventDefault();

        var button = $(this);

        // Block the button with a loading message
        button.block({
            message: null,
            overlayCSS: { backgroundColor: '#fff', opacity: 0.6 },
        });

        var variationID = $(this).data('variation-id');
        var userID = $(this).data('user-id');

        // Make an AJAX call to trigger inventory adjustment
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'alegra_wc_inventory_adjustment', // AJAX action name
                variation_id: variationID,
                user_id: userID
            },
            success: function (response) {
                // Handle success message
                console.log(response);
            },
            error: function (error) {
                // Handle error message
                console.error('Inventory adjustment failed:', error);
            },
            complete: function () {
                // Unblock the button after the request is complete
                button.unblock();
            }
        });
    });

    $('#alegra_open_modal_button').on('click', function () {

        var button = $(this);


        button.block({
            message: null,
            overlayCSS: { backgroundColor: '#fff', opacity: 0.6 },
        });

        tb_show('Enter Alegra Order Data', '#TB_inline?width=480&height=400&inlineId=alegra_modal&modal=true');


    });

    // Handle the Close button click
    $('#alegra_modal_close_button').on('click', function () {
        // Close the modal
        var button = $('#alegra_open_modal_button');

        button.unblock();
        tb_remove();
    });

    // Handle the Save button click
    $('#alegra_modal_save_button').on('click', function () {


        var save_button = $(this);

        var modal = $('#TB_ajaxContent');

        modal.block({
            message: "cargando...",
            overlayCSS: { backgroundColor: '#fff', opacity: 0.6 },
        });

        // Get the values from the modal
        var order_document_type = $('#alegra_modal_document_type').val();
        var order_document_id = $('#alegra_modal_order_document_id').val();
        var order_type = $('#alegra_modal_order_type').val();
        var comprobante_fiscal = $('#comprobante_fiscal').val();
        var order_id = save_button.data('order-id');
       


        // Close the modal
        //tb_remove();

        // Perform an AJAX request to save the data
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'save_wc_order_as_fiscal',
                alegra_order_document_type: order_document_type,
                alegra_order_document_id: order_document_id,
                alegra_order_type: order_type,
                comprobante_fiscal: comprobante_fiscal,
                order_id: order_id
            },
            success: function (response) {
                // Handle the AJAX response
                //P1 Show a Success Message in the modal
                console.log(JSON.stringify(response));
                alert(response.data);
                // You can perform additional actions based on the response
            },
            complete: function () {
                // Unblock the modal after the request is complete
                modal.unblock();
            }
        });
    });

    $('#alegra_inventory_adjustment_trigger').on('click', function () {
        var button = $(this);

        // Block the button with a loading message
        button.block({
            message: null,
            overlayCSS: { backgroundColor: '#fff', opacity: 0.6 },
        });


        // Perform an AJAX request to trigger the sync task
        $.ajax({
            url: ajaxurl, // WordPress AJAX endpoint
            type: 'POST',
            data: {
                action: 'alegra_wc_check_for_inventory_adjustments', // AJAX action name
            },
            success: function (response) {
                console.log(JSON.stringify(response));
                if (response.success) {
                    alert(response.data); // You can replace this with a more user-friendly message
                } else {
                    alert(response.data); // Handle the error case
                }
            },
            error: function (response) {
                alert('Ajax Call Sync to Alegra Failed' + JSON.stringify(response))
            },
            complete: function () {
                // Unblock the button after the request is complete
                button.unblock();
            }
        });
    });



});

