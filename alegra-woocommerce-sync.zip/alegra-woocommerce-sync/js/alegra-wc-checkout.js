jQuery(document).ready(function ($) {
    var $form = $('form.checkout');

    $form.on('submit', function () {
        console.log('submitting form...');
    });

    jQuery('input#comprobante_fiscal').change(function () {

        var invoiceFields = $('.alegra_fields');
        console.log('clicked');
        if (this.checked) {
            invoiceFields.show();
        } else {
            invoiceFields.hide();
        }

        jQuery('body').trigger('update_checkout');
    });

});


