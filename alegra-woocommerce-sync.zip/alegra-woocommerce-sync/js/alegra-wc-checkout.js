jQuery(document).ready(function ($) {
    var $form = $('form.checkout');

    $form.on('submit', function () {
        console.log('submitting form...');
    });

    jQuery('input#comprobante_fiscal').change(function () {

        var invoiceFields = $('.alegra_fields');
        console.log('clicked');
        if (this.checked) {
            invoiceFields.show();
        } else {
            invoiceFields.hide();
        }

        jQuery('body').trigger('update_checkout');
    });

    function validateDocumentID() {
        var documentType = $('#alegra_order_document_type').val();
        var documentID = $('#alegra_order_document_id').val();
        var error = '';
        var isValid = true;

        if (documentType === 'RNC') {
            if (!/^\d{9}$/.test(documentID)) {
                error = 'El RNC debe ser de exactamente 9 dígitos.';
                isValid = false;
            }
        } else if (documentType === 'CED') {
            if (!/^\d{11}$/.test(documentID)) {
                error = 'La Cédula debe ser de exactamente 11 digitos, sin guiones.';
                isValid = false;
            }
        } else if (documentType === 'IE') {
            if (!/^[a-zA-Z0-9]{1,25}$/.test(documentID)) {
                error = 'El pasaporte sólo puede contener hasta 25 caracteres.';
                isValid = false;
            }
        }

        if (!isValid) {
            $('#alegra_order_document_id').css('border-color', 'red');
            if ($('#alegra_order_document_id_error').length === 0) {
                $('#alegra_order_document_id').after('<p id="alegra_order_document_id_error" style="color: red;">' + error + '</p>');
            } else {
                $('#alegra_order_document_id_error').text(error);
            }
        } else {
            $('#alegra_order_document_id').css('border-color', '');
            $('#alegra_order_document_id_error').remove();
        }

        return isValid;
    }

    $('#alegra_order_document_id').on('input', function() {
        validateDocumentID();
    });

    $('#alegra_order_document_type').on('change', function() {
        validateDocumentID();
    });

    $('form.checkout').on('submit', function(e) {
        if (!validateDocumentID()) {
            e.preventDefault();
            $('html, body').animate({
                scrollTop: $('#alegra_order_document_id').offset().top - 20
            }, 500);
        }
    });

});


