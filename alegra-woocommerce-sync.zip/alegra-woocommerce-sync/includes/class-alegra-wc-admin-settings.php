<?php

use Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController;

class Alegra_WC_Admin_Settings

{



    public function __construct()
    {

        add_action('admin_enqueue_scripts', array($this, 'alegra_wc_enqueue_scripts'));

        //Showing admin settings
        add_filter('woocommerce_product_data_tabs', array($this, 'alegra_wc_add_custom_product_data_tab'));
        add_action('woocommerce_product_data_panels', array($this, 'alegra_wc_display_custom_product_data_tab_content'));
        add_action('add_meta_boxes', array($this, 'alegra_wc_add_metaboxes'));
        add_action('woocommerce_variation_options_pricing', array($this, 'alegra_wc_display_variation_unit_cost'), 10, 3);

        //AJAX Calls
        add_action('wp_ajax_alegra_wc_sync_to_alegra', array($this, 'wc_sync_to_alegra_ajax'));
        add_action('wp_ajax_nopriv_alegra_wc_sync_to_alegra', array($this, 'wc_sync_to_alegra_ajax'));
        add_action('wp_ajax_alegra_wc_get_alegra_invoice_pdf', array($this, 'alegra_wc_get_alegra_invoice_pdf'));
        add_action('wp_ajax_nopriv_alegra_wc_get_alegra_invoice_pdf', array($this, 'alegra_wc_get_alegra_invoice_pdf'));
        add_action('wp_ajax_save_wc_order_as_fiscal', array($this, 'save_wc_order_as_fiscal'));
        add_action('wp_ajax_nopriv_save_wc_order_as_fiscal', array($this, 'save_wc_order_as_fiscal'));
        add_action('wp_ajax_alegra_to_wc_inventory_sync', array($this, 'alegra_to_wc_inventory_sync_ajax'));
        add_action('wp_ajax_nopriv_alegra_to_wc_inventory_sync', array($this, 'alegra_to_wc_inventory_sync_ajax'));

        //User Profile Fields
        add_action('show_user_profile', array($this, 'alegra_wc_user_custom_fields_markup'));
        add_action('edit_user_profile', array($this, 'alegra_wc_user_custom_fields_markup'));
        add_action('personal_options_update', array($this, 'alegra_wc_save_user_custom_fields'));
        add_action('edit_user_profile_update', array($this, 'alegra_wc_save_user_custom_fields'));

        //Bulk Actions
        add_filter('woocommerce_debug_tools', array($this, 'alegra_wc_tools'));
        add_action('woocommerce_system_status_tool_executed', array($this, 'alegra_tools_post_execution'));

        //Hooks for actions upon save
        add_action('update_option_alegra_inventory_sync_delay', [$this, 'alegra_wc_update_inventory_delay'], 10, 3);
        add_action('update_option_alegra_wc_user', [$this, 'alegra_wc_credentials_updated'], 10, 3);
        add_action('update_option_alegra_wc_token', [$this, 'alegra_wc_credentials_updated'], 10, 3);
        add_action('woocommerce_update_options_alegra_settings', [$this, 'handle_post_saving_alegra_settings']);
        add_action('woocommerce_save_product_variation', array($this, 'alegra_wc_save_variation_changes'), 10, 2);
        add_action('woocommerce_process_product_meta', array($this, 'alegra_wc_save_product_unit_cost'));
        add_action('woocommerce_process_shop_order_meta', array($this, 'alegra_wc_save_settings_order_data'));

        // Add content to Emails
        add_action('woocommerce_email_after_order_table', [$this, 'add_fiscal_order_details_to_admin_email'], 20, 4);
    }

    function alegra_wc_enqueue_scripts()
    {
        add_thickbox();

        wp_enqueue_script('alegra-wc-sync', plugin_dir_url(__DIR__) . 'js/alegra-wc-sync.js', array('jquery'), '1.1', true);

        wp_enqueue_style('alegra-wc-sync', plugin_dir_url(__DIR__) . 'css/alegra-wc-sync-admin.css', array(), '1.0', 'all');
    }


    function alegra_to_wc_inventory_sync_ajax()
    {

        $alegra_sync = new Alegra_WC_Sync();

        $response = $alegra_sync->alegra_to_wc_inventory_sync();

        wp_send_json($response);
    }

    function alegra_wc_update_inventory_delay($old_value, $value, $option)
    {

        //The inventory delay changed, update accordingly
        as_unschedule_all_actions('alegra_to_wc_inventory_sync');

        as_schedule_recurring_action(date('U'), $value * HOUR_IN_SECONDS, 'alegra_to_wc_inventory_sync');
    }

    function wc_sync_to_alegra_ajax()
    {

        $object_type = $_POST['object_type'];
        $object_id = intval($_POST['post_id']);
        $sync_type = $_POST['sync_type'];
        $force_sync = (isset($_POST['force_sync']) ? $_POST['force_sync'] : false);

        if (empty($object_type) || empty($object_id)) {
            wp_send_json_error(__('No es posible determinar el objeto (producto, orden, contacto) a sincronizar.', 'alegra-wc-sync'));
        }

        $alegra_sync = new Alegra_WC_Sync();

        //Based on the object-type (order, product, etc), call the correct method.

        switch ($object_type) {
            case 'Product':
                $response = $alegra_sync->alegra_wc_create_wc_product($object_id, false, $sync_type, $force_sync);
                break;
            case 'Order':
                $response = $alegra_sync->alegra_wc_create_invoice($object_id, $sync_type, $force_sync = false);
                break;
            case 'Contact':
                $response = $alegra_sync->alegra_wc_create_contact($object_id, array());
                break;
        }

        if (($response['success'])) {
            wp_send_json_success($response['message']);
        } else {
            wp_send_json_error($response['message']);
        }
    }

    function alegra_wc_get_alegra_invoice_pdf()
    {

        $object_type = $_POST['object_type'];
        $object_id = intval($_POST['post_id']);
        $invoice_id = intval($_POST['invoice_id']);

        if (empty($object_type) || empty($object_id) || empty($invoice_id)) {
            wp_send_json_error(
                array('data' => array('message' => __('Hubo un error intentando obtener el PDF.', 'alegra-wc-sync')))
            );
        }

        $return = array();

        $endpoint = "invoices/" . $invoice_id . "?fields=pdf";

        $response = Alegra_WC_API::alegra_wc_api_request('GET', $endpoint);

        if (in_array($response['code'], array(200, 201)) && isset($response['data']['id'])) {

            //Response was successful, check for its content
            $response = $response['data'];

            if ($response['status'] == 'draft') {
                /* translators: %s is the Invoice ID */
                $message = sprintf(__("La factura %s está en borrador en Alegra. Las Facturas en borrador no tienen PDF disponible.", 'alegra-wc-sync'), $invoice_id);
                Alegra_WC_Logs::log(__METHOD__, $message, 'warning');
                $return['success'] = false;
                $return['data'] = $message;
            } else {
                $return['success'] = true;
                $pdf_link = $response['pdf'];
                $return['data'] = $pdf_link;
            }
        } else {
            Alegra_WC_Logs::log(__METHOD__, 'Error: ' . print_r($response, true), 'error');
            $return['success'] = false;
            $return['data'] = $response['data']['message'];
        }

        if (($return['success'])) {
            wp_send_json_success($return['data']);
        } else {
            wp_send_json_error($return['data']);
        }
    }

    // Add custom tab
    public function alegra_wc_add_custom_product_data_tab($tabs)
    {
        $tabs['alegra_wc_sync'] = array(
            'label'    => _x('Alegra WooCommerce Sync', 'Product Data Tab', 'alegra-wc-sync'),
            'target'   => 'alegra_wc_sync_options',
            'class'    => array('show_if_simple', 'show_if_variable'),
        );
        return $tabs;
    }

    // Display custom tab content
    public function alegra_wc_display_custom_product_data_tab_content()
    {
        global $post;

        $post_id = $post->ID;

        // Start the "options_group" div with the target class
        echo '<div id="alegra_wc_sync_options" class="panel woocommerce_options_panel hidden">';

        // Get the Alegra Sync Status value
        $alegra_sync_status = get_post_meta($post_id, 'wc_alegra_sync_status', true);

        // Get the Alegra Last Synced value
        $alegra_last_synced = get_post_meta($post_id, 'wc_alegra_last_synced', true);

        // Get the Alegra Product ID value
        $alegra_product_id = get_post_meta($post_id, 'wc_alegra_product_id', true);

        // Get the Alegra Product ID value
        $alegra_unit_cost = get_post_meta($post_id, 'wc_alegra_unit_cost', true);

        // Get the Alegra Product Unit value
        $alegra_product_unit = get_post_meta($post_id, 'wc_alegra_product_unit', true);

        // Get the Alegra Product category value
        $alegra_product_category = get_post_meta($post_id, 'wc_alegra_product_category', true);

        // Display Alegra Sync Status as an option
        woocommerce_wp_text_input(
            array(
                'id'          => 'wc_alegra_sync_status',
                'label'       => __('Estado de la Sincronización', 'alegra-wc-sync'),
                'desc_tip'    => 'true',
                'description' => __('Enter the Alegra sync status for this product.', 'alegra-wc-sync'),
                'custom_attributes' => ['disabled' => true, 'readonly' => true]
            )
        );

        // Display Alegra Last Synced as an option
        woocommerce_wp_text_input(
            array(
                'id'          => 'wc_alegra_last_synced',
                'label'       => __('Ultima Sincronización en Alegra', 'alegra-wc-sync'),
                'desc_tip'    => 'true',
                'description' => __('Fecha de la última sincronización en Alegra', 'alegra-wc-sync'),
                'custom_attributes' => ['disabled' => true, 'readonly' => true]
            )
        );


        // Display Alegra Product ID as an option if not a variable product

        $product = wc_get_product($post_id);

        if ($product->is_type('simple')) {

            woocommerce_wp_text_input(
                array(
                    'id'          => 'wc_alegra_product_id',
                    'label'       => __('ID de Producto en Alegra', 'alegra-wc-sync'),
                    'desc_tip'    => 'true',
                    'description' => __('El ID de producto en Alegra de este producto', 'alegra-wc-sync'),
                    'custom_attributes' => ['disabled' => true, 'readonly' => true]
                )
            );
        }

        //Display Alegra unit cost
        woocommerce_wp_text_input(
            array(
                'id' => 'wc_alegra_unit_cost',
                'label' => __('Costo Unitario del Producto', 'alegra-wc-sync'),
                'type' => 'number',
                'desc_tip' => 'true',
                'description' => __('Introduzca el costo unitario de este producto', 'alegra-wc-sync'),
                'custom_attributes' => array(
                    'step'     => 'any',
                    'min'    => '1'
                ),
                'data_type' => 'price'
            )
        );

        woocommerce_wp_select(
            array(
                'id' => 'wc_alegra_product_unit',
                'label' => __('Unidad de medida del producto', 'alegra-wc-sync'),
                'class' => 'wc-enhanced-select long',
                'style' => 'width: 50%',
                'value' => (empty($alegra_product_unit) ? 'LB' : $alegra_product_unit),
                'options' => array(
                    'BARR'  => 'Barril',
                    'BOL'  => 'Bolsa',
                    'BOT'  => 'Bote',
                    'BULTO'  => 'Bultos',
                    'BOTELLA'  => 'Botella',
                    'CAJ'  => 'Caja/Cajón',
                    'CAJETILLA'  => 'Cajetilla',
                    'CM'  => 'Centímetro',
                    'CIL'  => 'Cilindro',
                    'CONJ'  => 'Conjunto',
                    'CONT'  => 'Contenedor',
                    'DÍA'  => 'Día',
                    'DOC'  => 'Docena',
                    'FARD'  => 'Fardo',
                    'GL'  => 'Galones',
                    'GRAD'  => 'Grado',
                    'GR'  => 'Gramo',
                    'GRAN'  => 'Granel',
                    'HOR'  => 'Hora',
                    'HUAC'  => 'Huacal',
                    'KG'  => 'Kilogramo',
                    'kWh'  => 'Kilovatio Hora',
                    'LB'  => 'Libra',
                    'LITRO'  => 'Litro',
                    'LOT'  => 'Lote',
                    'M'  => 'Metro',
                    'M2'  => 'Metro Cuadrado',
                    'M3'  => 'Metro Cúbico',
                    'MMBTU'  => 'Millones de Unidades Térmicas',
                    'MIN'  => 'Minuto',
                    'PAQ'  => 'Paquete',
                    'PAR'  => 'Par',
                    'PIE'  => 'Pie',
                    'PZA'  => 'Pieza',
                    'ROL'  => 'Rollo',
                    'SOBR'  => 'Sobre',
                    'SEG'  => 'Segundo',
                    'TANQUE'  => 'Tanquear',
                    'TONE'  => 'Tonelada',
                    'TUB'  => 'Tubo',
                    'YD'  => 'Yarda',
                    'YD2'  => 'Yarda cuadrada',
                    'UND'  => 'Unidad',
                    'UND'  => 'Unidad',
                    'EA'  => 'Elemento',
                    'MILLAR'  => 'Millar',
                    'SAC'  => 'Saco',
                    'LAT'  => 'Lata',
                    'DIS'  => 'Display',
                    'BID'  => 'Bidón',
                    'RAC'  => 'Ración'
                ),
                'desc_tip' => true,
                'description' => __('Introduzca la unidad de medida de este producto.', 'alegra-wc-sync')
            )
        );

        $alegra_categories =  Alegra_WC_Sync::alegra_wc_get_alegra_categories();

        woocommerce_wp_select(
            array(
                'id' => 'wc_alegra_product_category',
                'label' => 'Categoría de Producto en Alegra',
                'class' => 'wc-enhanced-select long',
                'style' => 'width: 50%',
                'value' => (empty($alegra_product_category) ? '' : $alegra_product_category),
                'options' => $alegra_categories,
                'desc_tip' => true,
                'description' => __('Seleccione una categoría de Producto en Alegra', 'alegra-wc-sync')
            )
        );
        // Close the "options_group" div
        echo '</div>';
    }


    public function alegra_wc_display_variation_unit_cost($loop, $variation_data, $variation)
    {

        // Get the Alegra Product ID value
        $alegra_unit_cost = get_post_meta($variation->ID, 'wc_alegra_unit_cost', true);

        woocommerce_wp_text_input(
            array(
                'id' => "wc_alegra_unit_cost[" . $loop . "]",
                'type' => 'number',
                'wrapper_class' => 'form-row',
                'label' => __('Costo Unitario en Alegra', 'alegra-wc-sync'),
                'desc_tip' => 'true',
                'description' => __('Introduzca el costo unitario de este producto en Alegra', 'alegra-wc-sync'),
                'value' => $alegra_unit_cost
            )
        );
    }

    public function alegra_wc_save_variation_changes($variation_id, $i)
    {

        $alegra_unit_cost = isset($_POST['wc_alegra_unit_cost'][$i]) ? $_POST['wc_alegra_unit_cost'][$i] : 1;

        update_post_meta($variation_id, 'wc_alegra_unit_cost', $alegra_unit_cost);

        Alegra_WC_Logs::log(__METHOD__, "Variation " . $variation_id . " has been saved; Syncing to Alegra...");

        $alegra_sync = new Alegra_WC_Sync();
        $alegra_sync->alegra_wc_create_wc_product($variation_id);
    }

    // Save custom fields when the product is saved
    public function alegra_wc_save_product_unit_cost($post_id)
    {

        if (isset($_POST['wc_alegra_product_id'])) {
            $wc_alegra_product_id = sanitize_text_field($_POST['wc_alegra_product_id']);
            update_post_meta($post_id, 'wc_alegra_product_id', $wc_alegra_product_id);
        }

        if (isset($_POST['wc_alegra_unit_cost'])) {
            $wc_alegra_unit_cost = sanitize_text_field($_POST['wc_alegra_unit_cost']);
            update_post_meta($post_id, 'wc_alegra_unit_cost', $wc_alegra_unit_cost);
        }

        // Save Alegra Unit
        if (isset($_POST['wc_alegra_product_unit'])) {
            $wc_alegra_product_unit = sanitize_text_field($_POST['wc_alegra_product_unit']);
            update_post_meta($post_id, 'wc_alegra_product_unit', $wc_alegra_product_unit);
        }

        // Save Alegra Product Category
        if (isset($_POST['wc_alegra_product_category'])) {
            $wc_alegra_product_category = sanitize_text_field($_POST['wc_alegra_product_category']);
            update_post_meta($post_id, 'wc_alegra_product_category', $wc_alegra_product_category);
        }
    }


    // Add custom metabox
    public function alegra_wc_add_metaboxes()
    {

        add_meta_box(
            'alegra_wc_sync_metabox',
            __('Detalles de Alegra', 'alegra-wc-sync'),
            array($this, 'render_alegra_product_metabox'),
            'product',
            'side',
            'core'
        );

        $screen = wc_get_container()->get(CustomOrdersTableController::class)->custom_orders_table_usage_is_enabled()
            ? wc_get_page_screen_id('shop-order')
            : 'shop_order';

        add_meta_box(
            'alegra-order-metabox',
            __('Detalles de Alegra', 'alegra-wc-sync'),
            array($this, 'render_alegra_order_metabox'),
            $screen, // Set this to 'shop_order' to target orders
            'side',
            'default'
        );
    }

    // Render custom metabox
    public function render_alegra_product_metabox($post)
    {
        $product_id = $post->ID;
        $product = wc_get_product($product_id);

        echo '<div class="inside">';
        // Display the Sync Status
        $alegra_sync_status = get_post_meta($product_id, 'wc_alegra_sync_status', true);

        echo '<p><strong>' . __('Estado:', 'alegra-wc-sync') . '</strong><span class="alegra_wc_sync_status_' . sanitize_title($alegra_sync_status) . '"> ' . (!empty(esc_html($alegra_sync_status)) ? esc_html($alegra_sync_status) : "No Sincronizado") . '</p>';

        // Display the Last Synced timestamp
        $alegra_last_synced = get_post_meta($product_id, 'wc_alegra_last_synced', true);

        if (!empty($alegra_last_synced)) {
            echo '<p><strong>' . __('Ultima Sincronización:', 'alegra-wc-sync') . '</strong> ' . esc_html($alegra_last_synced) . '</p>';
        }

        if ($product->is_type('variable')) {

            $variations = $product->get_available_variations();

            $synced_variation_count = 0;


            echo '<p><strong> ID de Variación: </strong></p>';

            echo "<ul class='alegra-variation-list'>";

            foreach ($variations as $variation) {

                $alegra_product_id = get_post_meta($variation['variation_id'], 'wc_alegra_product_id', true);

                $variation_attributes_string = implode(' / ', $variation['attributes']);

                $variation_title = $product->get_name() . " " . ucwords(str_replace('-', ' ', $variation_attributes_string));


                if (!empty($alegra_product_id)) {

                    $synced_variation_count++;


                    echo '<li style="margin-bottom: 0px; margin-left:20px;"><strong>' . $variation_title . ': </strong> <a target="_blank" href="https://app.alegra.com/item/view/id/' . $alegra_product_id . '">' . esc_html($alegra_product_id) . '</a></li>';
                } else {

                    echo '<li style="margin-bottom: 0px; margin-left:20px;"><strong>' . $variation_title . ': </strong><span style="color:red"> No Sincronizado </span></li>';
                }
            }

            echo "</ul>";
        } else {

            $alegra_product_id = get_post_meta($product_id, 'wc_alegra_product_id', true);
            if (!empty($alegra_product_id)) {
                echo '<p><strong>' . __('ID de Alegra:', 'alegra-wc-sync') . '</strong> <a target="_blank" href="https://app.alegra.com/item/view/id/' . $alegra_product_id . '">' . esc_html($alegra_product_id) . '</a></p>';
            }
        }

        // Add the "Sync to Alegra" button with JavaScript click handler

        echo '<button type="button" class="button button-primary alegra_wc_sync_button" id="alegra_wc_sync_button" name="alegra_wc_sync_button" 
data-post-id="' . esc_attr($product_id) . '" 
data-object-type="Product" data-sync-type="all" data-force-sync="no">' . __('Sincronizar a Alegra', 'alegra-wc-sync') . '</button>';

        if ($alegra_sync_status == 'Error') {

            echo '<p><a href="#" class="alegra_wc_sync_button" role="button" id="alegra_wc_force_sync_button" data-post-id="' . esc_attr($product_id) . '" 
data-object-type="Product" data-sync-type="all" data-force-sync="yes">' . __('Forzar Sincronización', 'alegra-wc-sync') . '</a>';

            $tip = __("Una sincronización forzada ignora el ID de Alegra e intenta crear un producto como nuevo en Alegra.", 'alegra-wc-sync');

            echo wc_help_tip($tip, false);


            echo '</p>';
        }

        echo '</div>';
    }

    // Callback function to render the contents of the metabox
    public function render_alegra_order_metabox($post)
    {
        // Get the order object
        $order = wc_get_order($post);
        $order_id = $order->get_id();

        echo '<div class="inside">';

        // Get the stored custom meta values
        $alegra_invoice_id = $order->get_meta('alegra_invoice_id');
        $comprobante_fiscal = $order->get_meta('comprobante_fiscal');
        $alegra_order_document_id = $order->get_meta('alegra_order_document_id');
        $alegra_order_type = $order->get_meta('alegra_order_type');
        $alegra_order_document_type = $order->get_meta('alegra_order_document_type');
        $order_user_id = $order->get_customer_id();
        $alegra_order_alegra_contact_id = get_user_meta($order_user_id, 'alegra_user_id', true);


        echo '<ul>';
        echo '<li><strong>Status:</strong>';
        if (empty($alegra_invoice_id)) {
            echo '<span style="color:red">' . __(' No Sincronizado', 'alegra-wc-sync') . '<span>';
        } else {
            echo '<span style="color:green">' . __(' Sincronizado', 'alegra-wc-sync') . '<span></li>';
        }

        $Alegra_WC_Sync = new Alegra_WC_Sync();

        $documento = $Alegra_WC_Sync->get_alegra_document_type($alegra_order_document_type);

        $comprobante = $Alegra_WC_Sync->get_alegra_comprobante_type($alegra_order_type);

        // Output the custom data in the metabox
        if (!empty($alegra_invoice_id)) {
            echo '';
            echo '<li><strong>ID de Factura en Alegra:</strong> <a target="_blank" href="https://app.alegra.com/invoice/view/id/' . $alegra_invoice_id . '">' . esc_html($alegra_invoice_id) . '</a></li>';
        }

        if (!empty($alegra_order_alegra_contact_id)) {
            echo '';
            echo '<li><strong>ID de Usuario en Alegra:</strong> <a target="_blank" href="https://app.alegra.com/client/view/id/' . $alegra_order_alegra_contact_id . '">' . esc_html($alegra_order_alegra_contact_id) . '</a></li>';
        }


        echo '<li><strong>Comprobante Fiscal:</strong>';
        echo ($comprobante_fiscal == 1) ? ' Si ' : ' No ';
        echo '</li>';

        if (!empty($comprobante_fiscal)) {
            echo '<li><strong>' . $documento . ': </strong> ' . esc_html($alegra_order_document_id) . '</li>';
            echo '<li><strong>Tipo de Comprobante:</strong> ' . $comprobante . '</li>';
        }

        // Add the "Sync to Alegra" button with JavaScript click handler
        echo '<li style="margin-top:15px;">';
        echo '<button type="button" class="button button-primary" style="margin-right:10px;margin-bottom:10px; padding:0px 15px" id="alegra_wc_sync_button" name="alegra_wc_sync_button" 
                    data-post-id="' . esc_attr($order_id) . '" data-object-type="Order" data-sync-type="all">' . __('Sincronizar a Alegra', 'alegra-wc-sync') . '</button>';

        // Add the "Show Invoice Button" button with JavaScript click handler

        if (!empty($alegra_invoice_id)) {
            echo '<button type="button" class="button button-secondary" id="alegra_wc_invoice_button" name="alegra_wc_invoice_button" 
            data-post-id="' . esc_attr($order_id) . '" data-object-type="Order" data-invoice-id="' . $alegra_invoice_id . '">' . __('Ver PDF', 'alegra-wc-sync') . '</button>';
        }

        // Add the "Open Modal" button
        echo '<button type="button" class="button button-secondary" class="thickbox button button-secondary" id="alegra_open_modal_button" data-post-id="' . esc_attr($order_id) . '">' . __('Detalles Fiscales', 'alegra-wc-sync') . '</button>';
        echo '</li>';
        echo '</ul>';
        echo '</div>';

        require_once(PLUGIN_DIR . 'templates/alegra-modal-form.php');
    }


    //Render the custom fields to the user
    public function alegra_wc_user_custom_fields_markup($user)
    {
        $alegra_user_id = esc_attr(get_user_meta($user->ID, 'alegra_user_id', true));
        $alegra_user_tax_id = esc_attr(get_user_meta($user->ID, 'alegra_user_tax_id', true));
        $alegra_user_document_type = esc_attr(get_user_meta($user->ID, 'alegra_user_document_type', true));
        $alegra_user_razon_social = esc_attr(get_user_meta($user->ID, 'alegra_user_razon_social', true));
?>
        <h3>Detalles de Alegra</h3>
        <table class="form-table">
            <tr>
                <th>
                    <label for="alegra_user_id"><?php _e('ID de Usuario en Alegra', 'alegra-wc-sync') ?></label>
                </th>
                <td>
                    <input type="text" name="alegra_user_id" id="alegra_user_id" value="<?php echo $alegra_user_id; ?>" class="small-text">
                    <p class="description"><?php _e('Este es el ID de usuario en Alegra. ', 'alegra-wc-sync');
                                            if (!empty($alegra_user_id)) { ?><a href="https://app.alegra.com/client/view/id/<?php echo $alegra_user_id; ?> " target="_blank">Ver en Alegra</a><?php } ?></p>
                </td>
            </tr>
            <tr>
                <th>
                    <label for="alegra_user_document_type"><?php _e('Tipo de Documento en Alegra', 'alegra-wc-sync') ?></label>
                </th>
                <td>
                    <select name="alegra_user_document_type" id="alegra_user_document_type">
                        <option value="RNC" <?php selected($alegra_user_document_type, 'RNC'); ?>>RNC</option>
                        <option value="CED" <?php selected($alegra_user_document_type, 'CED'); ?>>Cédula</option>
                        <option value="IE" <?php selected($alegra_user_document_type, 'IE'); ?>>Pasaporte</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th>
                    <label for="alegra_user_razon_social"><?php _e('Razón Social', 'alegra-wc-sync') ?></label>
                </th>
                <td>
                    <input type="text" name="alegra_user_razon_social" id="alegra_user_razon_social" value="<?php echo $alegra_user_razon_social; ?>" class="medium-text">
                </td>
            </tr>
            <tr>
                <th>
                    <label for="alegra_user_tax_id"><?php _e('Identificador Fiscal en Alegra', 'alegra-wc-sync') ?></label>
                </th>
                <td>
                    <input type="text" name="alegra_user_tax_id" id="alegra_user_tax_id" value="<?php echo $alegra_user_tax_id; ?>" class="medium-text">
                </td>
            </tr>

            <tr>
                <th>
                    <label for="alegra_wc_sync_button"><?php _e('Sincronizar a Alegra', 'alegra-wc-sync') ?></label>
                </th>
                <td>
                    <button type="button" id="alegra_wc_sync_button" class="button hide-if-no-js alegra_wc_sync_button" aria-expanded="false" data-post-id="<?php echo esc_attr($user->ID) ?>" data-object-type="Contact" data-sync-type="all" data-force-sync="no">Sincronizar <?php echo $user->display_name  ?> a Alegra</button>


                </td>
            </tr>
        </table>
<?php
    }

    public function alegra_wc_save_user_custom_fields($user_id)
    {
        if (current_user_can('edit_user', $user_id)) {
            update_user_meta($user_id, 'alegra_user_id', sanitize_text_field($_POST['alegra_user_id']));
            update_user_meta($user_id, 'alegra_user_tax_id', sanitize_text_field($_POST['alegra_user_tax_id']));
            update_user_meta($user_id, 'alegra_user_document_type', sanitize_text_field($_POST['alegra_user_document_type']));
            update_user_meta($user_id, 'alegra_user_razon_social', sanitize_text_field($_POST['alegra_user_razon_social']));
        }
    }

    // Save the custom order data when the order is updated
    public function alegra_wc_save_settings_order_data($order_id)
    {

        $AlegraSync = new Alegra_WC_Sync();

        if (empty($order_id)) {
            //Maybe was called from ajax, get the order id from a jquery parameter
            $order_id = $_POST['order_id'];
        };

        $AlegraSync->alegra_wc_save_custom_order_data($order_id);
    }

    // Save the custom order data when the order is updated
    public function save_wc_order_as_fiscal()
    {

        $order = wc_get_order($_POST['order_id']);

        //First, update the order data, that's the source of truth

        $comprobante_fiscal = isset($_POST['comprobante_fiscal']) ? 1 : 0;

        $order->update_meta_data('comprobante_fiscal', $comprobante_fiscal);


        if (isset($_POST['alegra_order_document_id'])) {
            $order->update_meta_data('alegra_order_document_id', $_POST['alegra_order_document_id']);
        }

        if (isset($_POST['alegra_order_type'])) {
            $order->update_meta_data('alegra_order_type', $_POST['alegra_order_type']);
        }

        if (isset($_POST['alegra_order_document_type'])) {
            $order->update_meta_data('alegra_order_document_type', $_POST['alegra_order_document_type']);
        }

        if (isset($_POST['comprobante_fiscal'])) {
            $order->update_meta_data('comprobante_fiscal', $_POST['comprobante_fiscal']);
        }

        $order->save();

        Alegra_WC_Logs::log(__METHOD__, 'Invoice updated succesfully.');

        wp_send_json_success('Invoice Updated Successfully.');
    }




    public function alegra_wc_tools($tools)
    {

        $alegra_sync_all_products = array(
            'alegra_sync_all_products' => array(
                'name'     => __('Sincronizar todos los productos a Alegra', 'alegra-wc-sync'),
                'button'   => __('Sincronizar productos', 'alegra-wc-sync'),
                'desc'     => __('Esto intentará sincronizar TODOS los productos con Alegra. Es posible que tarde unos minutos en completarse.', 'alegra-wc-sync'),
                'callback' => array($this, 'alegra_sync_all_products'),
                'disabled' => false,
            ),
        );

        $alegra_sync_all_categories = array(
            'alegra_sync_all_categories' => array(
                'name'     => 'Sincronizar todas las categorías con Alegra',
                'button'   => 'Sincronizar categorías',
                'desc'     => __('Esto intentará sincronizar TODAS las categorías con Alegra. Es posible que tarde unos minutos en completarse.', 'alegra-wc-sync'),
                'callback' => array($this, 'alegra_sync_all_categories'),
                'disabled' => false,
            ),
        );

        $alegra_clear_all_alegra_data = array(
            'alegra_clear_all_alegra_data' => array(
                'name'     => __('Eliminar todos los metadatos de Alegra Sync', 'alegra-wc-sync') . " ⚠️ ",
                'button'   => 'Eliminar metadatos',
                'desc'     => __('Cuidado! Esto eliminará todos los metadatos sobre Alegra de todos los productos, órdenes y usuarios. Haga una copia de seguridad de su base de datos.', 'alegra-wc-sync'),
                'callback' => array($this, 'alegra_clear_all_alegra_data'),
                'disabled' => false,
            ),
        );

        //This brings our tools higher in the order in Woocommerce
        $tools = array_slice($tools, 0, 2, true) + $alegra_sync_all_products +  $alegra_sync_all_categories + $alegra_clear_all_alegra_data + array_slice($tools, 2, NULL, true);

        return $tools;
    }


    public function alegra_sync_all_products()
    {

        Alegra_WC_Logs::log(__METHOD__, "Syncing all products to WooCommerce started...");

        $args = array(
            'post_type' => array('product'),
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'fields' => 'ids',
            'no_found_rows' => 1
        );

        $query = new WP_Query($args);

        if ($query->have_posts()) {
            wp_reset_postdata();
            $Alegra_WC_Sync = new Alegra_WC_Sync();
            while ($query->have_posts()) : $query->the_post();
                $product_id = get_the_ID();
                $schedule_id = $Alegra_WC_Sync->alegra_wc_create_wc_product($product_id, true);
            endwhile;
        } else {
            return __('La solicitud está vacía.', 'alegra-wc-sync');
        }

        return __("Sincronización de todos los productos con Alegra iniciada. Consulte los registros de depuración para obtener más detalles.", 'alegra-wc-sync');
    }

    public function alegra_sync_all_categories()
    {

        Alegra_WC_Logs::log(__METHOD__, "Syncing all categories to WooCommerce started...");

        $args = array(
            'taxonomy' => 'product_cat', // Use 'product_cat' taxonomy to get product categories
            'hide_empty' => false,
            'fields' => 'ids',
        );

        $categories = get_terms($args);

        if (!empty($categories)) {
            $Alegra_WC_Sync = new Alegra_WC_Sync();
            foreach ($categories as $category_id) {
                $schedule_id = $Alegra_WC_Sync->alegra_wc_create_category($category_id, true);
                Alegra_WC_Logs::log(__METHOD__, "Scheduled Category " . $category_id . " with Schedule ID " . $schedule_id);
            }
        } else {
            Alegra_WC_Logs::log(__METHOD__, "No product Categories found.", 'notice');
            return __('No se encontraron categorías de producto.', 'alegra-wc-sync');
        }

        return __("Sincronización de todas la categorías productos con Alegra Iniciada. Consulte los registros de depuración para obtener más detalles.", 'alegra-wc-sync');
    }




    public function alegra_clear_all_alegra_data()
    {
        Alegra_WC_Logs::log(__METHOD__, "Clearing all Alegra Data from WooCommerce started...");

        global $wpdb;

        // Array of custom meta keys added by your plugin
        $custom_meta_keys = array(
            'wc_alegra_sync_status',
            'wc_alegra_last_synced',
            'wc_alegra_product_id',
            'wc_alegra_unit_cost',
            'wc_alegra_product_unit',
            'wc_alegra_product_category',
            'wc_alegra_variation_id',
            'alegra_order_document_id',
            'alegra_order_type',
            'alegra_order_document_type',
            'alegra_invoice_id',
            'alegra_invoice_date_created',
            'comprobante_fiscal',
        );

        // Array of custom meta keys added by your plugin for users
        $user_meta_keys = array(
            'alegra_user_tax_id',
            'alegra_user_document_type'
        );

        // Delete meta data for each key
        foreach ($custom_meta_keys as $meta_key) {
            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s",
                    $meta_key
                )
            );
        }

        foreach ($user_meta_keys as $meta_key) {
            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$wpdb->usermeta} WHERE meta_key = %s",
                    $meta_key
                )
            );
        }
        return __("Eliminación de metatados de WooCommerce iniciada. Consulte los registros de depuración para obtener más detalles.", 'alegra-wc-sync');
    }

    public function handle_post_saving_alegra_settings()
    {

        // Check the current checkbox state from the submitted form data
        $new_value = isset($_POST['receive_webhooks_from_alegra']) ? 'yes' : 'no';

        // Retrieve the current registration status from the options table
        $current_registration = get_option('alegra_webhook_subscription');

        // Decide to register or unregister webhooks based on the checkbox value
        if ($new_value === 'yes' && empty($current_registration)) {
            // If checkbox is checked and no webhooks are registered, register them
            $registration_result = Alegra_WC_API::register_and_store_webhook();
        } elseif ($new_value === 'no' && !empty($current_registration)) {
            // If checkbox is unchecked and webhooks are currently registered, unregister them
            $unregistration_result = Alegra_WC_API::unregister_webhooks();
        }
    }

    public function alegra_tools_post_execution($tool)
    {

        if (substr($tool['id'], 0, 7) === "alegra_") {

            // Alegra_WC_Logs::log(__METHOD__, $tool['name'] . " se ejecutó correctamente. ");


            echo '<div class="updated"><p>' .  $tool['name'] . __(" se ejecutó correctamente. ", 'alegra-wc-sync') . '</p></div>';
        }
    }

    function add_fiscal_order_details_to_admin_email($order, $sent_to_admin, $plain_text, $email)
    {
        // Check if the email is for the admin for a new order
        if ($sent_to_admin && 'new_order' == $email->id) {
            // Assuming you store fiscal order details as order meta
            $alegra_invoice_id = get_post_meta($order->get_id(), 'alegra_invoice_id', true);

            if (!empty($alegra_invoice_id)) {

                $Alegra_WC_Sync = new Alegra_WC_Sync();

                $alegra_order_document_type =  $Alegra_WC_Sync->get_alegra_document_type($order->get_meta('alegra_order_document_type'));
                $alegra_order_document_id = $order->get_meta('alegra_order_document_id');
                $alegra_order_type =  $Alegra_WC_Sync->get_alegra_comprobante_type($order->get_meta('alegra_order_type'));

                // Begin your table or any other formatting of information
                echo '<h2>Detalles Fiscales del Pedido</h2>';
                echo '<table cellspacing="0" style="width:100%; border: 1px solid #e5e5e5; margin-bottom: 40px;">';
                echo '<thead><tr>';
                echo '<th scope="col" style="text-align:left; border: 1px solid #eee; padding: 12px;">Detalle</th>';
                echo '<th scope="col" style="text-align:left; border: 1px solid #eee; padding: 12px;">Valor</th>';
                echo '</tr></thead>';
                echo '<tbody>';

                echo '<tr>';
                echo '<td style="text-align:left; border: 1px solid #eee; padding: 12px;">Tipo de Documento</td>';
                echo '<td style="text-align:left; border: 1px solid #eee; padding: 12px;">' . esc_html($alegra_order_document_type) . '</td>';
                echo '</tr>';

                echo '<tr>';
                echo '<td style="text-align:left; border: 1px solid #eee; padding: 12px;">Número de Documento</td>';
                echo '<td style="text-align:left; border: 1px solid #eee; padding: 12px;">' . esc_html($alegra_order_document_id) . '</td>';
                echo '</tr>';

                echo '<tr>';
                echo '<td style="text-align:left; border: 1px solid #eee; padding: 12px;">Tipo de Comprobante</td>';
                echo '<td style="text-align:left; border: 1px solid #eee; padding: 12px;">' . esc_html($alegra_order_type) . '</td>';
                echo '</tr>';

                echo '<tr>';
                echo '<td style="text-align:left; border: 1px solid #eee; padding: 12px;">ID de Factura en Alegra</td>';
                echo '<td style="text-align:left; border: 1px solid #eee; padding: 12px;">' . esc_html($alegra_invoice_id) . ' ( <a href="https://app.alegra.com/invoice/view/id/' . esc_html($alegra_invoice_id) . '" target="blank">ver en Alegra</a>)</td>';
                echo '</tr>';

                echo '</tbody></table>';
            }
        }
    }

    public function alegra_wc_credentials_updated($old_value, $value, $option_name)
    {
        // Perform the API call
        $response = Alegra_WC_API::alegra_wc_api_request('GET', 'company');

        if ($response['code'] == 200) {  // Assuming 200 is the success code
            update_option('alegra_connection_status', 'Conectado');
            update_option('alegra_company_name', $response['data']['name']);
            update_option('alegra_company_regime', $response['data']['regime']);

            $transient_data = array(
                'message' => 'Successfully connected to Alegra.',
                'type' => 'success'
            );

            if (get_option('alegra_inventory_sync') === 'yes') {

                //Unschedule everything to reschedule again
                as_unschedule_all_actions('alegra_to_wc_inventory_sync');

                $interval = get_option('alegra_inventory_sync_delay', 24);

                as_schedule_recurring_action(time(), $interval * HOUR_IN_SECONDS, 'alegra_to_wc_inventory_sync');
            }

            // Check if the custom field ID is already stored
            if (!get_option('alegra_wc_custom_field_id')) {
                Alegra_WC_Sync::create_alegra_custom_field();
            }


        } else {

            $transient_data = array(
                'message' => 'Failed to connect to Alegra. Check your credentials.',
                'type' => 'error'
            );
            update_option('alegra_connection_status', 'No Conectado');
            update_option('alegra_company_name', '');
            update_option('alegra_company_regime', '');
        }

        set_transient('alegra_admin_notice', $transient_data, 60);
    }
}
