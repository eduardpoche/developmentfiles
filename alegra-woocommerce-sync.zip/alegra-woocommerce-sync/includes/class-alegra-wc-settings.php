<?php
class AlegraWCSyncSettings
{
    public function __construct()
    {
        add_filter('woocommerce_product_data_tabs', array($this, 'alegra_wc_add_custom_product_data_tab'));
        add_action('woocommerce_product_data_panels', array($this, 'alegra_wc_display_custom_product_data_tab_content'));
        add_action('add_meta_boxes', array($this, 'alegra_wc_add_metaboxes'));
        add_action('admin_enqueue_scripts', array($this, 'alegra_wc_enqueue_scripts'));
        add_action('wp_ajax_alegra_wc_sync_to_alegra', array($this, 'wc_sync_to_alegra_ajax'));
        add_action('wp_ajax_nopriv_alegra_wc_sync_to_alegra', array($this, 'wc_sync_to_alegra_ajax'));
        add_action('wp_ajax_alegra_wc_get_alegra_invoice_pdf', array($this, 'alegra_wc_get_alegra_invoice_pdf'));
        add_action('wp_ajax_nopriv_alegra_wc_get_alegra_invoice_pdf', array($this, 'alegra_wc_get_alegra_invoice_pdf'));
        add_action('show_user_profile', array($this, 'alegra_wc_user_custom_fields_markup'));
        add_action('edit_user_profile', array($this, 'alegra_wc_user_custom_fields_markup'));
        add_action('personal_options_update', array($this, 'alegra_wc_save_user_custom_fields'));
        add_action('edit_user_profile_update', array($this, 'alegra_wc_save_user_custom_fields'));
        add_action('woocommerce_variation_options_pricing', array($this, 'alegra_wc_display_variation_unit_cost'), 10, 3);
        add_action('woocommerce_save_product_variation', array($this, 'alegra_wc_save_variation_changes'), 10, 2);
        add_action('woocommerce_process_product_meta', array($this, 'alegra_wc_save_product_unit_cost'));
        add_action('woocommerce_process_shop_order_meta', array($this, 'alegra_wc_save_settings_order_data'));
        add_filter('woocommerce_settings_tabs_array', array($this, 'alegra_wc_add_settings_tab'), 50);
        add_action('woocommerce_sections_alegra_settings', array($this, 'alegra_wc_sections_content'));
        add_action('woocommerce_settings_tabs_alegra_settings', array($this, 'alegra_wc_settings_tab'));
        add_action('woocommerce_update_options_alegra_settings', array($this, 'alegra_wc_register_settings'));
        //add_action('woocommerce_variation_options_pricing', array($this, 'alegra_wc_add_inventory_adjustment_button'), 10, 3); 
        //add_action('wp_ajax_alegra_wc_inventory_adjustment', array($this, 'alegra_wc_handle_inventory_adjustment'));
        //add_action('wp_ajax_nopriv_alegra_wc_inventory_adjustment', array($this, 'alegra_wc_handle_inventory_adjustment'));
        add_action('wp_ajax_save_wc_order_as_fiscal', array($this, 'save_wc_order_as_fiscal'));
        add_action('wp_ajax_nopriv_save_wc_order_as_fiscal', array($this, 'save_wc_order_as_fiscal'));
        add_filter('woocommerce_debug_tools', array($this, 'alegra_wc_tools'));
        //add_action('woocommerce_before_delete_product', array($this, 'alegra_wc_delete_variation'));
        add_action('woocommerce_system_status_tool_executed', array($this, 'alegra_tools_post_execution'));
        add_filter('woocommerce_status_log_items_per_page', array($this, 'alegra_wc_return_100_items'));
        add_action('woocommerce_admin_field_button', [$this, 'alegra_wc_render_button_settings']);
        add_action('wp_ajax_alegra_wc_check_for_inventory_adjustments', array($this, 'alegra_wc_check_for_inventory_adjustments_ajax'));
        add_action('wp_ajax_nopriv_alegra_wc_check_for_inventory_adjustments', array($this, 'alegra_wc_check_for_inventory_adjustments_ajax'));
        add_action('update_option_alegra_inventory_adjustment_delay', [$this, 'alegra_wc_update_inventory_delay'], 10, 3);
    }

    function alegra_wc_enqueue_scripts()
    {
        add_thickbox();

        wp_enqueue_script('alegra-wc-sync', plugin_dir_url(__DIR__) . 'js/alegra-wc-sync.js', array('jquery'), '1.1', true);

        wp_enqueue_style('alegra-wc-sync', plugin_dir_url(__DIR__) . 'css/alegra-wc-sync-admin.css', array(), '1.0', 'all');
    }

    function alegra_wc_check_for_inventory_adjustments_ajax()
    {

        $alegra_sync = new AlegraWCSync();

        $response = $alegra_sync->alegra_wc_check_for_inventory_adjustments();

        wp_send_json($response);
    }

    function alegra_wc_update_inventory_delay($old_value, $value, $option)
    {


        AlegraWCSync::alegra_log(__METHOD__ . "(): " . 'Our setting changed! => ' . print_r($old_value, true) . "    " . print_r($value, true) . "   " . print_r($option, true));

        //The inventory delay changed, update accordingly

        as_unschedule_all_actions('alegra_wc_check_for_inventory_adjustments');

        as_schedule_recurring_action(date('U'), $value * HOUR_IN_SECONDS, 'alegra_wc_check_for_inventory_adjustments');
    }

    function wc_sync_to_alegra_ajax()
    {

        $object_type = $_POST['object_type'];
        $object_id = intval($_POST['post_id']);
        $sync_type = $_POST['sync_type'];
        $force_sync = $_POST['force_sync'];

        if (empty($object_type) || empty($object_id)) {
            wp_send_json_error('Cannot determine the object (product, order, contact) to be synced.');
        }

        $alegra_sync = new AlegraWCSync();

        //Based on the object-type (order, product, etc), call the correct method.

        switch ($object_type) {
            case 'Product':
                $response = $alegra_sync->alegra_wc_create_product($object_id, false, $sync_type, $force_sync);
                break;
            case 'Order':
                $response = $alegra_sync->alegra_wc_create_invoice($object_id, $sync_type, $force_sync = false);
                break;
            case 'Contact':
                $response = $alegra_sync->alegra_wc_create_contact($object_id, array());
                break;
        }

        if (($response['success'])) {
            wp_send_json_success($response['data']);
        } else {
            wp_send_json_error($response['data']);
        }
    }

    function alegra_wc_get_alegra_invoice_pdf()
    {

        $object_type = $_POST['object_type'];
        $object_id = intval($_POST['post_id']);
        $invoice_id = intval($_POST['invoice_id']);

        if (empty($object_type) || empty($object_id) || empty($invoice_id)) {
            wp_send_json_error(
                array('data' => array('message' => 'Cannot determine the object (product, order) to be synced.'))
            );
        }

        $alegra_sync = new AlegraWCSync();

        //Based on the object-type (order, product, etc), call the correct method.

        $return = array();

        switch ($object_type) {
            case 'Product':
                //If this works for the Products at some point this should work.
                $response = $alegra_sync->alegra_wc_create_product($object_id);
                break;
            case 'Order':
                $endpoint = "invoices/" . $invoice_id . "?fields=pdf";

                $response = $alegra_sync->alegra_wc_api_request('GET', $endpoint);

                if (in_array($response['code'], array(200, 201)) && isset($response['data']['id'])) {

                    //Response was successful, check for its content
                    $response = $response['data'];

                    if ($response['status'] == 'draft') {

                        AlegraWCSync::alegra_log(__METHOD__ . "(): " . 'Got the Invoice from but its a draft. Drafts dont have PDF.' . print_r($response, true), 'warning');
                        $return['success'] = false;
                        $return['data'] = 'The Invoice ID ' . $invoice_id . ' is a Draft in Alegra. Drafts dont have PDF links.';
                    } else {
                        AlegraWCSync::alegra_log(__METHOD__ . "(): " . 'Got the Invoice from Alegra! => ' . print_r($response, true));
                        $return['success'] = true;
                        $pdf_link = $response['pdf'];
                        $return['data'] = $pdf_link;
                    }
                } else {
                    AlegraWCSync::alegra_log(__METHOD__ . "(): " . 'Getting invoice failed. ' . print_r($response, true), 'error');
                    $return['success'] = false;
                    $return['data'] = $response['data'];
                }
        }

        if (($return['success'])) {
            wp_send_json_success($return['data']);
        } else {
            wp_send_json_error($return['data']);
        }
    }

    // Add custom tab
    public function alegra_wc_add_custom_product_data_tab($tabs)
    {
        $tabs['alegra_wc_sync'] = array(
            'label'    => __('Alegra Sync', 'alegra-wc-sync'),
            'target'   => 'alegra_wc_sync_options',
            'class'    => array('show_if_simple', 'show_if_variable'),
        );
        return $tabs;
    }

    // Display custom tab content
    public function alegra_wc_display_custom_product_data_tab_content()
    {
        global $post;

        // Start the "options_group" div with the target class
        echo '<div id="alegra_wc_sync_options" class="panel woocommerce_options_panel hidden">';

        // Get the Alegra Sync Status value
        $alegra_sync_status = get_post_meta($post->ID, 'wc_alegra_sync_status', true);

        // Get the Alegra Last Synced value
        $alegra_last_synced = get_post_meta($post->ID, 'wc_alegra_last_synced', true);

        // Get the Alegra Product ID value
        $alegra_product_id = get_post_meta($post->ID, 'wc_alegra_product_id', true);

        // Get the Alegra Product ID value
        $alegra_unit_cost = get_post_meta($post->ID, 'wc_alegra_unit_cost', true);

        // Get the Alegra Product Unit value
        $alegra_product_unit = get_post_meta($post->ID, 'wc_alegra_product_unit', true);

        // Get the Alegra Product category value
        $alegra_product_category = get_post_meta($post->ID, 'wc_alegra_product_category', true);

        // Display Alegra Sync Status as an option
        woocommerce_wp_text_input(
            array(
                'id'          => 'wc_alegra_sync_status',
                'label'       => __('Alegra Sync Status', 'alegra-wc-sync'),
                'placeholder' => __('Enter Alegra Sync Status', 'alegra-wc-sync'),
                'desc_tip'    => 'true',
                'description' => __('Enter the Alegra sync status for this product.', 'alegra-wc-sync'),
                'custom_attributes' => ['disabled' => true, 'readonly' => true]
            )
        );

        // Display Alegra Last Synced as an option
        woocommerce_wp_text_input(
            array(
                'id'          => 'wc_alegra_last_synced',
                'label'       => __('Last Synced on Alegra', 'alegra-wc-sync'),
                'placeholder' => __('Enter Alegra Last Synced', 'alegra-wc-sync'),
                'desc_tip'    => 'true',
                'description' => __('Timestamp of the last sync with Alegra for this product.', 'alegra-wc-sync'),
                'custom_attributes' => ['disabled' => true, 'readonly' => true]
            )
        );


        // Display Alegra Product ID as an option if not a variable product

        $product = wc_get_product($post->ID);

        if ($product->is_type('simple')) {

            woocommerce_wp_text_input(
                array(
                    'id'          => 'wc_alegra_product_id',
                    'label'       => __('Alegra Product ID', 'alegra-wc-sync'),
                    'placeholder' => __('Enter Alegra Product ID', 'alegra-wc-sync'),
                    'desc_tip'    => 'true',
                    'description' => __('The Alegra Product ID for this product.', 'alegra-wc-sync'),
                    'custom_attributes' => ['disabled' => true, 'readonly' => true]
                )
            );
        }

        //Display Alegra unit cost
        woocommerce_wp_text_input(
            array(
                'id' => 'wc_alegra_unit_cost',
                'label' => __('Alegra Unit Cost', 'alegra-wc-sync'),
                'type' => 'number',
                'desc_tip' => 'true',
                'description' => __('Enter the unit cost for this product.', 'alegra-wc-sync'),
                'custom_attributes' => array(
                    'step'     => 'any',
                    'min'    => '1'
                ),
                'data_type' => 'price'
            )
        );

        woocommerce_wp_select(
            array(
                'id' => 'wc_alegra_product_unit',
                'label' => 'Product Unit',
                'class' => 'wc-enhanced-select long',
                'style' => 'width: 50%',
                'value' => (empty($alegra_product_unit) ? 'LB' : $alegra_product_unit),
                'options' => array(
                    'BARR'  => 'Barril',
                    'BOL'  => 'Bolsa',
                    'BOT'  => 'Bote',
                    'BULTO'  => 'Bultos',
                    'BOTELLA'  => 'Botella',
                    'CAJ'  => 'Caja/Cajón',
                    'CAJETILLA'  => 'Cajetilla',
                    'CM'  => 'Centímetro',
                    'CIL'  => 'Cilindro',
                    'CONJ'  => 'Conjunto',
                    'CONT'  => 'Contenedor',
                    'DÍA'  => 'Día',
                    'DOC'  => 'Docena',
                    'FARD'  => 'Fardo',
                    'GL'  => 'Galones',
                    'GRAD'  => 'Grado',
                    'GR'  => 'Gramo',
                    'GRAN'  => 'Granel',
                    'HOR'  => 'Hora',
                    'HUAC'  => 'Huacal',
                    'KG'  => 'Kilogramo',
                    'kWh'  => 'Kilovatio Hora',
                    'LB'  => 'Libra',
                    'LITRO'  => 'Litro',
                    'LOT'  => 'Lote',
                    'M'  => 'Metro',
                    'M2'  => 'Metro Cuadrado',
                    'M3'  => 'Metro Cúbico',
                    'MMBTU'  => 'Millones de Unidades Térmicas',
                    'MIN'  => 'Minuto',
                    'PAQ'  => 'Paquete',
                    'PAR'  => 'Par',
                    'PIE'  => 'Pie',
                    'PZA'  => 'Pieza',
                    'ROL'  => 'Rollo',
                    'SOBR'  => 'Sobre',
                    'SEG'  => 'Segundo',
                    'TANQUE'  => 'Tanquear',
                    'TONE'  => 'Tonelada',
                    'TUB'  => 'Tubo',
                    'YD'  => 'Yarda',
                    'YD2'  => 'Yarda cuadrada',
                    'UND'  => 'Unidad',
                    'UND'  => 'Unidad',
                    'EA'  => 'Elemento',
                    'MILLAR'  => 'Millar',
                    'SAC'  => 'Saco',
                    'LAT'  => 'Lata',
                    'DIS'  => 'Display',
                    'BID'  => 'Bidón',
                    'RAC'  => 'Ración'
                ),
                'desc_tip' => true,
                'description' => __('Enter the unit measurement for this product', 'alegra-wc-sync')
            )
        );

        $alegra_categories =  AlegraWCSync::alegra_wc_get_alegra_categories();

        woocommerce_wp_select(
            array(
                'id' => 'wc_alegra_product_category',
                'label' => 'Alegra Product Category',
                'class' => 'wc-enhanced-select long',
                'style' => 'width: 50%',
                'value' => (empty($alegra_product_category) ? '' : $alegra_product_category),
                'options' => $alegra_categories,
                'desc_tip' => true,
                'description' => __('Select an Alegra Product Category for this product.', 'alegra-wc-sync')
            )
        );
        // Close the "options_group" div
        echo '</div>';
    }


    public function alegra_wc_display_variation_unit_cost($loop, $variation_data, $variation)
    {

        // Get the Alegra Product ID value
        $alegra_unit_cost = get_post_meta($variation->ID, 'wc_alegra_unit_cost', true);

        woocommerce_wp_text_input(
            array(
                'id' => "wc_alegra_unit_cost[" . $loop . "]",
                'type' => 'number',
                'wrapper_class' => 'form-row',
                'label' => __('Alegra Unit Cost', 'alegra-wc-sync'),
                'desc_tip' => 'true',
                'description' => __('Enter the unit cost for this variation.', 'alegra-wc-sync'),
                'value' => $alegra_unit_cost
            )
        );
    }

    public function alegra_wc_save_variation_changes($variation_id, $i)
    {

        $alegra_unit_cost = isset($_POST['wc_alegra_unit_cost'][$i]) ? $_POST['wc_alegra_unit_cost'][$i] : 1;

        update_post_meta($variation_id, 'wc_alegra_unit_cost', $alegra_unit_cost);

        AlegraWCSync::alegra_log(__METHOD__ . "(): Variation " . $variation_id . " has been saved; Syncing to Alegra...");

        $alegra_sync = new AlegraWCSync();
        $alegra_sync->alegra_wc_create_product($variation_id);
    }

    // Save custom fields when the product is saved
    public function alegra_wc_save_product_unit_cost($post_id)
    {

        if (isset($_POST['wc_alegra_product_id'])) {
            $wc_alegra_product_id = sanitize_text_field($_POST['wc_alegra_product_id']);
            update_post_meta($post_id, 'wc_alegra_product_id', $wc_alegra_product_id);
        }

        if (isset($_POST['wc_alegra_unit_cost'])) {
            $wc_alegra_unit_cost = sanitize_text_field($_POST['wc_alegra_unit_cost']);
            update_post_meta($post_id, 'wc_alegra_unit_cost', $wc_alegra_unit_cost);
        }

        // Save Alegra Unit
        if (isset($_POST['wc_alegra_product_unit'])) {
            $wc_alegra_product_unit = sanitize_text_field($_POST['wc_alegra_product_unit']);
            update_post_meta($post_id, 'wc_alegra_product_unit', $wc_alegra_product_unit);
        }

        // Save Alegra Product Category
        if (isset($_POST['wc_alegra_product_category'])) {
            $wc_alegra_product_category = sanitize_text_field($_POST['wc_alegra_product_category']);
            update_post_meta($post_id, 'wc_alegra_product_category', $wc_alegra_product_category);
        }
    }


    // Add custom metabox
    public function alegra_wc_add_metaboxes()
    {

        add_meta_box(
            'alegra_wc_sync_metabox',
            __('Alegra Product Details', 'alegra-wc-sync'),
            array($this, 'render_alegra_product_metabox'),
            'product',
            'side',
            'core'
        );

        add_meta_box(
            'alegra-order-metabox',
            __('Alegra Order Details', 'alegra-wc-sync'),
            array($this, 'render_alegra_order_metabox'),
            'shop_order', // Set this to 'shop_order' to target orders
            'side',
            'default'
        );
    }

    // Render custom metabox
    public function render_alegra_product_metabox($post)
    {
        $product = wc_get_product($post->ID);

        echo '<div class="inside">';
        // Display the Sync Status
        $alegra_sync_status = get_post_meta($post->ID, 'wc_alegra_sync_status', true);

        echo '<p><strong>' . __('Status:', 'alegra-wc-sync') . '</strong><span class="alegra_wc_sync_status_' . sanitize_title($alegra_sync_status) . '"> ' . (!empty(esc_html($alegra_sync_status)) ? esc_html($alegra_sync_status) : "No Sincronizado") . '</p>';

        // Display the Last Synced timestamp
        $alegra_last_synced = get_post_meta($post->ID, 'wc_alegra_last_synced', true);
        echo '<p><strong>' . __('Ultima Sincronización:', 'alegra-wc-sync') . '</strong> ' . esc_html($alegra_last_synced) . '</p>';

        if ($product->is_type('variable')) {

            $variations = $product->get_available_variations();

            $synced_variation_count = 0;


            echo '<p><strong> Variation IDs: </strong></p>';

            echo "<ul class='alegra-variation-list'>";

            foreach ($variations as $variation) {

                $alegra_product_id = get_post_meta($variation['variation_id'], 'wc_alegra_product_id', true);

                $variation_attributes_string = implode(' / ', $variation['attributes']);

                $variation_title = $product->get_name() . " " . ucwords(str_replace('-', ' ', $variation_attributes_string));


                if (!empty($alegra_product_id)) {

                    $synced_variation_count++;


                    echo '<li style="margin-bottom: 0px; margin-left:20px;"><strong>' . $variation_title . ': </strong> <a target="_blank" href="https://app.alegra.com/item/view/id/' . $alegra_product_id . '">' . esc_html($alegra_product_id) . '</a></li>';
                } else {

                    echo '<li style="margin-bottom: 0px; margin-left:20px;"><strong>' . $variation_title . ': </strong><span style="color:red"> Not Synced</span>  </li>';
                }
            }

            echo "</ul>";
        } else {

            $alegra_product_id = get_post_meta($post->ID, 'wc_alegra_product_id', true);
            echo '<p><strong>' . __('ID de Alegra:', 'alegra-wc-sync') . '</strong> <a target="_blank" href="https://app.alegra.com/item/view/id/' . $alegra_product_id . '">' . esc_html($alegra_product_id) . '</a></p>';
        }

        // Add the "Sync to Alegra" button with JavaScript click handler

        echo '<button type="button" class="button button-primary alegra_wc_sync_button" id="alegra_wc_sync_button" name="alegra_wc_sync_button" 
data-post-id="' . esc_attr($post->ID) . '" 
data-object-type="Product" data-sync-type="all" data-force-sync="no">' . __('Sync to Alegra', 'alegra-wc-sync') . '</button>';

        if ($alegra_sync_status == 'Error') {


            echo '<p><a href="#" class="alegra_wc_sync_button" role="button" id="alegra_wc_force_sync_button" data-post-id="' . esc_attr($post->ID) . '" 
data-object-type="Product" data-sync-type="all" data-force-sync="yes">' . __('Force Sync', 'alegra-wc-sync') . '</a>';

            $tip = "A forced sync ignores the Alegra ID and tries to create a product as new in Alegra.";

            echo wc_help_tip($tip, false);


            echo '</p>';
        }

        if ($product->is_type('variable')) {


            echo '<button type="button" style="margin-top: 10px;" class="button button-secondary alegra_wc_sync_button" id="alegra_wc_sync_pending_button" name="alegra_wc_sync_pending_button" 
data-post-id="' . esc_attr($post->ID) . '" 
data-object-type="Product" data-sync-type="pending-variations">' . __('Sync Pending Variations', 'alegra-wc-sync') . '</button>';
        }



        echo '</div>';
    }

    // Callback function to render the contents of the metabox
    public function render_alegra_order_metabox($post)
    {
        // Get the order object
        $order = wc_get_order($post->ID);

        echo '<div class="inside">';

        // Get the stored custom meta values
        $alegra_invoice_id = $order->get_meta('alegra_invoice_id');
        $comprobante_fiscal = $order->get_meta('comprobante_fiscal');
        $alegra_order_document_id = $order->get_meta('alegra_order_document_id');
        $alegra_order_type = $order->get_meta('alegra_order_type');
        $alegra_order_document_type = $order->get_meta('alegra_order_document_type');


        echo '<ul>';
        echo '<li><strong>Status:</strong>';
        if (empty($alegra_invoice_id)) {
            echo '<span style="color:red"> No Sincronizado<span>';
        } else {
            echo '<span style="color:green"> Sincronizado<span></li>';
        }

        switch ($alegra_order_document_type) {
            case 'RNC':
                $documento = 'RNC';
                break;
            case 'CED':
                $documento = 'Cédula';
                break;
            default:
                $documento = "No. de Identificación";
        }

        switch ($alegra_order_type) {
            case 'INVOICE_B01':
                $comprobante = 'Crédito Fiscal';
                break;
            case 'INVOICE_B02':
                $comprobante = 'Factura de Consumo';
                break;
            case 'INVOICE_B14':
                $comprobante = 'Regímenes Especiales';
                break;
            case 'INVOICE_B15':
                $comprobante = 'Gubernamental';
                break;
            default:
                $comprobante = "Sin Comprobante";
        }

        // Output the custom data in the metabox
        if (!empty($alegra_invoice_id)) {
            echo '';
            echo '<li><strong>ID de Factura en Alegra:</strong> <a target="_blank" href="https://app.alegra.com/invoice/view/id/' . $alegra_invoice_id . '">' . esc_html($alegra_invoice_id) . '</a></li>';
        }

        echo '<li><strong>Comprobante Fiscal:</strong>';
        echo ($comprobante_fiscal == 1) ? ' Si ' : ' No ';
        echo '</li>';

        if (!empty($comprobante_fiscal)) {
            echo '<li><strong>' . $documento . ': </strong> ' . esc_html($alegra_order_document_id) . '</li>';
            echo '<li><strong>Tipo de Comprobante:</strong> ' . $comprobante . '</li>';
        }

        // Add the "Sync to Alegra" button with JavaScript click handler
        echo '<li style="margin-top:15px;">';
        echo '<button type="button" class="button button-primary" style="margin-right:15px;" id="alegra_wc_sync_button" name="alegra_wc_sync_button" 
                    data-post-id="' . esc_attr($post->ID) . '" data-object-type="Order" data-sync-type="all">' . __('Sync to Alegra', 'alegra-wc-sync') . '</button>';

        // Add the "Show Invoice Button" button with JavaScript click handler

        if (!empty($alegra_invoice_id)) {
            echo '<button type="button" class="button button-secondary" id="alegra_wc_invoice_button" name="alegra_wc_invoice_button" 
            data-post-id="' . esc_attr($post->ID) . '" data-object-type="Order" data-invoice-id="' . $alegra_invoice_id . '">' . __('View PDF', 'alegra-wc-sync') . '</button>';
        }

        // Add the "Open Modal" button
        echo '<button type="button" class="button button-secondary" class="thickbox button button-secondary" id="alegra_open_modal_button" data-post-id="' . esc_attr($post->ID) . '">' . __('Detalles Fiscales', 'alegra-wc-sync') . '</button>';
        echo '</li>';
        echo '</ul>';
        echo '</div>';

        require_once(PLUGIN_DIR . 'templates/alegra-modal-form.php');
    }


    //Render the custom fields to the user
    public function alegra_wc_user_custom_fields_markup($user)
    {
        $alegra_user_id = esc_attr(get_user_meta($user->ID, 'alegra_user_id', true));
        $alegra_user_tax_id = esc_attr(get_user_meta($user->ID, 'alegra_user_tax_id', true));
        $alegra_user_document_type = esc_attr(get_user_meta($user->ID, 'alegra_user_document_type', true));
?>
        <h3>Alegra Custom Fields</h3>
        <table class="form-table">
            <tr>
                <th>
                    <label for="alegra_user_id">Alegra User ID</label>
                </th>
                <td>
                    <input type="text" name="alegra_user_id" id="alegra_user_id" value="<?php echo $alegra_user_id; ?>" class="small-text">
                    <p class="description">This is the user ID on Alegra. <?php if (!empty($alegra_user_id)) { ?><a href="https://app.alegra.com/client/view/id/<?php echo $alegra_user_id; ?>">View on Alegra</a><?php } ?></p>
                </td>
            </tr>
            <tr>
                <th>
                    <label for="alegra_user_document_type">Alegra User Document Type</label>
                </th>
                <td>
                    <select name="alegra_user_document_type" id="alegra_user_document_type">
                        <option value="RNC" <?php selected($alegra_user_document_type, 'RNC'); ?>>RNC</option>
                        <option value="CED" <?php selected($alegra_user_document_type, 'CED'); ?>>Cédula</option>
                        <option value="IE" <?php selected($alegra_user_document_type, 'IE'); ?>>Pasaporte</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th>
                    <label for="alegra_user_tax_id">Alegra User Tax ID</label>
                </th>
                <td>
                    <input type="text" name="alegra_user_tax_id" id="alegra_user_tax_id" value="<?php echo $alegra_user_tax_id; ?>" class="medium-text">
                </td>
            </tr>

            <tr>
                <th>
                    <label for="alegra_wc_sync_button">Sync to Alegra</label>
                </th>
                <td>
                    <button type="button" id="alegra_wc_sync_button" class="button hide-if-no-js alegra_wc_sync_button" aria-expanded="false" data-post-id="<?php echo esc_attr($user->ID) ?>" data-object-type="Contact" data-sync-type="all" data-force-sync="no">Sync <?php echo $user->display_name  ?> to Alegra</button>


                </td>
            </tr>
        </table>
    <?php
    }

    public function alegra_wc_save_user_custom_fields($user_id)
    {
        if (current_user_can('edit_user', $user_id)) {
            update_user_meta($user_id, 'alegra_user_id', sanitize_text_field($_POST['alegra_user_id']));
            update_user_meta($user_id, 'alegra_user_tax_id', sanitize_text_field($_POST['alegra_user_tax_id']));
            update_user_meta($user_id, 'alegra_user_document_type', sanitize_text_field($_POST['alegra_user_document_type']));
        }
    }

    // Save the custom order data when the order is updated
    public function alegra_wc_save_settings_order_data($order_id)
    {

        $AlegraSync = new AlegraWCSync();

        if (empty($order_id)) {
            //Maybe was called from ajax, get the order id from a jquery parameter
            $order_id = $_POST['order_id'];
        };

        $AlegraSync->alegra_wc_save_custom_order_data($order_id);
    }

    // Save the custom order data when the order is updated
    public function save_wc_order_as_fiscal()
    {

        $alegraSync = new AlegraWCSync();

        $order_id = $_POST['order_id'];
        //First, update the order data, that's the source of truth

        if (isset($_POST['comprobante_fiscal'])) {
            update_post_meta($order_id, 'comprobante_fiscal', sanitize_text_field($_POST['comprobante_fiscal']));
        }

        if (isset($_POST['alegra_order_document_id'])) {
            update_post_meta($order_id, 'alegra_order_document_id', sanitize_text_field($_POST['alegra_order_document_id']));
        }

        if (isset($_POST['alegra_order_type'])) {
            update_post_meta($order_id, 'alegra_order_type', sanitize_text_field($_POST['alegra_order_type']));
        }

        if (isset($_POST['alegra_order_document_type'])) {
            update_post_meta($order_id, 'alegra_order_document_type', sanitize_text_field($_POST['alegra_order_document_type']));
        }

        $order = wc_get_order($order_id);

        $user_id = $order->get_customer_id();

        //This will either update or create a user in Alegra.
        $user_call_response = $alegraSync::alegra_wc_create_contact($user_id, $order);

        if (($user_call_response['success'])) {

            AlegraWCSync::alegra_log(__METHOD__ . "(): " . 'Contact updated succesfully. Updating Invoice... ');

            $invoice_call_response = $alegraSync->alegra_wc_create_invoice($order_id);

            if (($invoice_call_response['success'])) {

                AlegraWCSync::alegra_log(__METHOD__ . "(): " . 'Invoice updated succesfully.');

                wp_send_json_success($invoice_call_response['data']);
            } else {

                wp_send_json_error($invoice_call_response['data']);
            }
        } else {

            wp_send_json_error($user_call_response['data']);
        }
    }



    // Add a custom settings tab to WooCommerce
    public function alegra_wc_add_settings_tab($settings_tabs)
    {
        $settings_tabs['alegra_settings'] = 'Alegra Settings';
        return $settings_tabs;
    }

    // Add a custom settings tab to WooCommerce
    public function alegra_wc_sections_content()
    {
        global $current_section;
        $sections = array(
            'general' => 'General',
            'orders'  => 'Orders',
            'products' => 'Products'
        );

        echo '<ul class="subsubsub">';

        foreach ($sections as $id => $label) {
            $url = add_query_arg(
                array(
                    'page' => 'wc-settings',
                    'tab' => 'alegra_settings',
                    'section' => $id,
                ),
                admin_url('admin.php')
            );

            $current = $current_section == $id ? 'class="current"' : '';

            $keys = array_keys($sections);
            $separator = end($keys) === $id ? '' : '|';

            echo "<li><a href=\"$url\" $current>$label</a> $separator </li>";
        }

        echo '</ul><br class="clear" />';
    }


    public function get_alegra_settings()
    {
            $section = (isset($_GET['section']) ? $_GET['section'] : 'general' );

            switch ($section) {
                case 'general':
                    $settings = array(
                        'section_title' => array(
                            'name'     => 'API Keys',
                            'type'     => 'title',
                            'desc'     => 'Set up the Alegra API Keys here.',
                            'id'       => 'alegra_wc_settings_api_settings'
                        ),
                        'username' => array(
                            'name' => 'Username',
                            'type' => 'text',
                            'desc' => 'This is usually the User Email of the Alegra Account.',
                            'id'   => 'alegra_wc_user',
                            'custom_attributes' => array('required' => 'required')
                        ),
                        'token' => array(
                            'name' => 'Token',
                            'type' => 'text',
                            'desc' => 'Can be found in <a href="https://mi.alegra.com/integrations/api"> your Alegra Settings.</a>',
                            'id'   => 'alegra_wc_token',
                            'custom_attributes' => array('required' => 'required')
                        ),
                        'terms' => array(
                            'name' => 'Terms and Contitions',
                            'type' => 'textarea',
                            'desc' => 'This will be visible at the bottom of the invoice.',
                            'id'   => 'alegra_wc_tyc'
                        ),
                        'annotations' => array(
                            'name' => 'Annotations / Comments',
                            'type' => 'textarea',
                            'desc' => 'This will be visible at the bottom of the invoice.',
                            'id'   => 'alegra_wc_annotations'
                        ),
                        'debugMode' => array(
                            'name' => 'Debug Mode?',
                            'type' => 'checkbox',
                            'desc' => 'Enable advanced debugging in WooCommerce Logs.',
                            'id'   => 'alegra_wc_debug'
                        ),
                        'section_end' => array(
                            'type' => 'sectionend',
                            'id' => 'alegra_wc_settings_invoice_settings_end'
                        ),
                    );
                    break;
                case 'orders':
                    $settings = array(
                        'section_title' => array(
                            'name'     => 'Order Settings',
                            'type'     => 'title',
                            'desc'     => 'Set up how orders should be addressed in Alegra.',
                        ),
                        'send_orders_to_alegra' => array(
                            'name' => 'Should all orders go to Alegra Automatically?',
                            'type' => 'checkbox',
                            'desc' => 'Check this box if all orders should be created in Alegra Automatically. Uncheck it if you need to review them first.',
                            'id'   => 'send_orders_to_alegra'
                        ),
                        'section_end' => array(
                            'type' => 'sectionend'
                        ),
                    );
                    break;
                case 'products':
                    $settings = array(
                        'section_title' => array(
                            'name'     => 'Product Settings',
                            'type'     => 'title',
                            'desc'     => 'Set up how Products should be addressed in Alegra.',
                        ),
                        'included_categories_for_alegra' => array(
                            'name' => 'Categories that will be sent to alegra',
                            'type' => 'multiselect',
                            'desc' => 'description',
                            'id'   => 'included_categories_for_alegra',
                            'css'      => 'min-width:300px;',
                            'std'      => array(),
                            'options'  => $this->alegra_wc_get_product_categories(),
                            'desc_tip' => true,
                        ),
                        'auto_create_categories_to_alegra' => array(
                            'name' => 'Should all Product Categories go to Alegra Automatically?',
                            'type' => 'checkbox',
                            'desc' => 'Check this box if all categories should be created in Alegra Automatically. Product Categories are optional in Alegra.',
                            'id'   => 'auto_create_categories_to_alegra',
                            'desc_tip' => true,
                        ),
                        'alegra_inventory_adjustment_delay' => array(
                            'name' => 'Sync Inventory Delay',
                            'type' => 'number',
                            'default' => 24,
                            'desc' => 'Define how often it should trigger the Inventory check, in hours. The default value is 24.',
                            'id'   => 'alegra_inventory_adjustment_delay',
                            'desc_tip' => true,
                            'class' => 'small-text',
                            'custom_attributes' => array('required' => 'required')
                        ),
                        'alegra_inventory_adjustment_trigger' => array(
                            'name' => 'Sync Inventory Adjustment',
                            'type' => 'button',
                            'desc' => 'Trigger the sync between inventory adjustments.',
                            'id'   => 'alegra_inventory_adjustment_trigger',
                            'desc_tip' => true,
                            'class' => 'button'
                        ),
                        'section_end' => array(
                            'type' => 'sectionend'
                        ),
                    );
                    break;
                    //Add more tabs for the settings here
            }
        
        return $settings;
    }

    //Custom Setting field for WC backend

    public function alegra_wc_render_button_settings($data)
    {



        $defaults = array(
            'class'             => 'button-secondary',
            'css'               => '',
            'custom_attributes' => array(),
            'desc_tip'          => false,
            'description'       => '',
            'title'             => '',
        );

        $data = wp_parse_args($data, $defaults);

    ?>
        <tr valign="top">
            <th scope="row" class="titledesc">
                <label for="<?php echo esc_attr($data['id']); ?>"><?php echo wp_kses_post($data['title']); ?></label>
            </th>
            <td class="forminp">
                <fieldset>
                    <legend class="screen-reader-text"><span><?php echo wp_kses_post($data['title']); ?></span></legend>
                    <button class="<?php echo esc_attr($data['class']); ?>" type="button" name="<?php echo esc_attr($data['id']); ?>" id="<?php echo esc_attr($data['id']); ?>" style="<?php echo esc_attr($data['css']); ?>"><?php echo wp_kses_post($data['title']); ?></button>
                    <p class="description"><?php echo $data['desc']; ?></p>

                </fieldset>
            </td>
        </tr>
<?php

    }

    // Function to get product categories
    public function alegra_wc_get_product_categories()
    {
        $all_categories = get_terms('product_cat', array('hide_empty' => false));
        $category_options = array();

        foreach ($all_categories as $category) {
            $category_options[$category->term_id] = $category->name;
        }

        return $category_options;
    }
    // Create the content for the custom settings tab
    public function alegra_wc_settings_tab()
    {
        woocommerce_admin_fields($this->get_alegra_settings());
    }

    // Add settings sections and fields to the custom tab
    public function alegra_wc_register_settings()
    {
        woocommerce_update_options($this->get_alegra_settings());
    }

    // Add the custom button inside the variation accordion
    public function alegra_wc_add_inventory_adjustment_button($loop, $variation_data, $variation)
    {
        echo '<p class="form-field"><button class="alegra-inventory-adjustment-btn" data-variation-id="' . esc_attr($variation->ID) . '" data-user-id="' . get_current_user_id() . '">Adjust Inventory</button></p>';
    }

    public function alegra_wc_handle_inventory_adjustment($variation_id, $new_stock, $previous_stock, $alegra_unit_cost)
    {

        $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : '';

        // Calculate the difference between new stock and previous stock
        $stock_difference = $new_stock - $previous_stock;

        // Determine if it's an increase or decrease
        $operation = $stock_difference > 0 ? 'in' : 'out';

        // Absolute value of the stock difference for adjustment
        $stock_adjustment = abs($stock_difference);

        AlegraWCSync::alegra_log(__METHOD__ . "(): Adjusting Inventory for Variation ID => " . $variation_id);

        AlegraWCSync::alegra_wc_create_inventory_adjustment($variation_id, $operation, $stock_adjustment, $alegra_unit_cost, $user_id);

        return;
    }


    public function alegra_wc_tools($tools)
    {

        $alegra_sync_all_products = array(
            'alegra_sync_all_products' => array(
                'name'     => 'Sync All Products with Alegra',
                'button'   => 'Sync All Products',
                'desc'     => 'This will attempt to sync ALL products to Alegra. It might take a few minutes to complete.',
                'callback' => array($this, 'alegra_sync_all_products'),
                'disabled' => false,
            ),
        );

        $alegra_sync_all_categories = array(
            'alegra_sync_all_categories' => array(
                'name'     => 'Sync All Categories with Alegra',
                'button'   => 'Sync All Categories',
                'desc'     => 'This will attempt to sync ALL Categories to Alegra. It might take a few minutes to complete.',
                'callback' => array($this, 'alegra_sync_all_categories'),
                'disabled' => false,
            ),
        );

        $alegra_clear_all_alegra_data = array(
            'alegra_clear_all_alegra_data' => array(
                'name'     => 'Remove all Alegra Sync Meta Data ⚠️',
                'button'   => 'Remove Attributes',
                'desc'     => 'This will remove all the metadata about Alegra from all products. Backup your database.',
                'callback' => array($this, 'alegra_clear_all_alegra_data'),
                'disabled' => false,
            ),
        );

        //This brings our tools higher in the order in Woocommerce
        $tools = array_slice($tools, 0, 2, true) + $alegra_sync_all_products +  $alegra_sync_all_categories + $alegra_clear_all_alegra_data + array_slice($tools, 2, NULL, true);

        return $tools;
    }


    public function alegra_sync_all_products()
    {

        AlegraWCSync::alegra_log(__METHOD__ . "(): " . "Syncing all products to WooCommerce started...");

        $args = array(
            'post_type' => array('product'),
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'fields' => 'ids',
            'no_found_rows' => 1
        );

        $query = new WP_Query($args);

        if ($query->have_posts()) {
            wp_reset_postdata();
            $AlegraWCSync = new AlegraWCSync();
            while ($query->have_posts()) : $query->the_post();
                $product_id = get_the_ID();
                $schedule_id = $AlegraWCSync->alegra_wc_create_product($product_id, true);
            endwhile;
        } else {
            return 'the query is empty';
        }

        return "Syncing all products to WooCommerce started.... Check the logs for details.";
    }

    public function alegra_sync_all_categories()
    {

        AlegraWCSync::alegra_log(__METHOD__ . "(): " . "Syncing all categories to WooCommerce started...");

        $args = array(
            'taxonomy' => 'product_cat', // Use 'product_cat' taxonomy to get product categories
            'hide_empty' => false,
            'fields' => 'ids',
        );

        $categories = get_terms($args);

        if (!empty($categories)) {
            $AlegraWCSync = new AlegraWCSync();
            foreach ($categories as $category_id) {
                $schedule_id = $AlegraWCSync->alegra_wc_create_category($category_id, true);
                AlegraWCSync::alegra_log(__METHOD__ . "(): " . "Scheduled Category " . $category_id . " with Schedule ID " . $schedule_id);
            }
        } else {
            AlegraWCSync::alegra_log(__METHOD__ . "(): " . "No product Categories found.", 'notice');
            return 'No product categories found.';
        }

        return "Syncing all categories to WooCommerce completed. Check the logs for details.";
    }




    public function alegra_clear_all_alegra_data()
    {
        AlegraWCSync::alegra_log(__METHOD__ . "(): " . "Clearing all Alegra Data from WooCommerce started...");

        global $wpdb;

        // Array of custom meta keys added by your plugin
        $custom_meta_keys = array(
            'wc_alegra_sync_status',
            'wc_alegra_last_synced',
            'wc_alegra_product_id',
            'wc_alegra_unit_cost',
            'wc_alegra_product_unit',
            'wc_alegra_product_category',
            'wc_alegra_variation_id',
            'alegra_order_document_id',
            'alegra_order_type',
            'alegra_order_document_type',
            'alegra_invoice_id',
            'alegra_invoice_date_created',
            'comprobante_fiscal',
        );

        // Array of custom meta keys added by your plugin for users
        $user_meta_keys = array(
            'alegra_user_tax_id',
            'alegra_user_document_type'
        );

        // Delete meta data for each key
        foreach ($custom_meta_keys as $meta_key) {
            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s",
                    $meta_key
                )
            );
        }

        foreach ($user_meta_keys as $meta_key) {
            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$wpdb->usermeta} WHERE meta_key = %s",
                    $meta_key
                )
            );
        }
        return "Clearing all Alegra Data from WooCommerce started... Check the logs for details.";
    }

    public function alegra_tools_post_execution($tool)
    {

        if (substr($tool['id'], 0, 7) === "alegra_") {

            AlegraWCSync::alegra_log(__METHOD__ . "(): " . $tool['name'] . " completed successfully. ");


            echo '<div class="updated"><p>' .  $tool['name'] . " completed successfully. " . '</p></div>';
        }
    }

    public function alegra_wc_return_100_items()
    {
        return 500;
    }
}
