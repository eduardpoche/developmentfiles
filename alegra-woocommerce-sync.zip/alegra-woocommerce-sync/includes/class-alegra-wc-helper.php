<?php
class Alegra_WC_Helper
{

    /**
     * Checks if a WooCommerce product is synced in Alegra based on a custom field.
     * Returns the Alegra product ID if found, 0 if not found, and logs any errors.
     * 
     * @param int $product_id WooCommerce product ID to check.
     * @return int Alegra product ID or 0 if not synced or error.
     */
    public static function get_alegra_product_id_by_wc_id($product_id)
    {
        $custom_field_id = get_option('alegra_wc_custom_field_id');
        if (!$custom_field_id) {
            Alegra_WC_Logs::log(__METHOD__, 'No custom field ID stored in options. Creating it...', 'warning');
            //Rare case, but the custom field should exist already.
            $alegra_wc_custom_field_id = Alegra_WC_Sync::create_alegra_custom_field();

            if ($alegra_wc_custom_field_id) {
                $custom_field_id = $alegra_wc_custom_field_id;
            }
        }

        $response = Alegra_WC_API::alegra_wc_api_request(
            'GET',
            'items?metadata=true&customField_id=' . $custom_field_id . '&customField_value=' . $product_id
        );

        if (is_wp_error($response)) {
            Alegra_WC_Logs::log(__METHOD__, 'API request error: ' . $response['data'], 'error');
            return 0;
        }

        if (in_array($response['code'], [200, 201]) && isset($response['data']['metadata']['total']) && $response['data']['metadata']['total'] == 1) {
            return $response['data']['data'][0]['id'];
        } elseif ($response['code'] == 404) {
            Alegra_WC_Logs::log(__METHOD__, 'Custom Field not found in Alegra.', 'warning');
            return 0;
        } else {
            Alegra_WC_Logs::log(__METHOD__, 'Product not found in Alegra. ', 'error');
            return 0;
        }
    }

    /**
     * Determine the appropriate API endpoint and HTTP method for syncing products.
     * 
     * @param int $product_id WooCommerce product ID.
     * @param string $force_sync Flag to force sync as a new product.
     * @return array Contains 'endpoint' and 'request_type' for API call.
     */
    public static function determine_sync_method($alegra_product_id, $force_sync)
    {

        if ($force_sync === 'yes') {
            return [
                'endpoint' => 'items',
                'request_type' => 'POST'
            ];
        }

        if ($alegra_product_id > 0) {
            return [
                'endpoint' => 'items/' . $alegra_product_id,
                'request_type' => 'PUT'
            ];
        }

        return [
            'endpoint' => 'items',
            'request_type' => 'POST'
        ];
    }
}
