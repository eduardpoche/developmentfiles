<?php 

class Alegra_WC_Taxes {

/**
 * Retrieves the WooCommerce tax class corresponding to a specific tax rate.
 * 
 * @param string $rate The tax rate to match.
 * @return string The tax class if found, otherwise an empty string.
 */
public static function get_tax_class_by_rate($rate) {
    $formatted_rate = number_format((float)$rate, 4); // Format the rate to match WooCommerce formatting
    $tax_classes = WC_Tax::get_tax_classes();
    foreach ($tax_classes as $tax_class) {
        $tax_rates = WC_Tax::get_rates_for_tax_class($tax_class);
        foreach ($tax_rates as $rate_details) {
            if ($rate_details->tax_rate === $formatted_rate) {
                return $rate_details->tax_rate_class;
            }
        }
    }
    return ''; // Return an empty string if no matching tax class is found
}

/**
 * Apply the tax class to any object that supports set_tax_class method.
 *
 * @param mixed $object The cart item or product object.
 * @param string $tax_class The tax class to apply.
 * @return void
 */
public static function apply_tax_class($object, $tax_class) {
    if (method_exists($object, 'set_tax_class')) {
        $object->set_tax_class($tax_class);
    }
}
}
