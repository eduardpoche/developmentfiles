<?php

class Alegra_WC_API
{
    const ALEGRA_API_URL = 'https://api.alegra.com/api/v1/';

    public function __construct()
    {
        add_action('rest_api_init', array($this, 'register_alegra_webhook_endpoint'));
    }

    public function register_alegra_webhook_endpoint()
    {
        register_rest_route('alegra/v1', '/webhook', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_alegra_webhook'),
            'permission_callback' => '__return_true'  // This allows the request without authentication, consider securing this
        ));
    }

    // Public method to make API requests to Alegra
    public static function alegra_wc_api_request($request_type, $endpoint, $content = array())
    {
        // Generate the authorization string using the existing method
        $authorization = self::alegra_wc_generate_authstring();

        // Check if the authorization string is available
        if (!$authorization) {
            Alegra_WC_Logs::log('Authorization string is missing. Please check Alegra credentials.', 'error');
            return array(
                'code'    => 'auth_error',
                'data' => array(
                    'message' => __('Falló la autorización. Por favor revise sus credenciales de Alegra.', 'alegra-wc-sync')
                )
            );
        }

        // Define the API URL by appending the endpoint to the base URL
        $api_url = self::ALEGRA_API_URL . $endpoint;

        // Set up the request arguments
        $args = array(
            'method'      => $request_type,
            'timeout'     => 45,
            'headers'     => array(
                'accept'   => 'application/json',
                'Authorization' => 'Basic ' . $authorization, // Use the generated authorization string
                'Content-Type'  => 'application/json',
            ),
        );

        // Add content to the request for POST, PUT, and PATCH requests
        if (in_array($request_type, array('POST', 'PUT', 'PATCH'))) {
            $args['body'] = json_encode($content);
        }

        // Make the API request
        $response = wp_remote_request($api_url, $args);
        // Check for errors
        if (is_wp_error($response)) {
            // Handle WP error
            return array(
                'code'    => 'wp_error',
                'data' => $response->get_error_message(),
            );
        }

        // Get the response code
        $response_code = wp_remote_retrieve_response_code($response);

        // Get the response body as JSON
        $response_body = wp_remote_retrieve_body($response);
        $response_data = json_decode($response_body, true);

        if (isset($response_data['message']) && $response_data['message'] == 'Unauthorized') {
            $response_data['message'] = __('No se puede conectar con Alegra. Las credenciales proporcionadas son incorrectas. Por favor verifique sus credenciales.', 'alegra-wc-sync');
        }

        return array(
            'code' => $response_code,
            'data' => $response_data
        );
    }

    // Function to generate the Alegra API authorization string
    public static function alegra_wc_generate_authstring()
    {
        $alegra_wc_user = get_option('alegra_wc_user'); // Get the Alegra user (email) from settings
        $alegra_wc_token = get_option('alegra_wc_token'); // Get the Alegra token from settings

        // Check if both user and token are set
        if (!empty($alegra_wc_user) && !empty($alegra_wc_token)) {
            // Concatenate user and token with a semicolon
            $credentials = $alegra_wc_user . ':' . $alegra_wc_token;

            // Encode in base64
            $authorization_string = base64_encode($credentials);

            return $authorization_string;
        }

        return false; // Return false if user or token is empty
    }

    public function handle_alegra_webhook(WP_REST_Request $request)
    {
        $data = $request->get_json_params();

        //Determine what to do with new clients and products here.
        // Process the data according to the subject
        if (isset($data['subject'])) {
            switch ($data['subject']) {
                case 'new-item':
                    $this->process_new_item($data['message']);
                case 'new-client':
                    $this->process_new_client($data['message']);
                case 'new-invoice':
                    $this->process_new_invoice($data['message']);
                default:
                    return new WP_REST_Response('Invalid Subject.', 500);
            }
        } else {
            return new WP_REST_Response('Howdy', 200);  //P3 We don't want to listen on this endpoint if we are already set up.

        }
    }

    private function process_new_item($item_data)
    {
        // Assuming $item_data is already the item part of the message
        Alegra_WC_Logs::log('A new Product was created in Alegra. => ' . print_r($item_data, true), 'info');
        //##Creation processing goes here##.
        return new WP_REST_Response('Product processed successfully', 200);
    }

    private function process_new_client($client_data)
    {
        // Handle new client creation logic here
        Alegra_WC_Logs::log('A new client was created in Alegra. => ' . print_r($client_data, true), 'info');
        //##Creation processing goes here##.
        return new WP_REST_Response('Client processed successfully', 200);
    }

    private function process_new_invoice($invoice_data)
    {
        // Handle new invoice creation logic here
        Alegra_WC_Logs::log('A new Invoice was created in Alegra. => ' . print_r($invoice_data, true), 'info');
        //##Creation processing goes here##.
        return new WP_REST_Response('Invoice processed successfully', 200);
    }

    public static function register_and_store_webhook()
    {
        $option_key = 'alegra_webhook_subscription';
        $webhook_info = get_option($option_key);

        // Check if webhooks are already registered
        if (!$webhook_info) {
            $webhook_info = [];  // Initialize to store multiple webhook responses

            // List of events to register webhooks for
            $events = [
                'new-item',
                'new-client',
                'new-invoice'
            ];

            $base_url = preg_replace('#^https?://#', '', get_site_url()) . '/wp-json/alegra/v1/webhook';

            foreach ($events as $event_type) {
                $event = [
                    'event' => $event_type,
                    'url'   => $base_url
                ];

                $call_response = self::alegra_wc_api_request('POST', 'webhooks/subscriptions', $event);

                if (in_array($call_response['code'], array(200, 201)) && isset($call_response['data']['subscription'])) {
                    // If registration is successful, store each subscription in the array
                    $webhook_info[$event_type] = $call_response['data']['subscription'];
                    Alegra_WC_Logs::log(__METHOD__, 'Successfully registered a listener for ' . $event_type . ' Alegra Webhooks. ID => ' . $call_response['data']['subscription']['id']);
                } else {
                    // Log errors for each event
                    Alegra_WC_Logs::log(__METHOD__, 'Webhook Registration Failed for ' . $event_type . '. ' . print_r($call_response, true), 'error');
                }
            }

            // Update the stored option with all subscription data
            update_option($option_key, serialize($webhook_info));
            $response['data'] = 'Successfully registered listeners for Alegra Webhooks. ' . json_encode($webhook_info, true);
        } else {
            $response['data'] = 'The webhooks are already registered. ' . json_encode($webhook_info);
        }

        return $response;
    }

    public static function unregister_webhooks()
    {
        $option_key = 'alegra_webhook_subscription';
        $webhook_info = get_option($option_key);

        // Check if webhooks are already registered
        if ($webhook_info) {
            $webhook_info = unserialize($webhook_info);
            $errors = [];

            foreach ($webhook_info as $event_type => $subscription) {
                $endpoint = 'webhooks/subscriptions/' . $subscription['id'];
                $call_response = self::alegra_wc_api_request('DELETE', $endpoint);

                if (in_array($call_response['code'], [200, 201, 204])) { // 204 No Content for successful DELETE
                    Alegra_WC_Logs::log(__METHOD__, 'Successfully unregistered a listener for ' . $event_type . ' Alegra Webhooks. ID => ' . $subscription['id']);
                } else {
                    $errors[$event_type] = $call_response;
                    Alegra_WC_Logs::log(__METHOD__, 'Webhook Unregistration Failed for ' . $event_type . '. ' . print_r($call_response, true), 'error');
                }
            }
            // Clear the option if all webhooks were successfully unregistered
            if (empty($errors)) {
                delete_option($option_key);
                $response['data'] = 'All webhooks successfully unregistered.';
            } else {
                $response['data'] = 'Errors occurred while unregistering some webhooks: ' . json_encode($errors);
            }
        } else {
            $response['data'] = 'No webhooks registered or already cleared.';
        }

        return $response;
    }
}

// Instantiate the class
new Alegra_WC_API();
