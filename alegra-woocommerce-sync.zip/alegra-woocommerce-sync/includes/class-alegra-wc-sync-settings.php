<?php

if (!class_exists('Alegra_WC_Settings')) {

    class Alegra_WC_Settings extends WC_Settings_Page
    {

        /**
         * Constructor.
         */
        public function __construct()
        {
            $this->id    = 'alegra_settings';
            $this->label = __('Ajustes de Alegra', 'alegra-wc-sync');

            //Add our custom tab
            add_filter('woocommerce_settings_tabs_array', array($this, 'alegra_add_settings_tab'), 20);

            // Add new section to the page
            add_action('woocommerce_sections_' . $this->id, array($this, 'output_sections'));

            add_action('woocommerce_settings_' . $this->id, array($this, 'output'));

            add_action('woocommerce_settings_save_' . $this->id, array($this, 'save'));

            //Custom fields for admin rendering
            add_action('woocommerce_admin_field_button', [$this, 'alegra_wc_render_button_settings']);
            add_action('woocommerce_admin_field_hidden', [$this, 'alegra_wc_render_hidden_settings']);
            add_action('woocommerce_admin_field_alegra_connection_status', [$this, 'alegra_connection_status_field']);
        }

        public function alegra_add_settings_tab($settings_tabs)
        {
            $settings_tabs['alegra_settings'] = __('Ajustes de Alegra', 'alegra-wc-sync');
            return $settings_tabs;
        }

        /**
         * Get sections.
         */
        public function get_sections()
        {
            $sections = array(
                ''              => __('General', 'alegra-wc-sync'),
                'orders'        => __('Pedidos', 'alegra-wc-sync'),
                'products'      => __('Productos', 'alegra-wc-sync'),
                'webhooks'      => __('Webhooks', 'alegra-wc-sync'),
                'dgii-consultation' => __('Consulta DGII', 'alegra-wc-sync'),
            );

            return apply_filters('woocommerce_get_sections_' . $this->id, $sections);
        }

        /**
         * Output the settings.
         */
        public function output()
        {
            global $current_section;
            $settings = $this->get_settings($current_section);
            WC_Admin_Settings::output_fields($settings);
        }

        /**
         * Save settings.
         */
        public function save()
        {
            global $current_section;
            $settings = $this->get_settings($current_section);
            WC_Admin_Settings::save_fields($settings);
        }

        /**
         * Returns the settings for the current section.
         */
        public function get_settings($section = '')
        {

            switch ($section) {
                case 'orders':
                    $settings = array(
                        'section_title' => array(
                            'name'     => __('Ajustes de la Orden', 'alegra-wc-sync'),
                            'type'     => 'title',
                            'desc'     => __('Configure como deben comportarse las órdenes al crearse en Alegra.', 'alegra-wc-sync'),
                        ),
                        'send_orders_to_alegra' => array(
                            'name' => __('Crear órdenes automáticamente en Alegra?', 'alegra-wc-sync'),
                            'type' => 'checkbox',
                            'desc' => __('Marque esta casilla si todos los pedidos deben crearse en Alegra automáticamente. Desmárquelo si necesita revisarlos en la tienda primero.', 'alegra-wc-sync'),
                            'id'   => 'send_orders_to_alegra'
                        ),
                        'create_fiscal_order_in_alegra' => array(
                            'name' => __('Facturar pedidos automáticamente en Alegra?', 'alegra-wc-sync'),
                            'type' => 'checkbox',
                            'desc' => __('Los pedidos se crean como facturas en borrador en Alegra. Marque esta casilla para crear las facturas como definitivas (requiere <a href="https://app.alegra.com/fedom-wizard" target="_blank">Facturación Electronica</a> configurada). ', 'alegra-wc-sync'),
                            'id'   => 'create_fiscal_order_in_alegra'
                        ),
                        'terms' => array(
                            'name' => __('Términos y Condiciones', 'alegra-wc-sync'),
                            'type' => 'textarea',
                            'desc' => __('Esta información estará disponible al pie de la factura', 'alegra-wc-sync'),
                            'id'   => 'alegra_wc_tyc'
                        ),
                        'annotations' => array(
                            'name' => __('Notas / Comentarios', 'alegra-wc-sync'),
                            'type' => 'textarea',
                            'desc' => __('Esta información estará disponible al pie de la factura', 'alegra-wc-sync'),
                            'id'   => 'alegra_wc_annotations'
                        ),
                        'section_id' => array(
                            'id' => 'section_id',
                            'type' => 'hidden',
                            'value' => 'orders'  // This value identifies the section
                        ),
                        'section_end' => array(
                            'type' => 'sectionend'
                        ),
                    );
                    break;
                case 'products':
                    $settings = array(
                        'section_title' => array(
                            'name'     => 'Ajustes de Producto',
                            'type'     => 'title',
                            'desc'     => __('Configure como deben comportarse los productos al crearse en Alegra.', 'alegra-wc-sync'),
                        ),
                        'included_categories_for_alegra' => array(
                            'name' => __('Categorías permitidas para enviar a Alegra', 'alegra-wc-sync'),
                            'type' => 'multiselect',
                            'desc' => __('Introduzca aquí las categorías específicas que están permitidas para ser enviadas a Alegra. Si lo deja en blanco, todas estarán permitidas.', 'alegra-wc-sync'),
                            'id'   => 'included_categories_for_alegra',
                            'css'      => 'min-width:300px;',
                            'std'      => array(),
                            'options'  => $this->alegra_wc_get_product_categories(),
                            'desc_tip' => true,
                        ),
                        'auto_create_categories_to_alegra' => array(
                            'name' => __('Crear categorías automáticamente?', 'alegra-wc-sync'),
                            'type' => 'checkbox',
                            'desc' => __('Marque esta casilla si todas las categorías deben crearse en Alegra automáticamente. Las Categorías de Productos son opcionales en Alegra.', 'alegra-wc-sync'),
                            'id'   => 'auto_create_categories_to_alegra',
                            'desc_tip' => true,
                        ),
                        array(
                            'title' => __('Sincronización de Productos desde Alegra', 'text-domain'),
                            'id' => 'alegra_inventory_sync_section',
                            'type' => 'title',
                            'desc' => 'Configure las opciones para obtener los productos desde Alegra.',
                        ),
                        'alegra_inventory_sync' => array(
                            'name' => __('Sincronizar Inventario desde Alegra', 'alegra-wc-sync'),
                            'type' => 'checkbox',
                            'desc' => 'Habilite para sincronizar periodicamente su inventario desde Alegra.',
                            'id'   => 'alegra_inventory_sync',
                            'default' => 'no',
                            'desc_tip' => true
                        ),
                        'alegra_inventory_sync_delay' => array(
                            'name' => __('Retraso de Sincronización de Inventario', 'alegra-wc-sync'),
                            'type' => 'number',
                            'default' => 24,
                            'desc' => __('Defina con qué frecuencia debe activarse la sincronización de Inventario, en horas. El valor predeterminado es 24 horas.', 'alegra-wc-sync'),
                            'id'   => 'alegra_inventory_sync_delay',
                            'desc_tip' => true,
                            'class' => 'hidden_custom', // Add a custom class for hiding
                            'custom_attributes' => array(
                                'data-toggle' => 'alegra_inventory_sync', // Data attribute for linking with the checkbox
                            )
                        ),
                        'alegra_inventory_sync_trigger' => array(
                            'name' => __('Sincronizar Inventario Manualmente', 'alegra-wc-sync'),
                            'type' => 'button',
                            'desc' => 'Detona la sincronización de inventario manualmente. [Experimental]',
                            'id'   => 'alegra_inventory_sync_trigger',
                            'desc_tip' => true,
                            'class' => 'hidden_custom', // Add a custom class for hiding
                            'custom_attributes' => array(
                                'data-toggle' => 'alegra_inventory_sync', // Data attribute for linking with the checkbox
                            )
                        ),
                        'section_id' => array(
                            'id' => 'section_id',
                            'type' => 'hidden',
                            'value' => 'products'  // This value identifies the section
                        ),
                        'section_end' => array(
                            'type' => 'sectionend'
                        ),
                    );
                    break;
                case 'webhooks':
                    $settings = array(
                        'section_title' => array(
                            'name'     => 'Webhooks',
                            'type'     => 'title',
                            'desc'     => __('Configure la recepción de actualizaciones desde Alegra via Webhooks', 'alegra-wc-sync'),
                        ),
                        'receive_webhooks_from_alegra' => array(
                            'name' => __('Habilitar los Webhooks', 'alegra-wc-sync'),
                            'type' => 'checkbox',
                            'desc' => __('Marque esta casilla si desea recibir actualizaciones desde Alegra.', 'alegra-wc-sync'),
                            'default' => true,
                            'id'   => 'receive_webhooks_from_alegra',
                            'desc_tip' => true,
                        ),
                        'section_id' => array(
                            'id' => 'section_id',
                            'type' => 'hidden',
                            'value' => 'webhooks'  // This value identifies the section
                        ),
                        'section_end' => array(
                            'type' => 'sectionend'
                        ),
                    );
                    break;

                case 'dgii-consultation':
                    $settings = array(
                        'section_title' => array(
                            'name'     => 'Consulta a DGII',
                            'type'     => 'title',
                            'desc'     => __('Permite configurar la consulta a DGII de RNC al momento de crear una orden. ', 'alegra-wc-sync'),
                        ),
                        'enable_dgii_rnc_check' => array(
                            'name' => __('Habilitar la consulta a DGII', 'alegra-wc-sync'),
                            'type' => 'checkbox',
                            'desc' => __('Le permitirá consultar los RNCs o Cédulas antes de ingresar una orden. Este es un servicio adicional, consulte a soporte para activarlo.', 'alegra-wc-sync'),
                            'default' => false,
                            'id'   => 'enable_dgii_rnc_check',
                            'desc_tip' => true,
                        ),
                        'alegra_dgii_auth_user' => array(
                            'name' => __('Usuario para consultar DGII', 'alegra-wc-sync'),
                            'type' => 'text',
                            'desc' => __('Indique su usuario', 'alegra-wc-sync'),
                            'id'   => 'alegra_dgii_auth_user',
                            'desc_tip' => true,
                        ),
                        'alegra_dgii_auth_key' => array(
                            'name' => __('Clave de API para consultar DGII', 'alegra-wc-sync'),
                            'type' => 'password',
                            'desc' => __('Indique su clave de API', 'alegra-wc-sync'),
                            'id'   => 'alegra_dgii_auth_key',
                            'desc_tip' => true,
                        ),
                        'section_id' => array(
                            'id' => 'section_id',
                            'type' => 'hidden',
                            'value' => 'dgii-consultation'  // This value identifies the section
                        ),
                        'section_end' => array(
                            'type' => 'sectionend'
                        ),
                    );
                    break;
                default:
                    $settings = array(
                        'section_title' => array(
                            'name'     => __('Claves de API', 'alegra-wc-sync'),
                            'type'     => 'title',
                            'desc'     => __('Configure aquí sus claves de API de Alegra.', 'alegra-wc-sync'),
                            'id'       => 'alegra_wc_settings_api_settings'
                        ),
                        'username' => array(
                            'name' => __('Nombre de Usuario', 'alegra-wc-sync'),
                            'type' => 'text',
                            'desc' => __('Este es el correo electrónico de su cuenta de Alegra.', 'alegra-wc-sync'),
                            'id'   => 'alegra_wc_user',
                            'custom_attributes' => array('required' => 'required')
                        ),
                        'token' => array(
                            'name' => __('Token', 'alegra-wc-sync'),
                            'type' => 'text',

                            'desc' => /* translators: %s is the URL in Alegra */ sprintf(
                                __('Puede obtenerlo en sus <a target="_blank" href="%s">ajustes de Alegra.</a>', 'alegra-wc-sync'),
                                'https://mi.alegra.com/integrations/api'
                            ),
                            'id'   => 'alegra_wc_token',
                            'custom_attributes' => array('required' => 'required')
                        ),
                        'alegra_connection_status' => array(
                            'title' => __('Estatus de Conexión', 'text-domain'),
                            'id' => 'alegra_connection_status',
                            'class' => 'alegra_connection_status',
                            'type' => 'alegra_connection_status',
                            'custom_attributes' => array('readonly' => 'readonly')
                        ),
                        'debugMode' => array(
                            'name' => __('Modo de depuración?', 'alegra-wc-sync'),
                            'type' => 'checkbox',
                            'desc' => __('Habilite la depuración avanzada para ver registros detallados del funcionamiento del complemento.', 'alegra-wc-sync'),
                            'id'   => 'alegra_wc_debug'
                        ),
                        array(
                            'id' => 'section_id',
                            'type' => 'hidden',
                            'value' => 'general'  // This value identifies the section
                        ),
                        'section_end' => array(
                            'type' => 'sectionend',
                            'id' => 'alegra_wc_settings_invoice_settings_end'
                        ),
                    );
                    break;
                    //Add more tabs for the settings here
            }

            return apply_filters('woocommerce_get_settings_' . $this->id, $settings, $section);
        }

        // Function to get product categories
        public function alegra_wc_get_product_categories()
        {
            $all_categories = get_terms('product_cat', array('hide_empty' => false));
            $category_options = array();

            foreach ($all_categories as $category) {
                $category_options[$category->term_id] = $category->name;
            }

            return $category_options;
        }


        //Custom Setting field for WC backend
        public function alegra_wc_render_button_settings($data)
        {

            $defaults = array(
                'class'             => 'button-secondary',
                'css'               => '',
                'custom_attributes' => array(),
                'desc_tip'          => false,
                'description'       => '',
                'title'             => '',
            );

            $data = wp_parse_args($data, $defaults);

            // Building the custom attributes string
            $custom_attributes_string = '';
            foreach ($data['custom_attributes'] as $attribute => $value) {
                $custom_attributes_string .= esc_attr($attribute) . '="' . esc_attr($value) . '" ';
            }

?>
            <tr valign="top">
                <th scope="row" class="titledesc">
                    <label for="<?php echo esc_attr($data['id']); ?>"><?php echo wp_kses_post($data['title']); ?></label>
                </th>
                <td class="forminp">
                    <fieldset>
                        <legend class="screen-reader-text"><span><?php echo wp_kses_post($data['title']); ?></span></legend>
                        <button class="<?php echo esc_attr($data['class']); ?>" type="button" name="<?php echo esc_attr($data['id']); ?>" id="<?php echo esc_attr($data['id']); ?>" style="<?php echo esc_attr($data['css']); ?>" <?php echo $custom_attributes_string; ?>><?php echo wp_kses_post($data['title']); ?></button>
                        <p class="description"><?php echo $data['desc']; ?></p>

                    </fieldset>
                </td>
            </tr>
<?php

        }

        //Custom Setting field for WC backend

        public function alegra_wc_render_hidden_settings($value)
        {

            if (!empty($value['id']) && isset($value['value'])) {
                printf(
                    '<input type="hidden" id="%1$s" name="%1$s" value="%2$s">',
                    esc_attr($value['id']),
                    esc_attr($value['value'])
                );
            }
        }

        function alegra_connection_status_field($value)
        {
            $status = get_option('alegra_connection_status', 'No Conectado');
            $company_name = get_option('alegra_company_name', '');
            $regime = get_option('alegra_company_regime', '');
    
            if ($status === 'Conectado' && !empty($company_name)) {
                $color = 'green';
                $icon = 'dashicons-yes';
                $display_text = sprintf('%s (%s)', $company_name, $regime);
            } else {
                $color = 'red';
                $icon = 'dashicons-no';
                $display_text = 'No Conectado';
            }
    
            echo '<tr valign="top">';
            echo '<th scope="row" class="titledesc">';
            echo '<label>' . esc_html($value['title']) . '</label>';
            echo '</th>';
            echo '<td class="forminp">';
            echo '<fieldset>';
            echo '<legend class="screen-reader-text"><span>' . esc_html($value['title']) . '</span></legend>';
            echo '<p style="color:' . esc_attr($color) . ';"><span class="dashicons ' . esc_attr($icon) . '"></span> ' . esc_html($display_text) . '</p>';
            echo '</fieldset>';
            echo '</td>';
            echo '</tr>';
        }
    
    }
}

return new Alegra_WC_Settings();
