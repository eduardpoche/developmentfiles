
<?php

class Alegra_WC_Logs
{

    //Log to the Woocommerce Logging system. 
    public static function log($method, $data, $level = 'debug')
    {
        //Get the debug mode
        if (get_option('alegra_wc_debug') == 'no') {
            //Debug mode not set, exit.
            return;
        } else {

            //Pass the method if is set
            $log_data = (isset($method) ? $method . "(): " . $data : $data);

            $context = array('source' => 'alegra-wc-sync');
            // LOAD THE WC LOGGER    
            $logger = wc_get_logger();
            $logger->log($level, wc_print_r($log_data, true), $context);
        }
    }
}
