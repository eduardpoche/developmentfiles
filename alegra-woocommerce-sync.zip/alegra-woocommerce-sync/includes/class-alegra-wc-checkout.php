<?php
class AlegraWCCheckout
{
    public function __construct()
    {
        add_action('woocommerce_before_checkout_billing_form', array($this, 'alegra_wc_add_invoice_fields'));
        add_action('woocommerce_checkout_process', array($this, 'alegra_wc_validate_invoice_fields'));
        add_action('woocommerce_checkout_update_order_meta', array($this, 'alegra_wc_save_custom_fields'));
        add_filter('woocommerce_checkout_order_created', array($this, 'alegra_wc_new_order'));
        add_action('woocommerce_before_calculate_totals', array($this, 'apply_itbis_tax_class'));
        add_action('wp_enqueue_scripts', array($this, 'alegra_wc_enqueue_checkout_script'));
    }
    public function alegra_wc_enqueue_checkout_script()
    {
        if (is_checkout() && !is_wc_endpoint_url()) {
            wp_enqueue_script('alegra-wc-checkout', plugin_dir_url(__DIR__) . 'js/alegra-wc-checkout.js', array('jquery'), '1.0', true);
        }
    }

    public function alegra_wc_add_invoice_fields()
    {

        woocommerce_form_field('comprobante_fiscal', array(
            'type' => 'checkbox',
            'class' => array('form-row-wide', 'input-checkbox'),
            'label' => 'Requiero Factura Fiscal',
            'priority' => 5,
        ), WC()->checkout->get_value('comprobante_fiscal'));


        echo '<div class="alegra_fields" style="display:none">';

        woocommerce_form_field('alegra_order_document_type', array(
            'type' => 'select',
            'class' => array('form-row-first', 'required'),
            'label' => 'Tipo de Documento',
            'required' => true,
            'priority' => 7,
            'options' => array(
                'RNC' => 'RNC',
                'CED' => 'Cédula',
                'IE' => 'Pasaporte',
            ),
        ), WC()->checkout->get_value('alegra_order_document_type'));


        woocommerce_form_field('alegra_order_document_id', array(
            'type' => 'text',
            'class' => array('form-row-last', 'required'),
            'label' => 'Documento Fiscal',
            'required' => true,
        ), WC()->checkout->get_value('alegra_order_document_id'));

        woocommerce_form_field('alegra_order_type', array(
            'type' => 'select',
            'class' => array('form-row-wide', 'required'),
            'label' => 'Tipo de Comprobante',
            'required' => true,
            'priority' => 6,
            'options' => array(
                'INVOICE_B01' => 'Factura de Crédito Fiscal',
                'INVOICE_B02' => 'Factura de Consumo',
                'INVOICE_B14' => 'Regímenes Especiales',
                'INVOICE_B15' => 'Factura Gubernamental',
                'INVOICE_B16' => 'Comprobante para Exportaciones'
            ),
        ), WC()->checkout->get_value('alegra_order_type'));

        echo '</div>';
    }

    public function alegra_wc_validate_invoice_fields($posted)
    {
        if (isset($_POST['comprobante_fiscal']) && empty($_POST['alegra_order_document_id'])) {
            wc_add_notice('Please enter Cédula / RNC.', 'error');
        }

        if (isset($_POST['comprobante_fiscal']) && empty($_POST['alegra_order_type'])) {
            wc_add_notice('Please select a Tipo de Comprobante.', 'error');
        }

        if (isset($_POST['comprobante_fiscal']) && empty($_POST['alegra_order_document_type'])) {
            wc_add_notice('Please select a Tipo de Documento.', 'error');
        }
    }

    public function alegra_wc_save_custom_fields($order_id)
    {
        $AlegraSync = new AlegraWCSync(); 

        $AlegraSync->alegra_wc_save_custom_order_data($order_id);
        
    }

    public function alegra_wc_new_order($order)
    {

        //Check if all orders should be processed or only Fiscal Orders
        $AlegraSync = new AlegraWCSync();

        $order_id = $order->get_id();
        $send_orders = get_option('send_orders_to_alegra');

        if ($send_orders == 'no') {
            $AlegraSync->alegra_log(__METHOD__ . '(): ' . 'Order ID ' . $order_id . ' was created but orders are not being created automatically in Alegra.', 'notice');
            return;
        }
        $result = $AlegraSync->alegra_wc_create_invoice($order_id);

        if ($result['success'] === true) {
            $AlegraSync->alegra_log(__METHOD__ . '(): ' . 'Order ID ' . $order_id . ' was successfully created in Alegra. Alegra Order ID ' . $result['data']['id'] . '.');
        } else {
            $AlegraSync->alegra_log(__METHOD__ . '(): ' . 'Order ID ' . $order_id . ' creation failed. =>' . print_r($result, true), 'error');
        }
        return;
    }

    // Function to retrieve the TAX class corresponding to 18%, (ITBIS)
    public function get_itbis_class_rate()
    {
        $tax_classes = WC_Tax::get_tax_classes();
        foreach ($tax_classes as $tax_class) {
            $tax_rates = WC_Tax::get_rates_for_tax_class($tax_class);
            foreach ($tax_rates as $rate) {
                if ($rate->tax_rate === '18.0000') {
                    return $rate->tax_rate_class;
                }
            }
        }

        return ''; // Return an empty string if the tax class is not found
    }

    public function apply_itbis_tax_class($cart)
    {

        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }
        // Get the checkbox status sent via AJAX. Can come from the post data or the POST request.

        if (isset($_POST['post_data'])) {

            parse_str($_POST['post_data'], $post_data);
        } else {
            $post_data = $_POST;
        }

        $isChecked = isset($post_data['comprobante_fiscal']) ? '1' : '0';

        // Get the tax class associated with 18% rate
        $itbis_tax_class = $this->get_itbis_class_rate();

        if ($isChecked === '1') {

            if (empty($itbis_tax_class)) {
                wc_add_notice('We are having isssue generating NCFs right now. Please try again later.', 'error');
                return;
            } else {
                foreach ($cart->get_cart() as $cart_item) {
                    // Apply or remove the tax class to all cart items
                    if (!empty($itbis_tax_class)) {
                        $cart_item['data']->set_tax_class($itbis_tax_class);
                    } else {
                        $cart_item['data']->set_tax_class('standard');
                    }
                }
            }
        } else {

            foreach ($cart->get_cart() as $cart_item) {
                $cart_item['data']->set_tax_class('standard');
            }
        }
    }
}
