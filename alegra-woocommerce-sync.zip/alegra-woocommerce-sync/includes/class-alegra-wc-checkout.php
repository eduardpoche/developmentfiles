<?php
class Alegra_WC_Checkout
{
    public function __construct()
    {
        add_action('woocommerce_before_checkout_billing_form', array($this, 'alegra_wc_add_invoice_fields'));
        add_action('woocommerce_checkout_process', array($this, 'alegra_wc_validate_invoice_fields'));
        add_action('woocommerce_checkout_update_order_meta', array($this, 'alegra_wc_save_custom_fields'));
        add_filter('woocommerce_checkout_order_created', array($this, 'alegra_wc_new_order'));
        add_action('woocommerce_before_calculate_totals', array($this, 'apply_itbis_tax_class'));
        add_action('wp_enqueue_scripts', array($this, 'alegra_wc_enqueue_checkout_script'));
        add_action('wp_ajax_alegra_rnc_lookup', [$this, 'alegra_wc_rnc_lookup']);
        add_action('wp_ajax_nopriv_alegra_rnc_lookup', [$this, 'alegra_wc_rnc_lookup']);
        add_filter('woocommerce_checkout_fields', [$this, 'remove_wc_default_checkout_fields']);
        add_filter('woocommerce_checkout_get_value', [$this, 'prefill_rnc_checkout_field'], 10, 2);
    }
    public function alegra_wc_enqueue_checkout_script()
    {
        if (is_checkout() && !is_wc_endpoint_url()) {
            // Enqueue the main checkout script and style
            wp_enqueue_script('alegra-wc-checkout', plugin_dir_url(__DIR__) . 'js/alegra-wc-checkout.js', array('jquery'), '1.0', true);
            wp_enqueue_style('alegra-wc-sync', plugin_dir_url(__DIR__) . 'css/alegra-wc-sync-checkout.css', array(), '1.0', 'all');

            // Script control based on settings
            $enable_rnc_check = get_option('enable_dgii_rnc_check') === 'yes';
            $auth_user = get_option('alegra_dgii_auth_user');
            $auth_key = get_option('alegra_dgii_auth_key');

            // Localize script data common to both scenarios
            wp_localize_script('alegra-wc-checkout', 'alegraWcParams', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'performCheck' => $enable_rnc_check && !empty($auth_user) && !empty($auth_key) // True if all conditions are met
            ));

            // Optionally enqueue and localize additional script if RNC check is enabled and credentials are set
            if ($enable_rnc_check && !empty($auth_user) && !empty($auth_key)) {
                wp_enqueue_script('alegra-wc-checkout-rnc-script', plugin_dir_url(__DIR__) . 'js/alegra-wc-rnc-lookup.js', array('jquery'), '1.0', true);
                // No need to localize script again if already localized the main script with parameters
            }
        }
    }

    public function alegra_wc_add_invoice_fields()
    {

        woocommerce_form_field('comprobante_fiscal', array(
            'type' => 'checkbox',
            'class' => array('form-row-wide', 'input-checkbox'),
            'label' => __('Requiero Factura Fiscal', 'alegra-wc-sync'),
            'priority' => 5,
        ), WC()->checkout->get_value('comprobante_fiscal'));


        echo '<div class="alegra_fields" style="display:none">';

        woocommerce_form_field('alegra_order_document_type', array(
            'type' => 'select',
            'class' => array('alegra-select-field', 'form-row-first', 'required'),
            'label' => __('Tipo de Documento', 'alegra-wc-sync'),
            'required' => true,
            'priority' => 7,
            'options' => array(
                'RNC' => 'RNC',
                'CED' => 'Cédula',
                'IE' => 'Pasaporte',
            ),
        ), WC()->checkout->get_value('alegra_order_document_type'));


        woocommerce_form_field('alegra_order_document_id', array(
            'type' => 'text',
            'class' => array('form-row-last', 'required'),
            'label' => __('Documento Fiscal', 'alegra-wc-sync'),
            'required' => true,
        ), WC()->checkout->get_value('alegra_order_document_id'));


        echo '<div id="alegra_order_razon_social_field" style="display:none;">'; // Wrap details fields in a div with display none

        woocommerce_form_field('alegra_order_razon_social', array(
            'type' => 'text',
            'class' => array('form-row-wide'),
            'label' => __('Razón Social', 'alegra-wc-sync'),
            /*'custom_attributes' => array('readonly' => 'readonly')*/
        ), WC()->checkout->get_value('alegra_order_razon_social'));

        echo '</div>'; // Close the div

        echo '<div id="alegra_order_nombre_comercial_field" style="display:none;">'; // Wrap details fields in a div with display none

        woocommerce_form_field('alegra_order_nombre_comercial', array(
            'type' => 'text',
            'class' => array('form-row-wide'),
            'label' => __('Nombre Comercial', 'alegra-wc-sync'),
            /*'custom_attributes' => array('readonly' => 'readonly')*/
        ), WC()->checkout->get_value('alegra_order_nombre_comercial'));

        echo '</div>';


        woocommerce_form_field('alegra_order_type', array(
            'type' => 'select',
            'class' => array('form-row-wide', 'required', 'alegra-select-field'),
            'label' => __('Tipo de Comprobante', 'alegra-wc-sync'),
            'required' => true,
            'priority' => 6,
            'options' => array(
                'INVOICE_B01' => 'Factura de Crédito Fiscal',
                'INVOICE_B02' => 'Factura de Consumo',
                'INVOICE_B14' => 'Regímenes Especiales',
                'INVOICE_B15' => 'Factura Gubernamental',
                'INVOICE_B16' => 'Comprobante para Exportaciones'
            ),
            'default' => 'INVOICE_B02',
        ), WC()->checkout->get_value('alegra_order_type'));

        echo '</div>';
    }

    public function alegra_wc_validate_invoice_fields($posted)
    {
        if (isset($_POST['comprobante_fiscal']) && empty($_POST['alegra_order_document_id'])) {
            wc_add_notice(__('Por favor introduzca su documento fiscal.', 'alegra-wc-sync'), 'error');
        }

        if (isset($_POST['comprobante_fiscal']) && empty($_POST['alegra_order_type'])) {
            wc_add_notice(__('Por favor elija un tipo de comprobante.', 'alegra-wc-sync'), 'error');
        }

        if (isset($_POST['comprobante_fiscal']) && empty($_POST['alegra_order_document_type'])) {
            wc_add_notice(__('Por favor elija un tipo de documento.', 'alegra-wc-sync'), 'error');
        }
    }

    public function alegra_wc_save_custom_fields($order_id)
    {
        $AlegraSync = new Alegra_WC_Sync();

        $AlegraSync->alegra_wc_save_custom_order_data($order_id);
    }

    public function alegra_wc_new_order($order)
    {

        //Check if all orders should be processed or only Fiscal Orders
        $AlegraSync = new Alegra_WC_Sync();

        $order_id = $order->get_id();
        $send_orders = get_option('send_orders_to_alegra');

        if (!$send_orders) {
            Alegra_WC_Logs::log(__METHOD__, 'Creation of Order ID ' . $order_id . ' was stopped because the Integration is set to send orders manually.', 'notice');
            return;
        }
        $result = $AlegraSync->alegra_wc_create_invoice($order_id);

        if ($result['success'] === true) {
            Alegra_WC_Logs::log(__METHOD__, 'Order ID ' . $order_id . ' was successfully created in Alegra. Alegra Order ID ' . $result['data']['id'] . '.');
        } else {
            Alegra_WC_Logs::log(__METHOD__, 'Order ID ' . $order_id . ' creation failed. =>' . print_r($result, true), 'error');
        }
        return;
    }

    public function apply_itbis_tax_class($cart)
    {

        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }
        // Get the checkbox status sent via AJAX. Can come from the post data or the POST request.

        if (isset($_POST['post_data'])) {
            parse_str($_POST['post_data'], $post_data);
        } else {
            $post_data = $_POST;
        }

        // Get the tax class associated with 18% rate
        $itbis_tax_class = Alegra_WC_Taxes::get_tax_class_by_rate('18.00');

        if (isset($post_data['comprobante_fiscal'])) {

            if (empty($itbis_tax_class)) {
                Alegra_WC_Logs::log(__METHOD__, 'Unable to apply the ITBIS to this order, it seems that the ITBIS tax has not been created.', 'error');
                wc_add_notice(__('Estamos presentando inconvenientes para generar facturas fiscales. Intente más tarde.', 'alegra-wc-sync'), 'error');
                return;
            } else {
                foreach ($cart->get_cart() as $cart_item) {
                    // Apply or remove the tax class to all cart items
                    if (!empty($itbis_tax_class)) {
                        Alegra_WC_Taxes::apply_tax_class($cart_item['data'], $itbis_tax_class);
                    } else {
                        Alegra_WC_Taxes::apply_tax_class($cart_item['data'], 'standard');
                    }
                }
            }
        } else {
            foreach ($cart->get_cart() as $cart_item) {
                Alegra_WC_Taxes::apply_tax_class($cart_item['data'], 'standard');
            }
        }
    }

    public function alegra_wc_rnc_lookup()
    {
        if (isset($_POST['rnc']) && !empty($_POST['rnc'])) {
            $rnc = sanitize_text_field($_POST['rnc']);

            // Fetch credentials from WordPress settings
            $auth_user = get_option('alegra_dgii_auth_user');
            $auth_key = get_option('alegra_dgii_auth_key');

            // Endpoint with basic auth
            $endpoint = "https://n8n.infinitegroup.com.do/webhook/consulta?id=" . $rnc;
            $auth = base64_encode($auth_user . ':' . $auth_key);

            $response = wp_remote_post($endpoint, array(
                'headers' => array(
                    'Authorization' => 'Basic ' . $auth
                )
            ));

            if (is_wp_error($response)) {
                wp_send_json_error(array('message' => __('Error conectando con DGII.', 'alegra-wc-sync')));
            } else {
                $response_code = wp_remote_retrieve_response_code($response);
                $body = wp_remote_retrieve_body($response);
                $data = json_decode($body, true);

                switch ($response_code) {
                    case 200:
                        if (!empty($data) && isset($data[0]['RNC'])) {
                            wp_send_json_success($data);
                        } else {
                            wp_send_json_error(array('message' => __('No se encontró el documento suministrado.', 'alegra-wc-sync')));
                        }
                        break;
                    case 404:
                        wp_send_json_error(array('message' => __('URL o método incorrecto.', 'alegra-wc-sync')));
                        break;
                    case 500:
                        wp_send_json_error(array('message' => __('Error al consultar DGII:' . $data['message'], 'alegra-wc-sync')));
                        break;
                    default:
                        wp_send_json_error(array('message' => __('Ocurrió un error inesperado. Código: ', 'alegra-wc-sync') . $response_code));
                        break;
                }
            }
        } else {
            wp_send_json_error(array('message' => __('RNC is required.', 'alegra-wc-sync')));
        }
    }

    public function remove_wc_default_checkout_fields($fields)
    {
        unset($fields['billing']['billing_company']); // Remove the company name field from billing
        unset($fields['shipping']['shipping_company']); // Remove the company name field from shipping if necessary
        return $fields;
    }

    public function prefill_rnc_checkout_field($value, $input)
    {

        if ('alegra_order_document_id' === $input) { // Check if the current field is the RNC field
            $user_id = get_current_user_id();
            if ($user_id) {
                return get_user_meta($user_id, 'alegra_user_tax_id', true);
            }
        }
        return $value;
    }
}
