<?php
class AlegraWCSync
{

    const ALEGRA_API_URL = 'https://api.alegra.com/api/v1/';

    public function __construct()
    {
        // Add hooks and actions here for syncing inventory and generating invoices.
        add_action('init', array($this, 'alegra_wc_register_custom_meta_fields'));
        // add_action('created_term', [$this, 'alegra_wc_create_variant_attribute'], 10, 3);
        add_action('create_product_cat', [$this, 'alegra_wc_create_category']);
        add_action('edited_product_cat', [$this, 'alegra_wc_create_category']);
        add_action('admin_init', [$this, 'alegra_wc_activation_redirect']);
        add_action('admin_notices', [$this, 'alegra_ITBIS_creation_notice']);
        add_action('alegra_wc_adjust_product_inventory', array($this, 'alegra_wc_adjust_product_inventory'), 10, 4);
        add_action('alegra_wc_check_for_inventory_adjustments', array($this, 'alegra_wc_check_for_inventory_adjustments'));
        add_action('create_scheduled_product', array($this, 'create_scheduled_product'), 10, 4);
        add_action('create_scheduled_category', array($this, 'create_scheduled_category'), 10, 4);
    }


    public function alegra_wc_activation_redirect()
    {
        // Make sure it's the correct user
        if (!wp_doing_ajax() && intval(get_option('alegra_activation_redirect')) === wp_get_current_user()->ID) {
            // Make sure we don't redirect again after this one
            delete_option('alegra_activation_redirect');
            wp_safe_redirect(admin_url('admin.php?page=wc-settings&tab=alegra_settings'));
            exit;
        }
    }

    public function alegra_wc_register_custom_meta_fields()
    {
        // Register custom meta for WooCommerce attributes
        register_meta('pa_custom_attribute', '_alegra_attribute_id', array(
            'type' => 'string',
            'single' => true,
            'show_in_rest' => true,
        ));

        // Register custom meta for WooCommerce terms
        register_meta('product_attribute', '_alegra_term_id', array(
            'type' => 'string',
            'single' => true,
            'show_in_rest' => true,
        ));
    }

    /** 
     * If the Taxes has not been configured properly, display an admin notice. 
     */
    public function alegra_ITBIS_creation_notice()
    {
        $taxes = $this->alegra_get_itbis_class_rate();

        if ($taxes == '') {
            $msg = __('No se ha configurado ningún impuesto equivalente al ITBIS para poder generar facturas fiscales con Alegra.', 'alegra-wc-sync');
            $msg = sprintf($msg, 'alegra-wc-sync');
?>
            <div class="notice notice-error" style="padding: 15px; position: relative">
                <?php echo $msg; ?>

                <a href="<?php echo admin_url('admin.php?page=wc-settings&tab=tax'); ?>">
                    <?php _e('Configurar los impuestos', 'alegra-wc-sync'); ?>.
                </a>

            </div>
<?php
        }
    }


    // Function to generate the Alegra API authorization string
    public static function alegra_wc_generate_authstring()
    {
        $alegra_wc_user = get_option('alegra_wc_user'); // Get the Alegra user (email) from settings
        $alegra_wc_token = get_option('alegra_wc_token'); // Get the Alegra token from settings

        // Check if both user and token are set
        if (!empty($alegra_wc_user) && !empty($alegra_wc_token)) {
            // Concatenate user and token with a semicolon
            $credentials = $alegra_wc_user . ':' . $alegra_wc_token;

            // Encode in base64
            $authorization_string = base64_encode($credentials);

            return $authorization_string;
        }

        return false; // Return false if user or token is empty
    }

    // Public method to make API requests to Alegra
    public static function alegra_wc_api_request($request_type, $endpoint, $content = array())
    {
        // Generate the authorization string using the existing method
        $authorization = self::alegra_wc_generate_authstring();

        // Check if the authorization string is available
        if (!$authorization) {
            SELF::alegra_log('Authorization string is missing. Please check Alegra credentials.', 'error');
            return array(
                'code'    => 'auth_error',
                'data' => array(
                    'message' => 'Authorization string is missing. Please check your Alegra credentials.'
                )
            );
        }

        // Define the API URL by appending the endpoint to the base URL
        $api_url = self::ALEGRA_API_URL . $endpoint;

        // Set up the request arguments
        $args = array(
            'method'      => $request_type,
            'timeout'     => 45,
            'headers'     => array(
                'Authorization' => 'Basic ' . $authorization, // Use the generated authorization string
                'Content-Type'  => 'application/json',
            ),
        );

        // Add content to the request for POST, PUT, and PATCH requests
        if (in_array($request_type, array('POST', 'PUT', 'PATCH'))) {
            $args['body'] = json_encode($content);
        }

        // Make the API request
        $response = wp_remote_request($api_url, $args);
        SELF::alegra_log(__METHOD__ . "(): Calling Alegra with Args => " . wc_print_r($args, true) . "And URL => " . $api_url);

        // Check for errors
        if (is_wp_error($response)) {
            // Handle WP error
            return array(
                'code'    => 'wp_error',
                'data' => $response->get_error_message(),
            );
        }

        // Get the response code
        $response_code = wp_remote_retrieve_response_code($response);

        // Get the response body as JSON
        $response_body = wp_remote_retrieve_body($response);
        $response_data = json_decode($response_body, true);

        if (isset($response_data['message']) && $response_data['message'] == 'Unauthorized') {
            $response_data['message'] = 'Unable to connect to Alegra. The provided credentials are incorrect. Please check your credentials.';
        }

        return array(
            'code' => $response_code,
            'data' => $response_data
        );
    }



    public static function alegra_wc_create_variant_attribute($term_id, $tt_id, $taxonomy_slug)
    {
        //P2 Maybe we need to alter the response of the attribute creation in the frontend to reflect a failure.

        if ((!empty($term_id) && !empty($taxonomy_slug)) && taxonomy_exists($taxonomy_slug)) {

            SELF::alegra_log(__METHOD__ . "(): Creating Variant Attributes for Term ID " . $term_id . " ; Taxonomy ID " . $tt_id . " and Taxonomy Slug " . $taxonomy_slug);

            // Get the taxonomy
            $taxonomy = get_taxonomy($taxonomy_slug);

            $attribute_data = array(
                'name' => $taxonomy->labels->singular_name,
                'options' => array(),
                'status' => 'active'
            );

            // Get the created term
            $term = get_term($term_id, $taxonomy_slug);

            //For some reason $tt_id in the method doesn't pass the Taxonomy ID, so we obtain it via the slug
            $tt_id = wc_attribute_taxonomy_id_by_name($taxonomy_slug);

            $alegra_tax_id = get_term_meta($tt_id, '_alegra_attribute_id', true);

            //Set the Alegra Endpoint and Methods to create or update
            $method = 'POST';
            $endpoint = 'variant-attributes';

            if ($alegra_tax_id) {

                //Exists, has to be updated

                SELF::alegra_log(__METHOD__ . "(): The Alegra Tax ID exists for Taxonomy " . $taxonomy_slug . " ; Updating it...");

                $attribute_data['id'] = $alegra_tax_id;
                $method = 'PUT';
                $endpoint = $endpoint . '/' . $alegra_tax_id;

                //Get current taxonomies terms, they are required to update
                $current_alegra_taxonomy = SELF::alegra_wc_api_request('GET', 'variant-attributes/' . $alegra_tax_id);

                if (in_array($current_alegra_taxonomy['code'], array(200, 201)) && isset($current_alegra_taxonomy['data']['id'])) {

                    foreach ($current_alegra_taxonomy['options'] as $value) {
                        $attribute_data['options'][] = $value;
                    }
                } else {
                    SELF::alegra_log(__METHOD__ . "(): " . 'an error ocurred. ' . wc_print_r($current_alegra_taxonomy, true), 'error');
                    return false;
                }
            }

            // Update the attribute data
            $attribute_data['options'][] = array(
                'value' => $term->name,
            );

            // Perform the Alegra API request here to create the attribute and terms
            $response = SELF::alegra_wc_api_request($method, $endpoint, $attribute_data);

            if (in_array($response['code'], array(200, 201)) && isset($response['data']['id'])) {
                //Response was successful, check for its content
                $response = $response['data'];

                $attribute_id = $response['id'];

                //To update the newly created term, need to find its ID in the response.

                foreach ($response['options'] as $alegra_term) {

                    if ($alegra_term['value'] == $term->name) {

                        $alegra_term_id = $alegra_term['id'];
                    }
                }

                // Update custom meta for the Taxonomy with Alegra attribute ID
                update_term_meta($tt_id, '_alegra_attribute_id', $attribute_id);

                // Update custom meta for the term with Alegra term ID
                update_term_meta($term_id, '_alegra_term_id', $alegra_term_id);

                return true;
            } else {

                SELF::alegra_log(__METHOD__ . "(): " . 'an error ocurred. ' . wc_print_r($response, true), 'error');
                return false;
            }
        }
    }

    // Function to retrieve the TAX class corresponding to 18%, (ITBIS)
    public function alegra_get_itbis_class_rate()
    {
        $tax_classes = WC_Tax::get_tax_classes();

        foreach ($tax_classes as $tax_class) {
            $tax_rates = WC_Tax::get_rates_for_tax_class($tax_class);

            foreach ($tax_rates as $rate) {
                if ($rate->tax_rate === '18.0000') {
                    return $rate->tax_rate_class;
                }
            }
        }

        return ''; // Return an empty string if the tax class is not found
    }




    public function alegra_wc_build_product_data($product_id)
    {
        SELF::alegra_log(__METHOD__ . "(): " . 'Building product data for Product ' . $product_id);

        $product = wc_get_product($product_id);

        $item = array(
            'name' => $product->get_name(),
            'description' => $product->get_description(),
            'reference' => $product->get_sku(),
            'price' => wc_get_price_to_display($product),
        );

        if ($product->is_taxable()) {

            //If the product is taxable, determine what tax is and match it with Alegra
            $wc_tax = $this->wc_alegra_set_item_tax($product);

            if (!empty($wc_tax)) {
                $item_data['tax'][] = $wc_tax;
            }
        }

        $invoice_data["items"][] = $item_data;

        if ($product->managing_stock()) {


            $product_unit = (empty($product->get_meta('wc_alegra_product_unit')) ? 'LB' : $product->get_meta('wc_alegra_product_unit'));

            //The unit cost can be set at variation level, or parent product level. Check on parent level.
            if (empty($product->get_meta('wc_alegra_unit_cost')) && $product->is_type('variation')) {

                $unit_cost_meta = get_post_meta($product->get_parent_id(), 'wc_alegra_unit_cost', true);
            } else {
                $unit_cost_meta = $product->get_meta('wc_alegra_unit_cost', true);
            }

            $product_unit_cost = (empty($unit_cost_meta) ? 1 : $unit_cost_meta);

            //The product has stock management, add Inventory to Alegra
            $item_inventory = array(
                'unit' => $product_unit,
                'unitCost' => $product_unit_cost,
                'negativeSale' => ($product->backorders_allowed()) ? 'true' : 'false',
                'initialQuantity' => $product->get_stock_quantity()

            );

            $item['inventory'] = $item_inventory;
        }

        if (!empty($product->get_meta('wc_alegra_product_category'))) {
            //There's an Alegra Category, add to the product
            $item['itemCategory'] = array(
                'id' => $product->get_meta('wc_alegra_product_category')
            );
        }

        $item['type'] = ($product->is_virtual()) ? 'service' : 'product';

        return $item;
    }


    public static function alegra_wc_create_itemVariants_object($product)
    {

        SELF::alegra_log(__METHOD__ . "(): " . 'Creating Item Variants...');

        //Get all the variations of the product
        $variations = $product->get_available_variations();

        $itemVariants = array();

        foreach ($variations as $variation) {

            $attribute_data_options = array();

            foreach ($variation['attributes'] as $attribute_name => $attribute) {

                // Use wc_attribute_label to get the attribute label
                $attribute_label  = str_replace('attribute_', '', $attribute_name);

                $wc_tax_id = wc_attribute_taxonomy_id_by_name($attribute_label);

                $wc_term = get_term_by('slug', $attribute, $attribute_label, OBJECT);

                $alegra_term_id = get_term_meta($wc_term->term_id, '_alegra_term_id', true);

                $alegra_tax_id = get_term_meta($wc_tax_id, '_alegra_attribute_id', true);

                $attribute_data_options[] = array(
                    'alegra_term_id' => $alegra_term_id,
                    'alegra_tax_id' => $alegra_tax_id,
                    'term_name' => $attribute,
                    'tax_name' => $attribute_label
                );
            }

            $IV_variantAttributes_data = array();

            $itemVariant_Options = new stdClass();

            foreach ($attribute_data_options as $option) {


                $itemVariant_Options = array(
                    'tax_name' => $option['tax_name'],
                    'id' => $option['alegra_term_id'],
                    'term_name' => $option['term_name']
                );

                $IV_variantAttributes_data[] = array(
                    'attribute_name' => $option['tax_name'],
                    'id'  => (int)$option['alegra_tax_id'],
                    'options' => array($itemVariant_Options)
                );
            }
            $product_unit = (empty($product->get_meta('wc_alegra_product_unit')) ? 'LB' : $product->get_meta('wc_alegra_product_unit'));

            $product_unit_cost = (empty($product->get_meta('wc_alegra_unit_cost')) ? 1 : $product->get_meta('wc_alegra_unit_cost'));

            $alegra_product_id = get_post_meta($variation['variation_id'], 'wc_alegra_product_id', true);

            $item = array(
                "VariantID" => $variation['variation_id'],
                "reference" => $variation['sku'],
                "price" => $variation['display_price'],
                'inventory' => array(
                    "initialQuantity" => $variation['max_qty'],
                    "maxQuantity" => $variation['max_qty'],
                    "minQuantity" => $variation['min_qty'],
                    'unit' => $product_unit,
                    "unitCost" => $product_unit_cost,
                ),
                'variantAttributes' => $IV_variantAttributes_data
            );

            // Add 'id' key only if 'wc_alegra_product_id' meta exists
            if ($alegra_product_id !== '') {

                $item_id = array(
                    'id' => $alegra_product_id
                );

                $itemVariants[] = $item_id + $item;
            } else {

                $itemVariants[] = $item;
            }
        }
        echo print_r($itemVariants, true);
        return $itemVariants;
    }


    public function alegra_wc_match_variations($product, $itemVariants)
    {

        $variations = $product->get_available_variations();

        foreach ($itemVariants as $itemVariant) {

            $normalized_item_variant_name = sanitize_title($itemVariant['name']);

            $Alegra_itemVariantId = $itemVariant['id'];

            foreach ($variations as $variation) {
                // Get the variation attributes for this variation

                $variation_attributes = $variation['attributes'];

                // Combine the attributes into a string with slashes
                $variation_attributes_string = implode(' / ', $variation_attributes);

                // Get the product name for this variation
                $product_name = $product->get_name();

                $wc_variation_name = sanitize_title($product_name . ' / ' . $variation_attributes_string);

                // Compare the variation attributes and product name with the item variant name
                if ($wc_variation_name === $normalized_item_variant_name) {
                    // Match found, set the variation metadata
                    update_post_meta($variation['variation_id'], 'wc_alegra_product_id', $Alegra_itemVariantId);
                }
            }
        }
    }

    /**
     * Create a Category in Alegra by passing a WC Category ID.
     * @param int $CatId The WC Category ID.
     * @return object An array containing the result and a message.
     */

    public static function alegra_wc_create_category($CatId, $bulk = false, $tt_id = '', $taxonomy = '')
    {

        $send_categories = get_option('auto_create_categories_to_alegra');

        if ($send_categories == 'no') {
            SELF::alegra_log(__METHOD__ . '(): ' . 'Category ID ' . $CatId . ' was created but Categories are not being created automatically in Alegra. Exiting...', 'notice');
            return;
        }

        $message = __METHOD__ . "(): " . 'New Category Created or updated. ID => ' . $CatId . '. Syncing to Alegra...';

        $message .= ($bulk ? ' (This is a bulk update)' : '');

        SELF::alegra_log($message);

        $wc_taxonomy = get_term($CatId);

        $content = array(
            'name' => $wc_taxonomy->name,
            'description' => $wc_taxonomy->description,
            'status' => 'active'
        );

        $alegra_taxonomy_id = get_term_meta($CatId, 'alegra_taxonomy_id', true);

        //Depending if it has an alegra ID, either update, or create by changing request method and endpoint URL

        $request_type = (!empty($alegra_taxonomy_id) ? 'PUT' : 'POST');
        $endpoint = (!empty($alegra_taxonomy_id) ? 'item-categories/' . $alegra_taxonomy_id : 'item-categories');

        if ($bulk) {

            $schedule_id = as_enqueue_async_action("create_scheduled_category", array($request_type, $endpoint, $content, $CatId));

            if ($schedule_id) {
                SELF::alegra_log(__METHOD__ . "(): Scheduled the creation/update of Category ID  " . $CatId . " With method => " . $request_type);
            } else {
                SELF::alegra_log(__METHOD__ . "(): Something went wrong scheduling the creation/update of Category ID  " . $CatId . " With method => " . $request_type, 'error');
            }
            return $schedule_id;
        }

        $response = SELF::alegra_wc_api_request($request_type, $endpoint, $content);

        if (in_array($response['code'], array(200, 201)) && isset($response['data']['id'])) {

            //Response was successful, check for its content
            $response = $response['data'];

            //Store the Alegra Taxonomy ID in the Category Meta
            update_term_meta($CatId, 'alegra_taxonomy_id', $response['id']);
            SELF::alegra_log(__METHOD__ . "(): " . ' Category Created Succesfully in Alegra. Alegra Category ID ' . $response['id']);

            return true;
        } else {

            SELF::alegra_log(__METHOD__ . "(): " . ' An error ocurred trying to create the Category. ' . wc_print_r($response, true), 'error');
            return false;
        }
    }


    /**
     * Create a Product in Alegra by passing a WC product ID.
     * @param int $product_id The WC Product ID.
     * @return object An array containing the result and a message.
     */
    public function alegra_wc_create_product($product_id, $bulk = false, $sync_type = 'all', $force_sync = false)
    {

        $product = wc_get_product($product_id);

        $allowed_categories = apply_filters('alegra_wc_allowed_categories', get_option('included_categories_for_alegra'));

        if (!has_term($allowed_categories, 'product_cat', $product_id) && !empty($allowed_categories)) {
            // do something else if it isn't
            SELF::alegra_log(__METHOD__ . "(): Syncing Product ID " . $product_id . " Failed. Not in the approved categories: " . print_R($allowed_categories, true), 'error');
            $response['success'] = false;
            $response['data'] = 'Unable to Create Product "' . $product->get_name() . '": The product is not allowed to be synced to alegra. Check the categories settings.';

            return $response;
        }


        if ($product->is_type('variable')) {

            //Variable products are going to be handled as single products in Alegra
            SELF::alegra_log(__METHOD__ . "(): The Product " . $product->get_name() . " is Variable. Build content for each variation... Sync Type => " . $sync_type);

            $variations = $product->get_available_variations();

            foreach ($variations as $variation) {

                $alegra_product_id = get_post_meta($variation['variation_id'], 'wc_alegra_product_id', true);

                //If the requested sync was only for pending variations, just sync variations without an alegra ID.

                if ($sync_type == 'pending-variations' && !empty($alegra_product_id)) {
                    continue;
                }

                $VariantContent = $this->alegra_wc_build_product_data($variation['variation_id']);

                if (empty($VariantContent)) {
                    SELF::alegra_log(__METHOD__ . "(): Something went wrong building the request body for Variation ID  " . $variation['variation_id'], 'warning');
                    continue;
                }



                //Depending if it has an alegra ID, either update, or create by changing request method and endpoint URL

                $request_type = (!empty($alegra_product_id) ? 'PUT' : 'POST');
                $endpoint = (!empty($alegra_product_id) ? 'items/' . $alegra_product_id : 'items');
                $schedule_id = as_enqueue_async_action("create_scheduled_product", array($request_type, $endpoint, $VariantContent, $variation['variation_id']));

                $schedule_result = true;

                if ($schedule_id) {
                    SELF::alegra_log(__METHOD__ . "(): Scheduled the Creation of Variation ID  " . $variation['variation_id'] . " With method => " . $request_type);
                    $schedules[] = $schedule_id;
                } else {
                    SELF::alegra_log(__METHOD__ . "(): Something went wrong scheduling the creation of Variation ID  " . $variation['variation_id'] . " With method => " . $request_type, 'error');
                    $schedule_result = false;
                }
            }

            if ($schedule_result) {

                SELF::alegra_log(__METHOD__ . "(): " . 'Products scheduled to be created. Schedule IDs => ' . print_r($schedules, true));
                // Update the Alegra Product ID meta field if the request was successful
                $response['success'] = true;
            } else {
                SELF::alegra_log(__METHOD__ . "(): " . 'There was a problem Scheduling the product creation. ', 'error');
                $response['success'] = false;
            }
            $response['data'] = 'Products succesfully scheduled to be created.';
            return $response;
        } else {

            //Simple products, or specific variations, are addressed the same way, as simple products.

            SELF::alegra_log(__METHOD__ . "(): Syncing the Product " . $product->get_name() . " To Alegra. Sync Type => " . $sync_type . ". Force Sync => " . $force_sync);


            $alegra_product_id = $product->get_meta('wc_alegra_product_id');

            $request_type = (!empty($alegra_product_id) ? 'PUT' : 'POST');

            //If its a forced sync, treat products as new.

            if ($force_sync === 'yes') {

                $endpoint = 'items';
                $request_type = ('POST');
            } else {

                $endpoint = (!empty($alegra_product_id) ? 'items/' . $alegra_product_id : 'items');
                $request_type = (!empty($alegra_product_id) ? 'PUT' : 'POST');
            }

            $content = $this->alegra_wc_build_product_data($product_id);

            //This is a bulk creation request. Schedule the creation of the product.
            if ($bulk) {

                $schedule_id = as_schedule_single_action(date('U', strtotime("+5 min")), "create_scheduled_product", array($request_type, $endpoint, $content, $product_id));

                if ($schedule_id) {
                    SELF::alegra_log(__METHOD__ . "(): Scheduled the Creation of Product ID  " . $product_id . " With method => " . $request_type);
                } else {
                    SELF::alegra_log(__METHOD__ . "(): Something went wrong scheduling the creation of Variation ID  " . $product_id . " With method => " . $request_type, 'error');
                }
                return $schedule_id;
            }

            $call_response = $this->alegra_wc_api_request($request_type, $endpoint, $content);

            if (in_array($call_response['code'], array(200, 201)) && isset($call_response['data']['id'])) {

                //Response was successful, check for its content
                $call_response = $call_response['data'];

                SELF::alegra_log(__METHOD__ . "(): " . 'Product succesfully Synced with Alegra Product ID ' . $call_response['id'] . '. Updating Meta of Product ID ' . $product_id . "...");

                // Update the Alegra Product ID meta field if the request was successful
                update_post_meta($product_id, 'wc_alegra_product_id', $call_response['id']);
                update_post_meta($product_id, 'wc_alegra_sync_status', 'Synced');
                update_post_meta($product_id, 'wc_alegra_last_synced', date_i18n('Y-m-d H:i:s'));
                $response['success'] = true;
                $response['message'] = 'Product succesfully Synced with Alegra. Alegra Product ID: ' . $call_response['id'] . ".";
            } else {

                update_post_meta($product_id, 'wc_alegra_sync_status', 'Error');

                SELF::alegra_log(__METHOD__ . "(): " . 'Product Creation Failed. ' . print_r($call_response, true), 'error');

                $response['message'] = 'Hubo un problema al crear el producto. ' . $call_response['data']['message'];

                if ($call_response['code'] == 1009) {

                    $response['message'] = 'Ya existe un Producto en Alegra con el SKU ' . $content['reference'] . '. El valor de SKU debe ser único.';
                }
                $response['success'] = false;
                
            }
            $response['data'] = $call_response;
            return $response;
        }
    }

    /**
     * Create a Contact in Alegra by passing a WC User ID and the Order.
     * @param int $user_id The WC User ID.
     * @param object $order The WC Order Object
     * @return object An array containing the result and a message.
     */

    public static function alegra_wc_create_contact($user_id, $order = array())
    {

        SELF::alegra_log(__METHOD__ . "(): " . 'About to create contact with User ID ' . $user_id . "...");


        if (empty($order)) {

            //There's no order, the data should come from the User Meta

            $customer = new WC_Customer($user_id);

            //Build Customer Address
            $country_code = $customer->get_billing_country();
            $state_code = $customer->get_billing_state();
            $countries_obj = new WC_Countries();
            $countries_array = $countries_obj->get_countries();
            $country_states_array = $countries_obj->get_states();
            $country_name = $countries_array[$country_code];
            $state_name = $country_states_array[$country_code][$state_code];
            $address = (!empty($customer->get_billing_address_2())) ? $customer->get_billing_address_1() . " " . $customer->get_billing_address_2() : $customer->get_billing_address_1();

            //Customer Data
            $customer_name = $customer->get_billing_first_name() . " " . $customer->get_billing_last_name();
            $customer_phone = $customer->get_billing_phone();
            $customer_mobile = $customer->get_billing_phone();
            $customer_email = $customer->get_email();

            //Fiscal Data
            $alegra_order_document_id = $customer->get_meta('alegra_user_tax_id');
            $alegra_order_document_type = $customer->get_meta('alegra_user_document_type');
        } else {

            //The order is not empty, lets use its data

            //Build Customer Address
            $country_code = $order->get_billing_country();
            $state_code = $order->get_billing_state();
            $countries_obj = new WC_Countries();
            $countries_array = $countries_obj->get_countries();
            $country_states_array = $countries_obj->get_states();
            $country_name = $countries_array[$country_code];
            $state_name = $country_states_array[$country_code][$state_code];
            $address = (!empty($order->get_billing_address_2())) ? $order->get_billing_address_1() . " " . $order->get_billing_address_2() : $order->get_billing_address_1();

            //Customer Data
            $customer_name = $order->get_formatted_billing_full_name();
            $customer_phone = $order->get_billing_phone();
            $customer_mobile = $order->get_billing_phone();
            $customer_email = $order->get_billing_email();

            $alegra_order_document_id = $order->get_meta('alegra_order_document_id');
            $alegra_order_document_type = $order->get_meta('alegra_order_document_type');
        }



        // Create a mapping of English to Spanish country names
        $country_translation = array(
            'Dominican Republic' => 'República Dominicana',
            // Add more translations as needed
        );

        // Get the country name and translate it if necessary
        if (array_key_exists($country_name, $country_translation)) {
            $country_name = $country_translation[$country_name];
        }

        // Define contact data based on Alegra's JSON structure
        $contact_data = array(
            'address' => array(
                'province' => $state_name,
                'description' => $address,
                'country' => $country_name,
            ),
            'identificationObject' => array(),
            'name' => $customer_name,
            'phonePrimary' => $customer_phone,
            'mobile' => $customer_mobile,
            'email' => $customer_email,
            'type' => 'client', // this could come from a field in the admin 
        );


        if (!empty($alegra_order_document_id) && !empty($alegra_order_document_type)) {

            $contact_data['identificationObject'] = array(
                'type' => $alegra_order_document_type,
                'number' => $alegra_order_document_id,
            );
        }

        $alegra_user_id = '';

        if ((int)$user_id > 0) {

            $alegra_user_id = get_user_meta($user_id, 'alegra_user_id', true);

            if (empty($alegra_user_id)) {
                //The current user has no meta, but maybe exists in alegra with name and email
                $alegra_user_id = self::alegra_wc_check_user_by_email($customer_name, $customer_email);
            }
        }

        $request_type = (!empty($alegra_user_id) ? 'PUT' : 'POST');
        $endpoint = (!empty($alegra_user_id) ? 'contacts/' . $alegra_user_id : 'contacts');

        $call_response = self::alegra_wc_api_request($request_type, $endpoint, $contact_data);

        // Check if the API request was successful
        if (in_array($call_response['code'], array(200, 201)) && isset($call_response['data']['id'])) {

            //Response was successful, check for its content
            SELF::alegra_log(__METHOD__ . "(): " . 'user creation Suceeeded. ID => ' . $call_response['data']['id']);

            // Store the Alegra user ID as user meta if not guest
            if ($user_id > 0) {

                update_user_meta($user_id, 'alegra_user_id', $call_response['data']['id']);
                update_user_meta($user_id, 'alegra_user_tax_id', $alegra_order_document_id);
                update_user_meta($user_id, 'alegra_user_document_type', $alegra_order_document_type);

                // Store the current date and time as user meta
                $current_time = current_time('mysql');
                update_user_meta($user_id, 'alegra_user_date_created', $current_time);
            }

            $return['success'] = true;
            $return['message'] = 'Contact Created / Updated Successfully. ID: ' . $call_response['data']['id'];
            $return['data'] = $call_response;
        } else {
            SELF::alegra_log(__METHOD__ . "(): " . 'user creation failed. => ' . print_r($call_response, true), 'error');

            $return['success'] = false;
            $return['message'] = $call_response['data']['message'];
            $return['data'] = $call_response;
        }


        return $return;
    }

    public static function alegra_wc_get_numberTemplate_ID($alegra_order_type)
    {

        SELF::alegra_log(__METHOD__ . "(): " . 'Getting the Number Template ID for order type ' . $alegra_order_type);

        // Find the position of the last underscore
        $lastUnderscorePos = strrpos($alegra_order_type, '_');

        if ($lastUnderscorePos === false) {

            SELF::alegra_log(__METHOD__ . "(): " . 'Order type is invalid', 'error');
            // If there's no underscore, return null or handle as needed
            return null;
        }
        // Split the string into parts
        $prefix = substr($alegra_order_type, $lastUnderscorePos + 1);
        $documentType = substr($alegra_order_type, 0, $lastUnderscorePos);

        // Define the endpoint for the API call
        $endpoint = 'number-templates?documentType=' . $documentType;

        // Make the API call to Alegra
        $response = self::alegra_wc_api_request('GET', $endpoint);

        if (in_array($response['code'], array(200, 201)) && is_array($response['data'])) {

            //Response was successful, check for its content
            $response = $response['data'];

            // Loop through the response array to find the matching 'prefix'
            foreach ($response as $template) {
                if (isset($template['prefix']) && $template['prefix'] === $prefix) {
                    return $template;
                }
            }
        } else {

            SELF::alegra_log(__METHOD__ . "(): " . 'Number Template validation failed. => ' . print_r($response, true), 'error');

            // Return null if no matching template was found
            return null;
        }
    }

    public function alegra_wc_create_invoice($order_id)
    {

        SELF::alegra_log(__METHOD__ . "(): " . 'About to create order ID ' . $order_id . " in Alegra...");

        $invoice_data = array();

        $order = wc_get_order($order_id);

        if (!$order) {

            SELF::alegra_log(__METHOD__ . "(): " . 'There was an error creating the order. The order is not valid in WC.', 'error');
            $return['success'] = false;
            $return['data'] = array();
            $return['message'] = "There was an error creating the order " . $order_id . " The order is not valid in WooCommerce.";

            return $return;
        }

        $is_fiscal_order = $order->get_meta('comprobante_fiscal');

        if (!$is_fiscal_order) {

            //The order is not Fiscal, just Bail.
            $return['success'] = false;
            $return['data'] = array();
            $return['message'] = "The order " . $order_id . " is not Fiscal, so it won't go to Alegra. Provide the Fiscal details to send it to Alegra.";


        } else {

            // Get current date in yyyy-mm-dd format
            $current_date = date('Y-m-d', current_time('timestamp'));

            // P3 this could be a Setting: Set due date of invoices by default
            $due_date = date('Y-m-d', strtotime($current_date . ' + 15 days'));

            $Payment_options = $this->wc_alegra_get_payment_method($order);

            // Initialize the invoice data array

            $invoice_data = array(
                "stamp" => array(
                    "generateStamp" => false,
                ),
                "paymentType" => $Payment_options['PaymentType'],
                "paymentMethod" => $Payment_options['PaymentMethod'],
                "termsConditions" => get_option('alegra_wc_tyc'),
                "date" => $current_date,
                "dueDate" => $due_date,
                "anotation" => get_option('alegra_wc_annotations'),
                "items" => array(),
            );

            $alegra_order_type = $order->get_meta('alegra_order_type');

            $this->alegra_log('This is a Fiscal order. Determine the Sequence to Use for order type [' . $alegra_order_type  .  ']');

            $numberTemplate = $this->alegra_wc_get_numberTemplate_ID($alegra_order_type);

            if ($numberTemplate) {
                $invoice_data['numberTemplate'] = array(
                    'id' => $numberTemplate['id']
                );
            } else {
                SELF::alegra_log(__METHOD__ . "(): " . 'The sequence for Order Type [' . $alegra_order_type  .  '] is not set in Alegra. This invoice can not be created.', "error");
                $return['success'] = false;
                $return['message'] = 'The sequence for Order Type [' . $alegra_order_type  .  '] are not set in Alegra. This invoice can not be created in Alegra.';
                $return['data'] = array();
                $order->add_order_note($return['message']);
                return $return;
            }

            $user_id = $order->get_customer_id();

            // Get customer ID from the 'alegra_user_id' user meta
            $alegra_customer_id = get_user_meta($user_id, 'alegra_user_id', true);


            if (!$alegra_customer_id) {

                SELF::alegra_log(__METHOD__ . "(): " . 'user Dont have the Alegra Meta, checking if it needs to be created...', 'notice');

                $customer_name = $order->get_formatted_billing_full_name();
                $customer_email = $order->get_billing_email();

                $endpoint = 'contacts?mode=simple&query=' . $customer_name;

                $response = self::alegra_wc_api_request('GET', $endpoint);

                if (in_array($response['code'], array(200, 201))) {

                    //Response was successful, check for its content
                    $response = $response['data'];

                    foreach ($response as $alegra_contact) {

                        if ($alegra_contact['email'] = $customer_email) {
                            //The user was found in alegra by searching its name and email... break
                            SELF::alegra_log(__METHOD__ . "(): " . 'user has no Meta in WP, but was found in Alegra, using this ID...', 'notice');
                            $alegra_customer_id = $alegra_contact['id'];
                            update_user_meta($user_id, 'alegra_user_id', $alegra_customer_id);
                            break;
                        }
                    }
                }

                if (!$alegra_customer_id) {

                    SELF::alegra_log(__METHOD__ . "(): " . "user wasn't found in Alegra, creating it...", 'notice');

                    $creation = $this->alegra_wc_create_contact($user_id, $order);

                    if ($creation['success'] === true) {
                        $alegra_customer_id = $creation['data']['id'];
                    } else {

                        SELF::alegra_log(__METHOD__ . "(): " . 'user creation failed while creating invoice. ' . print_r($creation['data'], true), 'error');
                        $return['success'] = false;
                        $return['data'] = $creation;
                        $return['message'] = $creation['data']['message'];
                        return $return;
                    }
                }
            }

            $invoice_data['client'] = array(
                "id" => $alegra_customer_id,
            );

            // Get order items
            foreach ($order->get_items() as $item_id => $item) {

                $product = $item->get_product();
                $product_id = $product->get_id();

                $alegra_product_id = get_post_meta($product_id, 'wc_alegra_product_id', true);

                if (empty($alegra_product_id)) {
                    SELF::alegra_log(__METHOD__ . "(): " . 'Warning => ' . $product_id . " does NOT have an Alegra ID. Attempting to create it...", 'notice');

                    //Lets try to create the product.
                    $product_creation = $this->alegra_wc_create_product($product_id);
                    $alegra_product_id = get_post_meta($product_id, 'wc_alegra_product_id', true);

                    if ($product_creation['success']) {

                        $alegra_product_id = get_post_meta($product_id, 'wc_alegra_product_id', true);
                    } else {

                        //The product creation failed. Stop the invoice creation
                        $return['success'] = false;
                        $return['message'] = "Invoice creation failed. The Product id " . $product_id . " couldn't be created. " . $product_creation['data'];
                        $return['data'] = $product_creation;
                        return $return;
                    }
                }


                // Build the item data and add it to the items array
                $item_data = array(
                    "id" => $alegra_product_id,
                    "quantity" => $item->get_quantity(),
                    "price" => $item->get_total(),
                );


                if ($product->is_taxable()) {

                    //If the product is taxable, determine what tax is and match it with Alegra
                    $wc_tax = $this->wc_alegra_set_item_tax($item);

                    if (!empty($wc_tax)) {
                        $item_data['tax'][] = $wc_tax;
                    }
                }

                $invoice_data["items"][] = $item_data;
            }

            // Check if the "wc_alegra_invoice_id" meta field exists for the current order
            $alegra_invoice_id = get_post_meta($order_id, 'alegra_invoice_id', true);

            // Determine the request type and endpoint based on the existence of "wc_alegra_invoice_id"
            if (!empty($alegra_invoice_id)) {
                // If "alegra_invoice_id" exists, update the existing order in Alegra
                SELF::alegra_log(__METHOD__ . "(): " . ' Invoice already exists, updating it in Alegra on Invoice ID => ' . $alegra_invoice_id, 'notice');
                $request_type = 'PUT';
                $endpoint = 'invoices/' . $alegra_invoice_id;
            } else {
                // If "alegra_invoice_id" doesn't exist, create a new order in Alegra
                $request_type = 'POST';
                $endpoint = 'invoices';
            }

            $response = self::alegra_wc_api_request($request_type, $endpoint, $invoice_data);

            // Check if the API request was successful
            if (in_array($response['code'], array(200, 201)) && isset($response['data']['id'])) {

                //Response was successful, check for its content
                $response = $response['data'];

                SELF::alegra_log(__METHOD__ . "(): " . 'Success creating invoice! => ' . print_r($response, true));

                $alegra_invoice_id = $response['id'];

                $order->update_meta_data('alegra_invoice_id', $alegra_invoice_id);

                // Store the current date and time as order meta
                $current_time = current_time('mysql');
                $order->update_meta_data('alegra_invoice_date_created', $current_time,);

                $order->save();

                $return['success'] = true;
                $return['message'] = "Success syncing the Invoice. Invoice ID " . $alegra_invoice_id . ".";

                $stamp = array(
                    'ids' => array(
                        $alegra_invoice_id
                    )
                );

                //BUG trying to stamp an invoice to generate the nfc returns "La información registrada de tu compañia está incompleta o debe revisarse para la emisión de documentos electrónicos"

                //$stamp_response = self::alegra_wc_api_request('POST', 'invoices/stamp', $stamp);


            } else {

                SELF::alegra_log(__METHOD__ . "(): " . 'Invoice creation failed. => ' . print_r($response, true), 'error');

                $return['success'] = false;
                $return['message'] = "Invoice creation failed. " . $response['data']['message'];
            }

            $return['data'] = $response;
        }

        //P3 Would be useful to register actions to execute stuff after a succesful creation

        return $return;
    }

    public function wc_alegra_set_item_tax($item)
    {

        $wc_tax = array();
        $tax_rate_18_exists = false;
        $taxes = array();

        if (is_a($item, 'WC_Order_Item_Product')) {
            // Get the tax rates applied to the order item
            $taxes = $item->get_taxes();
        } elseif (is_int($item)) {
            // Get the product object
            $product = wc_get_product($item);

            // Check if the product is taxable
            if ($product) {
                // Get the tax rates applied to the product
                $tax_class = $product->get_tax_class();
                $tax_rates = WC_Tax::get_rates($tax_class);

                // Construct the taxes array similar to how it would be for an order item
                foreach ($tax_rates as $tax_rate_id => $tax_rate) {
                    $taxes['total'][$tax_rate_id] = $tax_rate['rate'];
                }
            }
        }

        foreach ($taxes['total'] as $tax_rate_id => $tax_amount) {
            $tax_rate = WC_Tax::_get_tax_rate($tax_rate_id);
            if (isset($tax_rate['tax_rate']) && $tax_rate['tax_rate'] == '18.0000') {
                $tax_rate_18_exists = true;
                break;
            }
        }

        // If the tax rate of 18.000 exists, add the tax data to the item_data array
        if ($tax_rate_18_exists) {
            $this->alegra_log('This is a Fiscal order. Adding Taxes...');
            $wc_tax = array(
                'id' => $this->alegra_wc_get_alegra_taxes()
            );
        }

        return $wc_tax;
    }

    public function wc_alegra_get_payment_method($order)
    {
        $payment_method = $order->get_payment_method();
        $payment_status = $order->get_status();

        // Define the default values
        $payment_type = 'CREDIT';
        $payment_subtype = '';

        // Check if the order has been paid
        if ($payment_status === 'completed' || $payment_status === 'processing') {
            $payment_type = 'CASH'; // Order has been paid or will be paid on delivery
            // Define equivalent options based on payment method
            switch ($payment_method) {
                case 'cheque':
                    $payment_subtype = 'check';
                    break;
                case 'bacs':
                    $payment_subtype = 'transfer';
                    break;
                case 'cod':
                    $payment_subtype = 'cash';
                    break;
                case 'credit-card':
                    $payment_subtype = 'credit-card';
                    break;
                    // Add more payment method cases as needed
            }
        }

        return array(
            'PaymentType' => $payment_type,
            'PaymentMethod' => $payment_subtype,
        );
    }

    //Log to the Woocommerce Logging system. 
    public static function alegra_log($data, $level = 'debug')
    {
        //Get the debug mode
        if (get_option('alegra_wc_debug') == 'no') {
            //Debug mode not set, exit.
            return;
        } else {

            $context = array('source' => 'alegra-wc-sync');
            // LOAD THE WC LOGGER    
            $logger = wc_get_logger();
            $logger->log($level, wc_print_r($data, true), $context);
        }
    }

    public static function alegra_wc_create_inventory_adjustment($product_id, $operation, $stock_adjustment, $alegra_unit_cost, $user_id = null)
    {

        $alegra_product_id = get_post_meta($product_id, 'wc_alegra_product_id', true);

        if ($alegra_product_id) {

            $observations = 'Automatic Adjustment made via Alegra WC Sync Plugin.';
            $observations .= $user_id > 0 ? 'Added by User ID ' . $user_id : '';
            $date = date('Y-m-d');
            $items[] = array(
                'type' => $operation,
                "id" => intval($alegra_product_id),
                "unitCost" => $alegra_unit_cost,
                "quantity" => $stock_adjustment
            );

            $content = array(
                'date' => $date,
                'observations' => $observations,
                'items' => $items
            );
        } else {
            $error = 'The Product Variation doesnt exists in Alegra. Has to be created...';
            $response = array(
                'data' => $error
            );
            AlegraWCSync::alegra_log(__METHOD__ . "(): Inventory Adjustment Failed: " . $error, 'error');
            //wp_send_json_error($response);
            //wp_die();
            $response['success'] = false;
            return $response;
        }

        $endpoint = 'inventory-adjustments';


        $call_response = SELF::alegra_wc_api_request('POST', $endpoint, $content);

        if (in_array($call_response['code'], array(200, 201)) && isset($call_response['data']['id'])) {

            //Response was successful, check for its content
            $call_response = $call_response['data'];

            SELF::alegra_log(__METHOD__ . "(): " . 'Inventory Adjustment created Successfully. ID => ' . $call_response['id']);
            $response['success'] = true;
        } else {
            SELF::alegra_log(__METHOD__ . "(): " . 'Inventory Adjustment Creation Failed. ' . print_r($call_response, true), 'error');
            $response['success'] = false;
        }

        $response['data'] = $call_response;

        return $response;
    }

    public static function alegra_wc_check_for_inventory_adjustments()
    {

        //Get all Inventory Adjustments and product purchases from Alegra 
        $purchases = SELF::alegra_wc_api_request('GET', 'bills');

        if (in_array($purchases['code'], array(200, 201))) {
            //Only get inventory adjustments if it was successfully connected to get the purchases
            $adjustments = SELF::alegra_wc_api_request('GET', 'inventory-adjustments');
        } else {

            AlegraWCSync::alegra_log(__METHOD__ . "(): " . 'Getting inventory adjustments failed. ' . print_r($purchases, true), 'error');
            $return['success'] = false;
            $return['data'] = $purchases['data']['message'];

            return $return;
        }

        $inventory_updates = array_merge($purchases['data'], $adjustments['data']);

        //P1 an extra validation is required in order to confirm that the response are inventory updates.

        if (is_array($inventory_updates) && count($inventory_updates) > 0) {

            $inventories = array();

            foreach ($inventory_updates as $inventory_update) {

                $notes = $inventory_update['observations'];

                if (!empty($notes) && stripos($notes, "WooCommerce Sync") !== false) {

                    //Do nothing, as this has been already updated.
                    SELF::alegra_log(__METHOD__ . "(): " . 'The Inventory Update Transaction ID ' . $inventory_update['id'] . ' has already been synced.');
                    continue;
                } else {

                    if (isset($inventory_update['purchases'])) {

                        $items = $inventory_update['purchases']['items'];
                        $adjustment_type = 'bills';
                    } else {
                        $items = $inventory_update['items'];
                        $adjustment_type = 'inventory-adjustments';
                    }

                    array_push($inventories, $inventory_update['id']);

                    SELF::alegra_log(__METHOD__ . "(): " . 'A new Inventory Update of type ' . $adjustment_type .  ' is pending to be synced. Alegra Purchase ID ' . $inventory_update['id']);

                    $schedule_id = as_enqueue_async_action("alegra_wc_adjust_product_inventory", array($inventory_update['id'], $items, $inventory_update['observations'], $adjustment_type));

                    if ($schedule_id) {
                        SELF::alegra_log(__METHOD__ . "(): " . 'The Inventory Update ID ' . $inventory_update['id'] . ' has been scheduled to update.');
                    } else {
                        SELF::alegra_log(__METHOD__ . "(): " . 'There was an error scheduling the Inventory Update.', 'error');
                    }
                }
            }
        } else {
            SELF::alegra_log(__METHOD__ . "():Theres no Inventory Update Transaction to Sync. Nothing returned from Alegra.");
        }

        if (!empty($inventories)) {
            $response = 'The following inventory updates are scheduled to be synced: ' . print_r(implode(', ', $inventories), true) . ".";
        } else {
            $response = 'All inventory updates (purchases and inventory adjustments) have been synced.';
        }
        return array(
            'success' => true,
            'data' => $response
        );
    }

    public static function alegra_wc_adjust_product_inventory($adjustment_id, $adjustment_items, $observation, $adjustment_type)
    {

        SELF::alegra_log(__METHOD__ . "(): " . 'About to adjust Inventory with an adjustment ID ' . print_r($adjustment_id, true) . " and type " . $adjustment_type . ". Payload => " . print_r($adjustment_items, true));

        $failed_products = [];

        foreach ($adjustment_items as $inventory_item) {
            $args = array(
                'post_type' => array('product', 'product_variation'),
                'post_status' => 'publish',
                'meta_query' => array(
                    array(
                        'key' => 'wc_alegra_product_id',
                        'value' => $inventory_item['id'],
                        'compare' => '=',
                    ),
                ),
            );

            $products = new WP_Query($args);

            if ($products->have_posts()) {
                while ($products->have_posts()) {
                    $products->the_post();
                    $product_id = get_the_ID();
                    $product = wc_get_product($product_id);

                    if ($product) {
                        $current_stock_qty = $product->get_stock_quantity();
                        if (isset($inventory_item['type'])) {
                            $new_qty = max(($inventory_item['type'] == 'in' ? $current_stock_qty + $inventory_item['quantity'] : $current_stock_qty - $inventory_item['quantity']), 0);
                            $unitCost = $inventory_item['unitCost'];
                        } else {
                            $new_qty = $current_stock_qty + $inventory_item['quantity'];
                            $unitCost = $inventory_item['price'];
                        }

                        $product->update_meta_data('wc_alegra_unit_cost', $unitCost);
                        $product->set_stock_quantity($new_qty);
                        $product->save();
                    } else {
                        SELF::alegra_log(__METHOD__ . "(): " . 'Inventory Adjustment Update Failed. The product ID ' . $product_id . ' doesnt seems to be valid.', 'error');
                    }
                }

                wp_reset_postdata();
            } else {
                SELF::alegra_log(__METHOD__ . "(): " . 'Inventory Adjustment Update Failed. No product found with ID ' . $inventory_item['id'] . ".", 'error');
                $failed_products[] = $inventory_item['id'];
            }
        }

        $new_observation = $observation . ' // WooCommerce Sync processed on ' . date('d-m-Y H:i:s', current_time('timestamp') . ".");

        if (!empty($failed_products)) {

            $new_observation .=  '. The following products were not found in WooCommerce: ' . implode(',', $failed_products) . '.';
        }

        $content = array(
            'observations' => $new_observation
        );

        $call_response = SELF::alegra_wc_api_request('PUT', $adjustment_type . '/' . $adjustment_id, $content);

        if (in_array($call_response['code'], array(200, 201)) && isset($call_response['data']['id'])) {

            //Response was successful, check for its content
            $call_response = $call_response['data'];

            SELF::alegra_log(__METHOD__ . "(): " . 'Inventory Adjustment Updated Successfully. ID => ' . $call_response['id']);

            $response['success'] = true;
        } else {
            SELF::alegra_log(__METHOD__ . "(): " . 'Inventory Adjustment Update Failed. ' . print_r($call_response, true), 'error');
            $response['success'] = false;
        }
        SELF::alegra_log(__METHOD__ . "(): " . 'Inventory Adjustment Update ' . print_r($adjustment_id, true) . ' Finished. ');
        return $response;
    }



    public function create_scheduled_product($request_type, $endpoint, $content, $product_id)
    {

        SELF::alegra_log(__METHOD__ . "(): " . 'About to Sync the Product ID ' . $product_id . ' to Alegra...');

        $call_response = $this->alegra_wc_api_request($request_type, $endpoint, $content);

        if (in_array($call_response['code'], array(200, 201)) && isset($call_response['data']['id'])) {

            //Response was successful, check for its content
            $call_response = $call_response['data'];

            SELF::alegra_log(__METHOD__ . "(): " . 'Product succesfully Synced with Alegra Product ID ' . $call_response['id'] . '. Updating Meta...');


            // Update the Alegra Product ID meta field if the request was successful
            update_post_meta($product_id, 'wc_alegra_product_id', $call_response['id']);
            update_post_meta($product_id, 'wc_alegra_sync_status', 'Synced');
            update_post_meta($product_id, 'wc_alegra_last_synced', date_i18n('Y-m-d H:i:s'));

            //If the updated product was a variation, mark its parent as updated on this timestamp as well
            $product = wc_get_product($product_id);
            if ($product->is_type('variation')) {
                $product_parent = $product->get_parent_id();
                update_post_meta($product_parent, 'wc_alegra_last_synced', date_i18n('Y-m-d H:i:s'));
            }


            $response['success'] = true;
        } else {
            SELF::alegra_log(__METHOD__ . "(): " . 'Product Creation Failed. ' . print_r($call_response, true), 'error');
            $response['success'] = false;
        }
        $response['data'] = $call_response;
        return $response;
    }

    public function create_scheduled_category($request_type, $endpoint, $content, $category_id)
    {

        SELF::alegra_log(__METHOD__ . "(): " . 'About to Sync the Category ID ' . $category_id . ' to Alegra...');

        $call_response = $this->alegra_wc_api_request($request_type, $endpoint, $content);

        if (in_array($call_response['code'], array(200, 201)) && isset($call_response['data']['id'])) {

            //Response was successful, check for its content
            $call_response = $call_response['data'];

            update_term_meta($category_id, 'alegra_taxonomy_id', $call_response['id']);
            SELF::alegra_log(__METHOD__ . "(): " . ' Category Created Succesfully in Alegra. Alegra Category ID ' . $call_response['id']);
            $response['success'] = true;
        } else {
            SELF::alegra_log(__METHOD__ . "(): " . 'Product Creation Failed. ' . print_r($call_response, true), 'error');
            $response['success'] = false;
        }
        $response['data'] = $call_response;
        return $response;
    }

    public function alegra_wc_get_alegra_taxes()
    {
        $alegra_taxes = $this->alegra_wc_api_request('GET', 'taxes');
        if (in_array($alegra_taxes['code'], array(200, 201))) {

            foreach ($alegra_taxes['data'] as $alegra_tax) {
                //Find the Tax Type ITBIS that is equal to the 18%
                if ($alegra_tax['type'] == 'ITBIS' && $alegra_tax['percentage'] == '18.00') {
                    return $alegra_tax['id'];
                }
            }
            SELF::alegra_log('No corresponding Tax was found in Alegra. => ' . print_r($alegra_taxes, true), 'error');
            //If this point is reached, return false

            return false;
        }
        SELF::alegra_log('There was an error obtaining the Taxes from Alegra. => ' . print_r($alegra_taxes, true), 'error');

        return false;
    }

    public function alegra_wc_get_alegra_order($alegra_invoice_id, $order_id = '')
    {

        //Obtain the order details from Alegra
        if (!empty($alegra_invoice_id)) {

            $alegra_order = $this->alegra_wc_api_request('GET', 'invoices/' . $alegra_invoice_id);

            if (in_array($alegra_order['code'], array(200, 201)) && isset($alegra_order['data']['id'])) {

                //Response was successful, check for its content
                $alegra_order = $alegra_order['data'];

                return $alegra_order;
            }
        }
    }

    public static function alegra_wc_get_alegra_categories()
    {
        //Using a transient to prevent an API call for this. 
        if (is_array(get_transient('alegra_wc_categories_array'))) {
            $categories = get_transient('alegra_wc_categories_array');
        } else {
            $alegra_categories = SELF::alegra_wc_api_request('GET', 'item-categories?status=active');
            $categories = [];
            if (in_array($alegra_categories['code'], array(200, 201))) {

                //Response was successful, check for its content
                $alegra_categories = $alegra_categories['data'];
                foreach ($alegra_categories as $alegra_cat) {
                    $categories[$alegra_cat['id']] = $alegra_cat['name'];
                }
            }
            set_transient('alegra_wc_categories_array', $categories, DAY_IN_SECONDS);
        }
        return $categories;
    }

    public static function alegra_wc_check_user_by_email($name, $email)
    {

        SELF::alegra_log(__METHOD__ . "(): " . 'Getting all contacts by name...');

        $endpoint = 'contacts?mode=simple&query=' . $name;

        $response = self::alegra_wc_api_request('GET', $endpoint);

        $alegra_user_id = '';

        if (in_array($response['code'], array(200, 201))) {

            foreach ($response as $alegra_contact) {

                if ($alegra_contact['email'] == $email) {
                    //The user was found in alegra by searching its name and email... break
                    SELF::alegra_log(__METHOD__ . "(): " . 'user was found in Alegra using email ' . $email, 'info');
                    $alegra_user_id = $alegra_contact['id'];
                    break;
                }
            }
        }
        return $alegra_user_id;
    }

    // Save the custom order data when the order is updated
    public function alegra_wc_save_custom_order_data($order_id = '')
    {

        if (empty($order_id)) {
            // Maybe was called from AJAX, get the order ID from a jQuery parameter
            $order_id = isset($_POST['order_id']) ? sanitize_text_field($_POST['order_id']) : '';
        }

        // Make sure order exists and is valid
        $order = wc_get_order($order_id);

        if (!$order || !is_a($order, 'WC_Order')) {
            // Order doesn't exist or is not valid, handle the validation error
            // You can return an error message, log an error, or perform other actions
            SELF::alegra_log(__METHOD__ . "(): " . ' Order data update failed. The supplied order is not valid or empty.', 'error');
            return;
        }

        if (isset($_POST['comprobante_fiscal'])) {
            $comprobante_fiscal = sanitize_text_field($_POST['comprobante_fiscal']);
            $order->update_meta_data('comprobante_fiscal', $comprobante_fiscal);
        }

        if (isset($_POST['alegra_order_document_id'])) {
            $alegra_order_document_id = sanitize_text_field($_POST['alegra_order_document_id']);
            $order->update_meta_data('alegra_order_document_id', $alegra_order_document_id);
        }

        if (isset($_POST['alegra_order_type'])) {
            $alegra_order_type = sanitize_text_field($_POST['alegra_order_type']);
            $order->update_meta_data('alegra_order_type', $alegra_order_type);
        }

        if (isset($_POST['alegra_order_document_type'])) {
            $alegra_order_document_type = sanitize_text_field($_POST['alegra_order_document_type']);
            $order->update_meta_data('alegra_order_document_type', $alegra_order_document_type);
        }

        $order->save();
    }
}
