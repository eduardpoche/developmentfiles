<?php
class Alegra_WC_Sync
{

    public function __construct()
    {
        // Add hooks and actions here for syncing inventory and generating invoices.
        add_action('init', array($this, 'alegra_wc_register_custom_meta_fields'));
        // add_action('created_term', [$this, 'alegra_wc_create_variant_attribute'], 10, 3);
        add_action('create_product_cat', [$this, 'alegra_wc_create_category']);
        add_action('edited_product_cat', [$this, 'alegra_wc_create_category']);
        add_action('admin_init', [$this, 'alegra_wc_activation_redirect']);
        add_action('admin_notices', [$this, 'alegra_ITBIS_creation_notice']);
        add_action('alegra_to_wc_inventory_sync', array($this, 'alegra_to_wc_inventory_sync'));
        add_action('create_scheduled_product', array($this, 'create_scheduled_product'), 10, 4);
        add_action('create_scheduled_category', array($this, 'create_scheduled_category'), 10, 4);
        add_action('create_alegra_product_in_wc', array($this, 'create_alegra_product_in_wc'), 10, 2);
        add_action('admin_notices', [$this, 'alegra_display_admin_notices']);
    }


    public function alegra_wc_activation_redirect()
    {
        // Make sure it's the correct user
        if (!wp_doing_ajax() && intval(get_option('alegra_activation_redirect')) === wp_get_current_user()->ID) {
            // Make sure we don't redirect again after this one
            delete_option('alegra_activation_redirect');
            wp_safe_redirect(admin_url('admin.php?page=wc-settings&tab=alegra_settings'));
            exit;
        }
    }

    public function alegra_wc_register_custom_meta_fields()
    {
        // Register custom meta for WooCommerce attributes
        register_meta('pa_custom_attribute', '_alegra_attribute_id', array(
            'type' => 'string',
            'single' => true,
            'show_in_rest' => true,
        ));

        // Register custom meta for WooCommerce terms
        register_meta('product_attribute', '_alegra_term_id', array(
            'type' => 'string',
            'single' => true,
            'show_in_rest' => true,
        ));
    }

    /** 
     * If the Taxes has not been configured properly, display an admin notice. 
     */
    public function alegra_ITBIS_creation_notice()
    {
        $taxes = Alegra_WC_Taxes::get_tax_class_by_rate('18.00');
        if ($taxes == '') {
            $msg = __('No se ha configurado ningún impuesto equivalente al ITBIS para poder generar facturas fiscales con Alegra.', 'alegra-wc-sync');
            $msg = sprintf($msg, 'alegra-wc-sync');
?>
            <div class="notice notice-error" style="padding: 15px; position: relative">
                <?php echo $msg; ?>

                <a href="<?php echo admin_url('admin.php?page=wc-settings&tab=tax'); ?>">
                    <?php _e('Configurar los impuestos', 'alegra-wc-sync'); ?>.
                </a>

            </div>
<?php
        }
    }


    public static function alegra_wc_create_variant_attribute($term_id, $tt_id, $taxonomy_slug)
    {
        //P3 Maybe we need to alter the response of the attribute creation in the frontend to reflect a failure.

        if ((!empty($term_id) && !empty($taxonomy_slug)) && taxonomy_exists($taxonomy_slug)) {

            Alegra_WC_Logs::log(__METHOD__, "Creating Variant Attributes for Term ID " . $term_id . " ; Taxonomy ID " . $tt_id . " and Taxonomy Slug " . $taxonomy_slug);

            // Get the taxonomy
            $taxonomy = get_taxonomy($taxonomy_slug);

            $attribute_data = array(
                'name' => $taxonomy->labels->singular_name,
                'options' => array(),
                'status' => 'active'
            );

            // Get the created term
            $term = get_term($term_id, $taxonomy_slug);

            //For some reason $tt_id in the method doesn't pass the Taxonomy ID, so we obtain it via the slug
            $tt_id = wc_attribute_taxonomy_id_by_name($taxonomy_slug);

            $alegra_tax_id = get_term_meta($tt_id, '_alegra_attribute_id', true);

            //Set the Alegra Endpoint and Methods to create or update
            $method = 'POST';
            $endpoint = 'variant-attributes';

            if ($alegra_tax_id) {

                //Exists, has to be updated

                Alegra_WC_Logs::log(__METHOD__, "The Alegra Tax ID exists for Taxonomy " . $taxonomy_slug . " ; Updating it...");

                $attribute_data['id'] = $alegra_tax_id;
                $method = 'PUT';
                $endpoint = $endpoint . '/' . $alegra_tax_id;

                //Get current taxonomies terms, they are required to update
                $current_alegra_taxonomy = Alegra_WC_API::alegra_wc_api_request('GET', 'variant-attributes/' . $alegra_tax_id);

                if (in_array($current_alegra_taxonomy['code'], array(200, 201)) && isset($current_alegra_taxonomy['data']['id'])) {

                    foreach ($current_alegra_taxonomy['options'] as $value) {
                        $attribute_data['options'][] = $value;
                    }
                } else {
                    Alegra_WC_Logs::log(__METHOD__, 'an error ocurred. ' . wc_print_r($current_alegra_taxonomy, true), 'error');
                    return false;
                }
            }

            // Update the attribute data
            $attribute_data['options'][] = array(
                'value' => $term->name,
            );

            // Perform the Alegra API request here to create the attribute and terms
            $response = Alegra_WC_API::alegra_wc_api_request($method, $endpoint, $attribute_data);

            if (in_array($response['code'], array(200, 201)) && isset($response['data']['id'])) {
                //Response was successful, check for its content
                $response = $response['data'];

                $attribute_id = $response['id'];

                //To update the newly created term, need to find its ID in the response.

                foreach ($response['options'] as $alegra_term) {

                    if ($alegra_term['value'] == $term->name) {

                        $alegra_term_id = $alegra_term['id'];
                    }
                }

                // Update custom meta for the Taxonomy with Alegra attribute ID
                update_term_meta($tt_id, '_alegra_attribute_id', $attribute_id);

                // Update custom meta for the term with Alegra term ID
                update_term_meta($term_id, '_alegra_term_id', $alegra_term_id);

                return true;
            } else {

                Alegra_WC_Logs::log(__METHOD__, 'an error ocurred. ' . wc_print_r($response, true), 'error');
                return false;
            }
        }
    }

    public function alegra_wc_build_product_data($product_id)
    {
        Alegra_WC_Logs::log(__METHOD__, 'Building product data for Product ' . $product_id);

        $product = wc_get_product($product_id);

        $item_data  = array(
            'name' => $product->get_name(),
            'description' => $product->get_description(),
            'reference' => $product->get_sku(),
            'price' => wc_get_price_to_display($product),
            'tax' => []
        );

        if ($product->is_taxable()) {

            //If the product is taxable, determine what tax is and match it with Alegra
            $wc_tax = $this->wc_alegra_set_item_tax($product);

            if (!empty($wc_tax)) {
                $item_data['tax'][] = $wc_tax;
            }
        }

        if ($product->managing_stock()) {


            $product_unit = (empty($product->get_meta('wc_alegra_product_unit')) ? 'LB' : $product->get_meta('wc_alegra_product_unit'));

            //The unit cost can be set at variation level, or parent product level. Check on parent level.
            if (empty($product->get_meta('wc_alegra_unit_cost')) && $product->is_type('variation')) {

                $unit_cost_meta = get_post_meta($product->get_parent_id(), 'wc_alegra_unit_cost', true);
            } else {
                $unit_cost_meta = $product->get_meta('wc_alegra_unit_cost', true);
            }

            $product_unit_cost = (empty($unit_cost_meta) ? 1 : $unit_cost_meta);

            //The product has stock management, add Inventory to Alegra
            $item_inventory = array(
                'unit' => $product_unit,
                'unitCost' => $product_unit_cost,
                'negativeSale' => ($product->backorders_allowed()) ? 'true' : 'false',
                'initialQuantity' => $product->get_stock_quantity()

            );

            $item_data['inventory'] = $item_inventory;
        }

        if (!empty($product->get_meta('wc_alegra_product_category'))) {
            //There's an Alegra Category, add to the product
            $item_data['itemCategory'] = array(
                'id' => $product->get_meta('wc_alegra_product_category')
            );
        }

        $item_data['type'] = ($product->is_virtual()) ? 'service' : 'product';

        // Check if the custom field ID is already stored
        if (get_option('alegra_wc_custom_field_id')) {
            $item_data['customFields']  = array(
                array(
                    'id' => get_option('alegra_wc_custom_field_id'),
                    'value' => $product_id
                )
            );
        } else {
            //Rare case, but the custom field should exist already.
            $alegra_wc_custom_field_id = Alegra_WC_Sync::create_alegra_custom_field();

            if ($alegra_wc_custom_field_id) {
                $item_data['customFields']  = array(
                    array(
                        'id' => $alegra_wc_custom_field_id,
                        'value' => $product_id
                    )
                );
            }
        }


        return $item_data;
    }


    /**
     * Create a Category in Alegra by passing a WC Category ID.
     * @param int $CatId The WC Category ID.
     * @return object An array containing the result and a message.
     */

    public static function alegra_wc_create_category($CatId, $bulk = false, $tt_id = '', $taxonomy = '')
    {

        $send_categories = get_option('auto_create_categories_to_alegra');

        if ($send_categories == 'no' && !$bulk) {
            Alegra_WC_Logs::log(__METHOD__, 'No fue posible crear la categoría ' . $CatId . ' en Alegra: Las categorías están configuradas para crearse manualmente.', 'notice');
            return;
        }

        $message = __METHOD__ . "(): " . 'Sincronizando categoría ' . $CatId . '. a Alegra...';

        $message .= ($bulk ? ' ( Actualización masiva )' : '');

        Alegra_WC_Logs::log(__METHOD__, $message);

        $wc_taxonomy = get_term($CatId);

        $content = array(
            'name' => $wc_taxonomy->name,
            'description' => $wc_taxonomy->description,
            'status' => 'active'
        );

        $alegra_taxonomy_id = get_term_meta($CatId, 'alegra_taxonomy_id', true);

        //Depending if it has an alegra ID, either update, or create by changing request method and endpoint URL

        $request_type = (!empty($alegra_taxonomy_id) ? 'PUT' : 'POST');
        $endpoint = (!empty($alegra_taxonomy_id) ? 'item-categories/' . $alegra_taxonomy_id : 'item-categories');

        if ($bulk) {

            $schedule_id = as_enqueue_async_action("create_scheduled_category", array($request_type, $endpoint, $content, $CatId));

            if ($schedule_id) {
                Alegra_WC_Logs::log(__METHOD__, "Se programó la creación/actualización de la categoría " . $CatId . " con el método => " . $request_type);
            } else {
                Alegra_WC_Logs::log(__METHOD__, "Hubo un error programando la creación de la categoría " . $CatId . " con el método => " . $request_type, 'error');
            }
            return $schedule_id;
        }

        $response = Alegra_WC_API::alegra_wc_api_request($request_type, $endpoint, $content);

        if (in_array($response['code'], array(200, 201)) && isset($response['data']['id'])) {

            //Response was successful, check for its content
            $response = $response['data'];

            //Store the Alegra Taxonomy ID in the Category Meta
            update_term_meta($CatId, 'alegra_taxonomy_id', $response['id']);
            Alegra_WC_Logs::log(__METHOD__, ' Categoría creada exitosamente en Alegra. ID ' . $response['id'] . ".");

            return true;
        } else {

            Alegra_WC_Logs::log(__METHOD__, ' Ocurrio un error creando la categoría. ' . wc_print_r($response, true), 'error');
            return false;
        }
    }


    /**
     * Create a Product in Alegra by passing a WC product ID.
     * @param int $product_id The WC Product ID.
     * @return object An array containing the result and a message.
     */
    public function alegra_wc_create_wc_product($product_id, $bulk = false, $sync_type = 'all', $force_sync = false)
    {

        $product = wc_get_product($product_id);

        $allowed_categories = apply_filters('alegra_wc_allowed_categories', get_option('included_categories_for_alegra'));

        if (!has_term($allowed_categories, 'product_cat', $product_id) && !empty($allowed_categories)) {
            // do something else if it isn't
            Alegra_WC_Logs::log(__METHOD__, "Syncing Product ID " . $product_id . " Failed. Not in the approved categories: " . print_R($allowed_categories, true), 'error');
            $response['success'] = false;
            /* translators: %s is the Product ID */
            $response['message'] = sprintf(__('No se puede crear el producto %s: el producto no está incluido en las categorías a sincronizarse con Alegra. Verifique la configuración de categorías.', 'alegra-wc-sync'), $product_id);
            $response['data'] = sprintf(__('No se puede crear el producto %s: el producto no está incluido en las categorías a sincronizarse con Alegra. Verifique la configuración de categorías.', 'alegra-wc-sync'), $product_id);


            return $response;
        }


        if ($product->is_type('variable')) {

            //Variable products in WC are going to be handled as single products in Alegra
            Alegra_WC_Logs::log(__METHOD__, "The Product " . $product->get_name() . " is Variable. Build content for each variation... Sync Type => " . $sync_type);

            $variations = $product->get_available_variations();

            foreach ($variations as $variation) {

                $alegra_product_id = get_post_meta($variation['variation_id'], 'wc_alegra_product_id', true);

                $VariantContent = $this->alegra_wc_build_product_data($variation['variation_id']);

                if (empty($VariantContent)) {
                    Alegra_WC_Logs::log(__METHOD__, "Something went wrong building the request body for Variation ID  " . $variation['variation_id'], 'warning');
                    continue;
                }

                //Depending if it has an alegra ID, either update, or create by changing request method and endpoint URL

                $alegra_product_id = Alegra_WC_Helper::get_alegra_product_id_by_wc_id($product_id);

                $sync_info = Alegra_WC_Helper::determine_sync_method($alegra_product_id, $force_sync);

                $schedule_id = as_enqueue_async_action("create_scheduled_product", array($sync_info['request_type'], $sync_info['endpoint'], $VariantContent, $variation['variation_id']));

                $schedule_result = true;

                if ($schedule_id) {
                    Alegra_WC_Logs::log(__METHOD__, "Scheduled the Creation of Variation ID  " . $variation['variation_id'] . " With method => " . $sync_info['request_type']);
                    $schedules[] = $schedule_id;
                } else {
                    Alegra_WC_Logs::log(__METHOD__, "Something went wrong scheduling the creation of Variation ID  " . $variation['variation_id'] . " With method => " . $sync_info['request_type'], 'error');
                    $schedule_result = false;
                }
            }

            if ($schedule_result) {

                Alegra_WC_Logs::log(__METHOD__, 'Products scheduled to be created. Schedule IDs => ' . print_r($schedules, true));
                // Update the Alegra Product ID meta field if the request was successful
                $response['success'] = true;
            } else {
                Alegra_WC_Logs::log(__METHOD__, 'There was a problem Scheduling the product creation. ', 'error');
                $response['success'] = false;
            }
            $response['message'] = __('Productos programados con éxito para ser creados / actualizados.', 'alegra-wc-sync');
            return $response;
        } else {

            //Simple products, or specific variations, are addressed the same way, as simple products.

            Alegra_WC_Logs::log(__METHOD__, "Syncing the Product " . $product->get_name() . " To Alegra. Sync Type => " . $sync_type . ". Force Sync => " . $force_sync);

            $alegra_product_id = Alegra_WC_Helper::get_alegra_product_id_by_wc_id($product_id);

            $sync_info = Alegra_WC_Helper::determine_sync_method($alegra_product_id, $force_sync);

            $content = $this->alegra_wc_build_product_data($product_id);


            if ($bulk) {

                //This is a bulk creation request. Schedule the creation of the product.

                $schedule_id = as_schedule_single_action(date('U', strtotime("+5 min")), "create_scheduled_product", array($sync_info['request_type'], $sync_info['endpoint'], $content, $product_id));

                if ($schedule_id) {
                    Alegra_WC_Logs::log(__METHOD__, "Scheduled the Creation of Product ID  " . $product_id . " With method => " . $sync_info['request_type']);
                } else {
                    Alegra_WC_Logs::log(__METHOD__, "Something went wrong scheduling the creation of Variation ID  " . $product_id . " With method => " . $sync_info['request_type'], 'error');
                }
                return $schedule_id;
            }

            $call_response = Alegra_WC_API::alegra_wc_api_request($sync_info['request_type'], $sync_info['endpoint'], $content);

            if (in_array($call_response['code'], array(200, 201)) && isset($call_response['data']['id'])) {

                //Response was successful, check for its content
                $call_response = $call_response['data'];

                Alegra_WC_Logs::log(__METHOD__, 'Product succesfully Synced with Alegra Product ID ' . $call_response['id'] . '. Updating Meta of Product ID ' . $product_id . "...");

                // Update the Alegra Product ID meta field if the request was successful
                update_post_meta($product_id, 'wc_alegra_product_id', $call_response['id']);
                update_post_meta($product_id, 'wc_alegra_sync_status', 'Sincronizado');
                update_post_meta($product_id, 'wc_alegra_last_synced', date_i18n('Y-m-d H:i:s'));
                $response['success'] = true;
                /* translators: %s is the Product ID */
                $response['message'] = sprintf(__('Producto sincronizado exitosamente con Alegra. ID de producto Alegra: %s.', 'alegra-wc-sync'), $call_response['id']);
            } else {

                update_post_meta($product_id, 'wc_alegra_sync_status', 'Error');

                Alegra_WC_Logs::log(__METHOD__, 'Product Creation Failed. ' . print_r($call_response, true), 'error');

                /* translators: %s is the error message returned from Alegra */
                $response['message'] = sprintf(__('Hubo un problema al crear el producto: %s', 'alegra-wc-sync'), $call_response['data']['message']);

                if ($call_response['code'] == 1009) {
                    /* translators: %s is the SKU of the product */
                    $response['message'] = sprintf(__('Ya existe un Producto en Alegra con el SKU %s. El valor de SKU debe ser único.', 'alegra-wc-sync'), $content['reference']);
                }
                $response['success'] = false;
            }
            $response['data'] = $call_response;
            return $response;
        }
    }

    public function create_alegra_product_in_wc($product_id, $transient_id)
    {

        $alegra_product = get_transient($transient_id);

        if ($alegra_product) {

            // First, try to find the product by Alegra product ID or by WordPress ID
            $wc_product_id = null;

            $alegra_wc_custom_field_id = (get_option('alegra_wc_custom_field_id')) ? get_option('alegra_wc_custom_field_id') : Alegra_WC_Sync::create_alegra_custom_field();

            if (!empty($alegra_product['customFields'])) {

                //The product has custom fields, check if there's a value in our custom field
                foreach ($alegra_product['customFields'] as $customField) {
                    if ($customField['id'] == $alegra_wc_custom_field_id) {
                        //Found our custom field, store the value
                        $wc_product_id = $customField['value'];
                    }
                }
            }

            if ($wc_product_id) {

                //There's a valid product, use the product ID instead
                $product = wc_get_product($wc_product_id);
            } else {

                //There's no corresponding custom field with a proper value
                $args = array(
                    'post_type' => 'product',
                    'posts_per_page' => 1,
                    'meta_query' => array(
                        array(
                            'key' => 'wc_alegra_product_id',
                            'value' => $product_id,
                            'compare' => '='
                        )
                    )
                );

                $query = new WP_Query($args);
                $product = ($query->have_posts()) ? wc_get_product($query->posts[0]->ID) : null;
            }

            // If no product is found, create a new one
            if (!$product) {
                // we can't sync variable products yet
                //$product = ($alegra_product['type'] === 'variantParent') ? new WC_Product_Variable() : new WC_Product_Simple();
                $product =  new WC_Product_Simple();
            }

            // Set or update product data from $item_data
            $product->set_name($alegra_product['name']);
            $product->set_description(isset($alegra_product['description']) ? $alegra_product['description'] : ' ');

            if (isset($alegra_product['reference'])) {
                $product->set_sku($alegra_product['reference']['reference']);
            }

            if ($alegra_product['status'] === 'active') {
                // If the product is active in Alegra, set it to 'publish' to show on the frontend.
                $product->set_status('publish');
            } else {
                // If the product is not active, set it to 'draft' or 'private'.
                $product->set_status('draft'); // or 'private'
            }

            if (isset($alegra_product['tax'])) {
                $this->set_product_tax_class_from_alegra($product, $alegra_product['tax']);
            }

            if (isset($alegra_product['customFields'])) {
                //P3 we need to address the Custom Fields set in Alegra
            }

            $product->set_regular_price($alegra_product['price'][0]['price']);  // Assume first price, handle multiple prices carefully


            //this must be conditional, only if exists and inventory is managed.
            if (isset($alegra_product['inventory']['availableQuantity'])) {
                $product->set_manage_stock(true);
                $product->set_stock_quantity($alegra_product['inventory']['availableQuantity']);
            }

            // Save the product to ensure it has an ID for further
            $product->save();

            // Update additional Meta
            $product->update_meta_data('wc_alegra_product_id', $alegra_product['id']);
            $product->update_meta_data('wc_alegra_sync_status', 'Sincronizado');
            $product->update_meta_data('wc_alegra_last_synced', date_i18n('Y-m-d H:i:s'));

            if (isset($alegra_product['inventory']['unit'])) {
                $product->update_meta_data('wc_alegra_product_unit', $alegra_product['inventory']['unit']);
            }

            $product->save_meta_data();

            if (isset($alegra_product['itemCategory'])) {
                $this->sync_alegra_category_to_wc($product, $alegra_product['itemCategory']);
            }

            // Handle images
            if (isset($alegra_product['images'])) {
                $this->set_product_images($product, $alegra_product['images']);
            }


            //this will no longer be used as we won't manage variant products
            /*switch ($alegra_product['type']) {
                case 'product':
                    //To Be Developed
                    break;
                case 'variantParent':
                    // Initialize an array to hold all the attributes
                    $attributes = [];

                    foreach ($alegra_product['variantAttributes'] as $attribute) {

                        $taxonomy = 'pa_' . wc_sanitize_taxonomy_name($attribute['name']);
                        $values = array_map(function ($option) {
                            return $option['value'];  // Assuming you're passing the name values here
                        }, $attribute['options']);

                        $term_slugs = $this->ensure_attribute_terms_exist($taxonomy, $values);

                        $wc_attribute = new WC_Product_Attribute();
                        $wc_attribute->set_id($this->get_attribute_taxonomy_id($attribute['name']));
                        $wc_attribute->set_name($taxonomy);
                        $wc_attribute->set_options($term_slugs);
                        $wc_attribute->set_position(0);
                        $wc_attribute->set_visible(true);
                        $wc_attribute->set_variation(true);

                        // Collect attributes in the array
                        $attributes[$taxonomy] = $wc_attribute;
                    }


                    $product->set_attributes($attributes);
                    $product->save();

                    $attributes = [];
                    foreach ($alegra_product['itemVariants'] as $alegra_variant) {
                        $args = array(
                            'post_type' => 'product_variation',
                            'posts_per_page' => 1,
                            'meta_query' => array(
                                array(
                                    'key' => 'wc_alegra_product_id',
                                    'value' => $alegra_variant['id'],
                                    'compare' => '='
                                )
                            )
                        );

                        $query = new WP_Query($args);
                        $variation = ($query->have_posts()) ? wc_get_product($query->posts[0]->ID) : new WC_Product_Variation();

                        $variation->set_parent_id($product->get_id());
                        $variation->set_regular_price($alegra_variant['price'][0]['price']);
                        $variation->set_stock_quantity($alegra_variant['inventory']['availableQuantity']);
                        $variation->set_manage_stock(true);
                        // Prepare attributes for the variation
                        $attributes = [];
                        foreach ($alegra_variant['variantAttributes'] as $attribute) {
                            $attribute_taxonomy_name = wc_sanitize_taxonomy_name('pa_' . $attribute['name']);
                            $option_value = array_map(function ($option) {
                                return sanitize_title($option['value']); // Ensure the term slug is used, not the term name
                            }, $attribute['options']);

                            if (!empty($option_value)) {
                                $attributes[$attribute_taxonomy_name] = implode('', $option_value); // Assuming there is one option per attribute
                            }
                        }

                        $variation->set_attributes($attributes);
                        $variation->save();

                        //Useful Meta
                        $variation->update_meta_data('wc_alegra_product_id', $alegra_variant['id']);
                        $variation->update_meta_data('wc_alegra_sync_status', 'Sincronizado');
                        $variation->update_meta_data('wc_alegra_last_synced', date_i18n('Y-m-d H:i:s'));

                        //Inventory Meta
                        $variation->update_meta_data('wc_alegra_unit_cost', $alegra_variant['inventory']['unitCost']);
                        $variation->update_meta_data('wc_alegra_product_unit', $alegra_variant['inventory']['unit']);

                        $variation->save_meta_data();
                    }
                    break;
            }*/


            // We have to update the custom field in Alegra 
            $custom_field_data = array(
                "customFields" => array(
                    array(
                        'id' => $alegra_wc_custom_field_id,
                        "value" => $product->get_id()
                    )
                )
            );

            //P2 Handle errors here
            $custom_field_response = Alegra_WC_API::alegra_wc_api_request('PUT', "items/" . $product_id, $custom_field_data);

            //P1 Delete the transient when done.
            //delete_transient($transient_id);
            return $product->get_id();
        } else {
            // Log an error or handle cases where the transient might have expired or been deleted
            Alegra_WC_Logs::log(__METHOD__, 'Failed to retrieve product data from transient for product ID ' . $product_id, 'error');
        }
    }

    private function ensure_attribute_terms_exist($taxonomy, $values)
    {
        $term_slugs = [];
        foreach ($values as $value) {
            $term = get_term_by('name', $value, $taxonomy);
            if (!$term) {
                // Term doesn't exist, create it
                $term_info = wp_insert_term($value, $taxonomy);
                if (!is_wp_error($term_info)) {
                    $term = get_term_by('id', $term_info['term_id'], $taxonomy);
                    $term_slugs[] = $term->slug;
                } else {
                    error_log('Failed to create term: ' . $term_info->get_error_message());
                }
            } else {
                $term_slugs[] = $term->slug;
            }
        }
        return $term_slugs;
    }

    // Function to get/set WooCommerce attribute taxonomy ID
    private function get_attribute_taxonomy_id($name)
    {
        global $wpdb;

        $sanitized_name = wc_sanitize_taxonomy_name($name);

        $attribute_taxonomies = wc_get_attribute_taxonomies();

        foreach ($attribute_taxonomies as $tax) {
            if ($tax->attribute_name === $sanitized_name) {
                return $tax->attribute_id;
            }
        }

        error_log('Taxonomy NOT found for => ' . print_r($sanitized_name, true));

        // If not found, create it
        $args = [
            'name'         => $sanitized_name,  // The slug
            'label'        => $name,  // Human-readable name
            'type'         => 'select',
            'order_by'     => 'menu_order',
            'has_archives' => false,
        ];

        $attribute_id = wc_create_attribute($args);
        if (is_wp_error($attribute_id)) {
            error_log('Error creating attribute: ' . $attribute_id->get_error_message());
            return null;  // Handle error appropriately
        }

        // Successfully created, return new attribute ID
        return $attribute_id;
    }

    private function set_product_images($product, $images)
    {
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        $gallery_ids = [];
        $featured_set = false;
        $product_id = $product->get_id();

        foreach ($images as $image) {
            $existing_image_id = $this->find_existing_image($image['id'], $image['name'], $product_id);

            if ($existing_image_id) {
                $image_id = $existing_image_id;
            } else {
                // Download image
                $image_id = media_sideload_image($image['url'], $product_id, $image['name'], 'id');
                if (!is_wp_error($image_id)) {
                    // Store Alegra image ID and name as meta
                    update_post_meta($image_id, '_alegra_image_id', $image['id']);
                    update_post_meta($image_id, '_alegra_image_name', $image['name']);
                }
            }

            if (!is_wp_error($image_id)) {
                // Set alt text for SEO
                update_post_meta($image_id, '_wp_attachment_image_alt', $product->get_name());

                // Check if the image is marked as favorite
                if ($image['favorite'] && !$featured_set) {
                    // Set the first favorite image as the featured image
                    set_post_thumbnail($product_id, $image_id);
                    $featured_set = true;
                } else {
                    // Add other images to the gallery
                    $gallery_ids[] = $image_id;
                }
            } else {
                error_log('Error downloading image: ' . $image['url']);
            }
        }

        // Update the product gallery if there are additional images
        if (!empty($gallery_ids)) {
            update_post_meta($product_id, '_product_image_gallery', implode(',', $gallery_ids));
        }
    }

    private function find_existing_image($alegra_image_id, $image_name, $product_id)
    {
        global $wpdb;
        $query = "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_alegra_image_id' AND meta_value = %s";
        $existing_image_id = $wpdb->get_var($wpdb->prepare($query, $alegra_image_id));

        if ($existing_image_id) {
            // Additionally check if the name matches
            $existing_image_name = get_post_meta($existing_image_id, '_alegra_image_name', true);
            if ($existing_image_name === $image_name) {
                return $existing_image_id;
            }
        }
        return false;
    }


    /**
     * Create a Contact in Alegra by passing a WC User ID and the Order.
     * @param int $user_id The WC User ID.
     * @param object $order The WC Order Object
     * @return object An array containing the result and a message.
     */

    public static function alegra_wc_create_contact($user_id, $order = array())
    {

        Alegra_WC_Logs::log(__METHOD__, 'About to create contact with User ID ' . $user_id . "...");


        if (empty($order)) {

            //There's no order, the data should come from the User Meta

            $customer = new WC_Customer($user_id);

            //Build Customer Address
            $country_code = $customer->get_billing_country();
            $state_code = $customer->get_billing_state();
            $countries_obj = new WC_Countries();
            $countries_array = $countries_obj->get_countries();
            $country_states_array = $countries_obj->get_states();
            $country_name = $countries_array[$country_code];
            $state_name = $country_states_array[$country_code][$state_code];
            $address = (!empty($customer->get_billing_address_2())) ? $customer->get_billing_address_1() . " " . $customer->get_billing_address_2() : $customer->get_billing_address_1();

            //Customer Data
            $customer_fname = $customer->get_first_name();
            $customer_lname = $customer->get_last_name();
            $customer_mobile = $customer->get_billing_phone();
            $customer_email = $customer->get_email();

            //Fiscal Data
            $alegra_order_document_id = $customer->get_meta('alegra_user_tax_id');
            $alegra_order_document_type = $customer->get_meta('alegra_user_document_type');
            $alegra_order_razon_social = $customer->get_meta('alegra_order_razon_social');
        } else {

            //The order is not empty, lets use its data

            //Build Customer Address
            $country_code = $order->get_billing_country();
            $state_code = $order->get_billing_state();
            $countries_obj = new WC_Countries();
            $countries_array = $countries_obj->get_countries();
            $country_states_array = $countries_obj->get_states();
            $country_name = $countries_array[$country_code];
            $state_name = $country_states_array[$country_code][$state_code];
            $address = (!empty($order->get_billing_address_2())) ? $order->get_billing_address_1() . " " . $order->get_billing_address_2() : $order->get_billing_address_1();

            //Customer Data
            $customer_fname = $order->get_billing_first_name();
            $customer_lname = $order->get_billing_last_name();
            $customer_phone = $order->get_billing_phone();
            $customer_mobile = $order->get_billing_phone();
            $customer_email = $order->get_billing_email();

            $alegra_order_document_id = $order->get_meta('alegra_order_document_id');
            $alegra_order_document_type = $order->get_meta('alegra_order_document_type');
            $alegra_order_razon_social = $order->get_meta('alegra_order_razon_social');
        }

        // Create a mapping of English to Spanish country names
        $country_translation = array(
            'Dominican Republic' => 'República Dominicana',
            // Add more translations as needed
        );

        // Get the country name and translate it if necessary
        if (array_key_exists($country_name, $country_translation)) {
            $country_name = $country_translation[$country_name];
        }

        // Define contact data based on Alegra's JSON structure
        $contact_data = array(
            'address' => array(
                'province' => $state_name,
                'description' => $address,
                'country' => $country_name,
            ),
            'identificationObject' => array(),
            'name' => $alegra_order_razon_social,
            'phonePrimary' => $customer_phone,
            'mobile' => $customer_mobile,
            'email' => $customer_email,
            'type' => 'client',
            'internalContacts' => array(
                array(
                    "lastName" =>  $customer_lname,
                    "name" => $customer_fname,
                    "email" => $customer_email,
                    "mobile" => $customer_mobile,
                    "phone" => $customer_mobile,
                    "sendNotifications" => "yes"
                )
            )
        );

        if (!empty($alegra_order_document_id) && !empty($alegra_order_document_type)) {

            $contact_data['identificationObject'] = array(
                'type' => $alegra_order_document_type,
                'number' => $alegra_order_document_id,
            );
        }

        // $alegra_user_id = '';

        $alegra_user_id = get_user_meta($user_id, 'alegra_user_id', true);


        if (empty($alegra_user_id)) {
            //The current user has no meta, but maybe exists in alegra with the RNC
            $alegra_user_id = self::alegra_wc_check_user_by_id($alegra_order_document_id);
        }

        $request_type = (!empty($alegra_user_id) ? 'PUT' : 'POST');
        $endpoint = (!empty($alegra_user_id) ? 'contacts/' . $alegra_user_id : 'contacts');

        $call_response = Alegra_WC_API::alegra_wc_api_request($request_type, $endpoint, $contact_data);

        // Check if the API request was successful
        if (in_array($call_response['code'], array(200, 201)) && isset($call_response['data']['id'])) {

            //Response was successful, check for its content
            Alegra_WC_Logs::log(__METHOD__, 'user creation Suceeeded. ID => ' . $call_response['data']['id']);

            // Store the Alegra user ID as user meta if not guest
            if ($user_id > 0) {

                update_user_meta($user_id, 'alegra_user_id', $call_response['data']['id']);
                update_user_meta($user_id, 'alegra_user_tax_id', $alegra_order_document_id);
                update_user_meta($user_id, 'alegra_user_document_type', $alegra_order_document_type);
                update_user_meta($user_id, 'alegra_user_razon_social', $alegra_order_razon_social);

                // Store the current date and time as user meta
                $current_time = current_time('mysql');
                update_user_meta($user_id, 'alegra_user_date_created', $current_time);
            }

            $return['success'] = true;
            /* translators: %s is the user ID */
            $return['message'] = sprintf(__('Contacto creado / actualizado exitosamente. ID en Alegra: %s', 'alegra-wc-sync'), $call_response['data']['id']);
            $return['data'] = $call_response['data'];
        } else {
            Alegra_WC_Logs::log(__METHOD__, 'user creation failed. => ' . print_r($call_response, true), 'error');
            $return['success'] = false;
            $return['message'] = $call_response['data']['error']['message'];
            $return['data'] = $call_response;
        }


        return $return;
    }

    public static function alegra_wc_get_numberTemplate_ID($alegra_order_type)
    {

        Alegra_WC_Logs::log(__METHOD__, 'Getting the Number Template ID for order type ' . $alegra_order_type);

        // Find the position of the last underscore
        $lastUnderscorePos = strrpos($alegra_order_type, '_');

        if ($lastUnderscorePos === false) {

            Alegra_WC_Logs::log(__METHOD__, 'Order type is invalid', 'error');
            // If there's no underscore, return null or handle as needed
            return null;
        }
        // Split the string into parts
        $prefix = substr($alegra_order_type, $lastUnderscorePos + 1);
        $documentType = substr($alegra_order_type, 0, $lastUnderscorePos);

        // Define the endpoint for the API call
        $endpoint = 'number-templates?documentType=' . $documentType;

        // Make the API call to Alegra
        $response = Alegra_WC_API::alegra_wc_api_request('GET', $endpoint);

        if (in_array($response['code'], array(200, 201)) && is_array($response['data'])) {

            //Response was successful, check for its content
            $response = $response['data'];

            // Loop through the response array to find the matching 'prefix'
            foreach ($response as $template) {
                if (isset($template['prefix']) && $template['prefix'] === $prefix) {
                    return $template;
                }
            }
        } else {

            Alegra_WC_Logs::log(__METHOD__, 'Number Template validation failed. => ' . print_r($response, true), 'error');

            // Return null if no matching template was found
            return null;
        }
    }

    public function alegra_wc_create_invoice($order_id)
    {

        Alegra_WC_Logs::log(__METHOD__, 'About to create order ID ' . $order_id . " in Alegra...");

        $invoice_data = array();

        $order = wc_get_order($order_id);

        if (!$order) {

            Alegra_WC_Logs::log(__METHOD__, 'There was an error creating the order. The order is not valid in WC.', 'error');
            $return['success'] = false;
            $return['data'] = array();
            /* translators: %s is the Order ID */
            $return['message'] = sprintf(__("Hubo un error al crear el pedido %s. El pedido no es válido en WooCommerce.", 'alegra-wc-sync'), $order_id);

            return $return;
        }

        $is_fiscal_order = $order->get_meta('comprobante_fiscal');

        if (!$is_fiscal_order) {

            //The order is not Fiscal, just Bail.
            $return['success'] = false;
            $return['data'] = array();
            /* translators: %s is the Order ID */
            $return['message'] = sprintf(__("El pedido %s no es Fiscal, por lo que no irá a Alegra. Proporcione los detalles fiscales para enviarlo a Alegra.", 'alegra-wc-sync'), $order_id);
        } else {

            // Get current date in yyyy-mm-dd format
            $current_date = date('Y-m-d', current_time('timestamp'));

            // P3 this could be a Setting: Set due date of invoices by default
            $due_date = date('Y-m-d', strtotime($current_date . ' + 15 days'));

            $Payment_options = $this->wc_alegra_get_payment_method($order);

            // Initialize the invoice data array
            $invoice_data = array(
                "stamp" => array(
                    "generateStamp" => (get_option('create_fiscal_order_in_alegra') == 'yes' ? true :  false),
                ),
                "paymentType" => $Payment_options['PaymentType'],
                "paymentMethod" => $Payment_options['PaymentMethod'],
                "termsConditions" => get_option('alegra_wc_tyc'),
                "date" => $current_date,
                "dueDate" => $due_date,
                "anotation" => get_option('alegra_wc_annotations'),
                "items" => array(),
            );

            $alegra_order_type = $order->get_meta('alegra_order_type');

            Alegra_WC_Logs::log(__METHOD__, 'This is a Fiscal order. Determine the Sequence to Use for order type [' . $alegra_order_type  .  ']');

            $numberTemplate = $this->alegra_wc_get_numberTemplate_ID($alegra_order_type);

            if ($numberTemplate) {
                $invoice_data['numberTemplate'] = array(
                    'id' => $numberTemplate['id']
                );
            } else {
                Alegra_WC_Logs::log(__METHOD__, 'The sequence for Order Type [' . $alegra_order_type  .  '] is not set in Alegra. This invoice can not be created.', "error");
                $return['success'] = false;
                /* translators: %s is the type of order */
                $return['message'] = sprintf(__('La secuencia para Tipo de Orden [%s] no está configurada en Alegra. Esta factura no se puede crear en Alegra.', 'alegra-wc-sync'), $alegra_order_type);
                $return['data'] = array();
                $order->add_order_note($return['message']);
                return $return;
            }

            $user_id = $order->get_customer_id();

            // Get customer ID from the 'alegra_user_id' user meta
            $alegra_customer_id = get_user_meta($user_id, 'alegra_user_id', true);


            if (!$alegra_customer_id) {

                Alegra_WC_Logs::log(__METHOD__, 'user Dont have the Alegra Meta, checking if it needs to be created...', 'notice');

                $customer_name = $order->get_formatted_billing_full_name();
                $customer_email = $order->get_billing_email();

                $endpoint = 'contacts?mode=simple&query=' . $customer_name;

                $response = Alegra_WC_API::alegra_wc_api_request('GET', $endpoint);

                if (in_array($response['code'], array(200, 201))) {

                    //Response was successful, check for its content
                    $response = $response['data'];

                    foreach ($response as $alegra_contact) {

                        if ($alegra_contact['email'] = $customer_email) {
                            //The user was found in alegra by searching its name and email... break
                            Alegra_WC_Logs::log(__METHOD__, 'user has no Meta in WP, but was found in Alegra, using this ID...', 'notice');
                            $alegra_customer_id = $alegra_contact['id'];
                            update_user_meta($user_id, 'alegra_user_id', $alegra_customer_id);
                            break;
                        }
                    }
                }

                if (!$alegra_customer_id) {

                    Alegra_WC_Logs::log(__METHOD__, "user wasn't found in Alegra, creating it...", 'notice');

                    $creation = $this->alegra_wc_create_contact($user_id, $order);

                    if ($creation['success'] === true) {
                        $alegra_customer_id = $creation['data']['id'];
                    } else {

                        Alegra_WC_Logs::log(__METHOD__, 'user creation failed while creating invoice. ' . print_r($creation['data'], true), 'error');
                        $return['success'] = false;
                        $return['data'] = $creation;
                        $return['message'] = $creation['data']['message'];
                        return $return;
                    }
                }
            }


            $invoice_data['client'] = array(
                "id" => $alegra_customer_id,
            );

            //P3 Invoices now support comments
            /*$invoice_data['comments'] = array(
                'Comment No. 1',
                'Comment No. 2'
            );*/

            // Get order items
            foreach ($order->get_items() as $item_id => $item) {

                $product = $item->get_product();
                $product_id = $product->get_id();

                $alegra_product_id = Alegra_WC_Helper::get_alegra_product_id_by_wc_id($product_id);

                if ($alegra_product_id == 0) {
                    Alegra_WC_Logs::log(__METHOD__, $product_id . " does not have an Alegra ID. Creating it...", 'info');

                    //Lets try to create the product.
                    $product_creation = $this->alegra_wc_create_wc_product($product_id);
                    $alegra_product_id = get_post_meta($product_id, 'wc_alegra_product_id', true);

                    if ($product_creation['success']) {

                        $alegra_product_id = get_post_meta($product_id, 'wc_alegra_product_id', true);
                    } else {

                        //The product creation failed. Stop the invoice creation
                        $return['success'] = false;
                        /* translators: 1: Error message. */
                        $return['message'] = sprintf(__("Error: %1\$s", 'alegra-wc-sync'), $product_creation['data']);
                        $return['data'] = $product_creation;
                        $order->add_order_note($return['message']);
                        return $return;
                    }
                }


                // Build the item data and add it to the items array
                $item_data = array(
                    "id" => $alegra_product_id,
                    "quantity" => $item->get_quantity(),
                    "price" => $item->get_total(),
                );


                if ($product->is_taxable()) {

                    //If the product is taxable, determine what tax is and match it with Alegra
                    $wc_tax = $this->wc_alegra_set_item_tax($item);

                    if (!empty($wc_tax)) {
                        $item_data['tax'][] = $wc_tax;
                    }
                }

                $invoice_data["items"][] = $item_data;
            }

            // Check if the "wc_alegra_invoice_id" meta field exists for the current order
            $alegra_invoice_id = $order->get_meta('alegra_invoice_id');

            // Determine the request type and endpoint based on the existence of "wc_alegra_invoice_id"
            if (!empty($alegra_invoice_id)) {
                // If "alegra_invoice_id" exists, update the existing order in Alegra
                Alegra_WC_Logs::log(__METHOD__, ' Invoice already exists, updating it in Alegra on Invoice ID => ' . $alegra_invoice_id, 'notice');
                $request_type = 'PUT';
                $endpoint = 'invoices/' . $alegra_invoice_id;
            } else {
                // If "alegra_invoice_id" doesn't exist, create a new order in Alegra
                $request_type = 'POST';
                $endpoint = 'invoices';
            }

            $response = Alegra_WC_API::alegra_wc_api_request($request_type, $endpoint, $invoice_data);

            // Check if the API request was successful
            if (in_array($response['code'], array(200, 201)) && isset($response['data']['id'])) {

                //Response was successful, check for its content
                $response = $response['data'];

                Alegra_WC_Logs::log(__METHOD__, 'Success creating invoice! ');

                $alegra_invoice_id = $response['id'];

                $order->update_meta_data('alegra_invoice_id', $alegra_invoice_id);

                // Store the current date and time as order meta
                $current_time = current_time('mysql');
                $order->update_meta_data('alegra_invoice_date_created', $current_time);

                $order->save();

                $return['success'] = true;
                $return['message'] = __("Sincronización exitosa de la factura. ID de factura " . $alegra_invoice_id . ".", 'alegra-wc-sync');
            } else {

                Alegra_WC_Logs::log(__METHOD__, 'Falló la creación de la factura: ' . print_r($response, true), 'error');

                $message = __("Falló la creación de la factura. " . $response['data']['error']['message'] . ".", 'alegra-wc-sync');

                $return['success'] = false;
                $return['message'] = $message;
                $order->add_order_note($message);
            }

            $return['data'] = $response;
        }

        do_action('alegra_wc_invoice_created', $return);

        return $return;
    }

    public function wc_alegra_set_item_tax($item)
    {

        $wc_tax = array();
        $tax_rate_18_exists = false;
        $taxes = array();

        if (is_a($item, 'WC_Order_Item_Product')) {
            // Get the tax rates applied to the order item
            $taxes = $item->get_taxes();
        } elseif (is_int($item)) {
            // Get the product object
            $product = wc_get_product($item);

            // Check if the product is taxable
            if ($product) {
                // Get the tax rates applied to the product
                $tax_class = $product->get_tax_class();
                $tax_rates = WC_Tax::get_rates($tax_class);

                // Construct the taxes array similar to how it would be for an order item
                foreach ($tax_rates as $tax_rate_id => $tax_rate) {
                    $taxes['total'][$tax_rate_id] = $tax_rate['rate'];
                }
            }
        } else {
            $tax_class = $item->get_tax_class();
            $tax_rates = WC_Tax::get_rates($tax_class);
            // Construct the taxes array similar to how it would be for an order item
            foreach ($tax_rates as $tax_rate_id => $tax_rate) {
                $taxes['total'][$tax_rate_id] = $tax_rate['rate'];
            }
        }

        if (is_array($taxes) && !empty($taxes)) {

            foreach ($taxes['total'] as $tax_rate_id => $tax_amount) {
                $tax_rate = WC_Tax::_get_tax_rate($tax_rate_id);
                if (isset($tax_rate['tax_rate']) && $tax_rate['tax_rate'] == '18.0000') {
                    $tax_rate_18_exists = true;
                    break;
                }
            }

            // If the tax rate of 18.000 exists, add the tax data to the item_data array
            if ($tax_rate_18_exists) {
                Alegra_WC_Logs::log(__METHOD__, 'This is a Fiscal order. Adding Taxes...');
                $wc_tax = array(
                    'id' => $this->alegra_wc_get_alegra_taxes()
                );
            };
            return $wc_tax;
        } else {

            return $taxes;
        }
    }

    public function wc_alegra_get_payment_method($order)
    {
        $payment_method = $order->get_payment_method();
        $payment_status = $order->get_status();

        // Define the default values
        $payment_type = 'CREDIT';
        $payment_subtype = '';

        // Check if the order has been paid
        if ($payment_status === 'completed' || $payment_status === 'processing') {
            $payment_type = 'CASH'; // Order has been paid or will be paid on delivery
            // Define equivalent options based on payment method
            switch ($payment_method) {
                case 'cheque':
                    $payment_subtype = 'check';
                    break;
                case 'bacs':
                    $payment_subtype = 'transfer';
                    break;
                case 'cod':
                    $payment_subtype = 'cash';
                    break;
                case 'credit-card':
                    $payment_subtype = 'credit-card';
                    break;
                    // Add more payment method cases as needed
            }
        }

        return array(
            'PaymentType' => $payment_type,
            'PaymentMethod' => $payment_subtype,
        );
    }


    public static function alegra_to_wc_inventory_sync()
    {
        //$products = Alegra_WC_API::alegra_wc_api_request('GET', 'items?fields=variantAttributes,itemVariants&metadata=true&mode=advanced');
        $products = Alegra_WC_API::alegra_wc_api_request('GET', 'items?type=simple&metadata=true&mode=advanced');

        if (!in_array($products['code'], array(200, 201))) {
            Alegra_WC_Logs::log(__METHOD__, 'Getting inventory from Alegra failed. ' . print_r($products, true), 'error');
            return [
                'success' => false,
                'data' => $products['data']['message']
            ];
        } else {
            foreach ($products['data']['data'] as $product) {

                $transient_id = 'alegra_product_' . $product['id'];

                set_transient($transient_id, $product, DAY_IN_SECONDS * 6); // Expires slightly after the scheduled action is supposed to run

                $hook_name = 'create_alegra_product_in_wc';

                // Schedule the action with minimal arguments
                if (!as_next_scheduled_action($hook_name, ['product_id' => $product['id'], 'transient_id' => $transient_id])) {

                    //P1 Recurrent for testing purposes
                    as_schedule_recurring_action(date('U'), 5 * HOUR_IN_SECONDS, $hook_name, ['product_id' => $product['id'], 'transient_id' => $transient_id], 'create_alegra_product_in_wc');

                    //as_schedule_single_action(time() + (DAY_IN_SECONDS * 5), $hook_name, ['product_id' => $product['id'], 'transient_id' => $transient_id]);

                }
            }

            return [
                'success' => true,
                'data' => 'The creation of ' . $products['data']['metadata']['total'] . ' product(s) has been scheduled.'
            ];
        }
    }

    public function create_scheduled_product($request_type, $endpoint, $content, $product_id)
    {

        Alegra_WC_Logs::log(__METHOD__, 'About to Sync the Product ID ' . $product_id . ' to Alegra...');

        $call_response = Alegra_WC_API::alegra_wc_api_request($request_type, $endpoint, $content);

        if (in_array($call_response['code'], array(200, 201)) && isset($call_response['data']['id'])) {

            //Response was successful, check for its content
            $call_response = $call_response['data'];

            Alegra_WC_Logs::log(__METHOD__, 'Product succesfully Synced with Alegra Product ID ' . $call_response['id'] . '. Updating Meta...');


            // Update the Alegra Product ID meta field if the request was successful
            update_post_meta($product_id, 'wc_alegra_product_id', $call_response['id']);
            update_post_meta($product_id, 'wc_alegra_sync_status', 'Sincronizado');
            update_post_meta($product_id, 'wc_alegra_last_synced', date_i18n('Y-m-d H:i:s'));

            //If the updated product was a variation, mark its parent as updated on this timestamp as well
            $product = wc_get_product($product_id);
            if ($product->is_type('variation')) {
                $product_parent = $product->get_parent_id();
                update_post_meta($product_parent, 'wc_alegra_last_synced', date_i18n('Y-m-d H:i:s'));
            }


            $response['success'] = true;
        } else {
            Alegra_WC_Logs::log(__METHOD__, 'Product Creation Failed. ' . print_r($call_response, true), 'error');
            $response['success'] = false;
        }
        $response['data'] = $call_response;
        return $response;
    }

    public function create_scheduled_category($request_type, $endpoint, $content, $category_id)
    {

        Alegra_WC_Logs::log(__METHOD__, 'About to Sync the Category ID ' . $category_id . ' to Alegra...');

        $call_response = Alegra_WC_API::alegra_wc_api_request($request_type, $endpoint, $content);

        if (in_array($call_response['code'], array(200, 201)) && isset($call_response['data']['id'])) {

            //Response was successful, check for its content
            $call_response = $call_response['data'];

            update_term_meta($category_id, 'alegra_taxonomy_id', $call_response['id']);
            Alegra_WC_Logs::log(__METHOD__, ' Category Created Succesfully in Alegra. Alegra Category ID ' . $call_response['id']);
            $response['success'] = true;
        } else {
            Alegra_WC_Logs::log(__METHOD__, 'Product Creation Failed. ' . print_r($call_response, true), 'error');
            $response['success'] = false;
        }
        $response['data'] = $call_response;
        return $response;
    }

    public function alegra_wc_get_alegra_taxes()
    {
        $alegra_taxes = Alegra_WC_API::alegra_wc_api_request('GET', 'taxes');
        if (in_array($alegra_taxes['code'], array(200, 201))) {

            foreach ($alegra_taxes['data'] as $alegra_tax) {
                //Find the Tax Type ITBIS that is equal to the 18%
                if ($alegra_tax['type'] == 'ITBIS' && $alegra_tax['percentage'] == '18.00') {
                    return $alegra_tax['id'];
                }
            }
            Alegra_WC_Logs::log('No corresponding Tax was found in Alegra. => ' . print_r($alegra_taxes, true), 'error');
            //If this point is reached, return false

            return false;
        }
        Alegra_WC_Logs::log('There was an error obtaining the Taxes from Alegra. => ' . print_r($alegra_taxes, true), 'error');

        return false;
    }

    public function alegra_wc_get_alegra_order($alegra_invoice_id, $order_id = '')
    {

        //Obtain the order details from Alegra
        if (!empty($alegra_invoice_id)) {

            $alegra_order = Alegra_WC_API::alegra_wc_api_request('GET', 'invoices/' . $alegra_invoice_id);

            if (in_array($alegra_order['code'], array(200, 201)) && isset($alegra_order['data']['id'])) {

                //Response was successful, check for its content
                $alegra_order = $alegra_order['data'];

                return $alegra_order;
            }
        }
    }

    public static function alegra_wc_get_alegra_categories()
    {
        //Using a transient to prevent an API call for this. 
        if (is_array(get_transient('alegra_wc_categories_array'))) {
            $categories = get_transient('alegra_wc_categories_array');
        } else {
            $alegra_categories = Alegra_WC_API::alegra_wc_api_request('GET', 'item-categories?status=active');
            $categories = [];
            if (in_array($alegra_categories['code'], array(200, 201))) {

                //Response was successful, check for its content
                $alegra_categories = $alegra_categories['data'];
                foreach ($alegra_categories as $alegra_cat) {
                    $categories[$alegra_cat['id']] = $alegra_cat['name'];
                }
            }
            set_transient('alegra_wc_categories_array', $categories, DAY_IN_SECONDS);
        }
        return $categories;
    }

    public static function alegra_wc_check_user_by_id($alegra_order_document_id)
    {

        Alegra_WC_Logs::log(__METHOD__, 'Getting all contacts by name...');

        $endpoint = 'contacts?mode=simple&identification=' . $alegra_order_document_id;

        $response = Alegra_WC_API::alegra_wc_api_request('GET', $endpoint);

        $alegra_user_id = '';

        if (in_array($response['code'], array(200, 201))) {

            foreach ($response['data'] as $alegra_contact) {

                if ($alegra_contact['identification'] == $alegra_order_document_id) {
                    //The user was found in alegra by searching its id... break
                    Alegra_WC_Logs::log(__METHOD__, 'user was found in Alegra using id ' . $alegra_order_document_id, 'info');
                    $alegra_user_id = $alegra_contact['id'];
                    break;
                }
            }
        }
        return $alegra_user_id;
    }

    // Save the custom order data when the order is updated
    public function alegra_wc_save_custom_order_data($order_id = '')
    {

        if (empty($order_id)) {
            // Maybe was called from AJAX, get the order ID from a jQuery parameter
            $order_id = isset($_POST['order_id']) ? sanitize_text_field($_POST['order_id']) : '';
        }

        // Make sure order exists and is valid
        $order = wc_get_order($order_id);

        if (!$order || !is_a($order, 'WC_Order')) {
            // Order doesn't exist or is not valid, handle the validation error
            // You can return an error message, log an error, or perform other actions
            Alegra_WC_Logs::log(__METHOD__, ' Order data update failed. The supplied order is not valid or empty.', 'error');
            return;
        }

        if (isset($_POST['comprobante_fiscal'])) {
            $comprobante_fiscal = sanitize_text_field($_POST['comprobante_fiscal']);
            $order->update_meta_data('comprobante_fiscal', $comprobante_fiscal);
        }

        if (isset($_POST['alegra_order_document_id'])) {
            $alegra_order_document_id = sanitize_text_field($_POST['alegra_order_document_id']);
            $order->update_meta_data('alegra_order_document_id', $alegra_order_document_id);
        }

        if (isset($_POST['alegra_order_type'])) {
            $alegra_order_type = sanitize_text_field($_POST['alegra_order_type']);
            $order->update_meta_data('alegra_order_type', $alegra_order_type);
        }

        if (isset($_POST['alegra_order_document_type'])) {
            $alegra_order_document_type = sanitize_text_field($_POST['alegra_order_document_type']);
            $order->update_meta_data('alegra_order_document_type', $alegra_order_document_type);
        }

        if (isset($_POST['alegra_order_razon_social'])) {
            $alegra_order_razon_social = sanitize_text_field($_POST['alegra_order_razon_social']);
            $order->update_meta_data('alegra_order_razon_social', $alegra_order_razon_social);
        }

        if (isset($_POST['alegra_order_nombre_comercial'])) {
            $alegra_order_nombre_comercial = sanitize_text_field($_POST['alegra_order_nombre_comercial']);
            $order->update_meta_data('alegra_order_nombre_comercial', $alegra_order_nombre_comercial);
        }

        $order->save();
    }

    /**
     * Returns the document type label based on the provided key.
     *
     * @param string $type The key to get the document type label.
     * @return string The label of the document type.
     */
    public function get_alegra_document_type($type)
    {
        $types = [
            'RNC' => 'RNC',
            'CED' => 'Cédula',
        ];

        return $types[$type] ?? "No. de Identificación";
    }

    /**
     * Returns the comprobante type label based on the provided key.
     *
     * @param string $type The key to get the comprobante type label.
     * @return string The label of the comprobante type.
     */
    public function get_alegra_comprobante_type($type)
    {
        $types = [
            'INVOICE_B01' => 'Crédito Fiscal',
            'INVOICE_B02' => 'Factura de Consumo',
            'INVOICE_B14' => 'Regímenes Especiales',
            'INVOICE_B15' => 'Gubernamental',
            'INVOICE_B16' => 'Comprobante para Exportaciones',
        ];

        return $types[$type] ?? "Sin Comprobante";
    }

    public function alegra_display_admin_notices()
    {
        if ($notice_data = get_transient('alegra_admin_notice')) {
            $type = $notice_data['type'] === 'error' ? 'notice-error' : 'notice-success';
            echo '<div class="notice ' . $type . ' is-dismissible"><p>' . esc_html($notice_data['message']) . '</p></div>';
            delete_transient('alegra_admin_notice');
        }
    }


    public static function create_alegra_custom_field()
    {
        $body = [
            "resourceType" => "item",
            "type" => "text",
            "settings" => [
                "isRequired" => false,
                "printOnInvoices" => false,
                "showInItemVariants" => true
            ],
            "name" => "WooCommerce ID",
            "description" => "El ID del producto en WooCommerce para la sincronización con Alegra. Favor no eliminar.",
            "status" => "active"
        ];

        // Use the API class to make the request
        $response = Alegra_WC_API::alegra_wc_api_request('POST', 'custom-fields', $body);

        // Check for successful response and store the custom field ID
        if (isset($response['data']['id']) && ($response['code'] == 200 || $response['code'] == 201)) {
            update_option('alegra_wc_custom_field_id', $response['data']['id']);
            Alegra_WC_Logs::log('Custom field created successfully in Alegra with ID: ' . $response['data']['id'], 'info');
            return $response['data']['id'];
        } else {
            Alegra_WC_Logs::log('Failed to create custom field in Alegra: ' . $response['data']['message'], 'error');
            return null;
        }
    }

    public function set_product_tax_class_from_alegra($product, $alegra_tax_data)
    {
        foreach ($alegra_tax_data as $tax) {
            if ($tax['percentage'] === '18.00' && $tax['status'] === 'active') {
                $itbis_tax_class = Alegra_WC_Taxes::get_tax_class_by_rate('18.00');
                Alegra_WC_Taxes::apply_tax_class($product, $itbis_tax_class);
                $product->save();
                break;
            }
        }
    }

    function sync_alegra_category_to_wc(WC_Product $product, $alegra_category)
    {

        // Retrieve the product ID from the product object
        $product_id = $product->get_id();


        // Check for existing category by Alegra ID
        $args = array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
            'meta_query' => array(
                array(
                    'key' => 'alegra_taxonomy_id',
                    'value' => $alegra_category['id'],
                    'compare' => '='
                )
            )
        );

        $terms = get_terms($args);

        if (!empty($terms) && !is_wp_error($terms)) {


            $term_id = $terms[0]->term_id; // Assume the first matching term is the correct one
        } else {
            // No existing term found, create new category
            $term = wp_insert_term(
                $alegra_category['name'],
                'product_cat',
                array(
                    'description' => $alegra_category['description'],
                    'slug' => sanitize_title($alegra_category['name'])
                )
            );

            if (is_wp_error($term)) {
                Alegra_WC_Logs::log('Error creating the Alegra Category: ' . $alegra_category['name'] . ': ' . $term->get_error_message(), 'error');
                return; // Exit if there was an error creating the category
            }

            $term_id = $term['term_id'];

            // Store Alegra ID as term meta
            add_term_meta($term_id, 'alegra_id', $alegra_category['id'], true);
        }

        //This will clear up all previous categories, as Alegra works
        //P2 This could be a setting
        $exclusive = true;

        // Check if we should remove other categories
        // If exclusive, set this as the only category
        if ($exclusive) {
            wp_set_object_terms($product_id, $term_id, 'product_cat', false);
        } else {
            wp_set_object_terms($product_id, $term_id, 'product_cat', true);
        }

        // Assign the category to the product
        wp_set_object_terms($product_id, $term_id, 'product_cat', true);
    }
}
