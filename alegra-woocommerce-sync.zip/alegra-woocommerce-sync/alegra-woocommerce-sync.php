<?php

/**
 * Plugin Name: Alegra WC Sync
 * Plugin URI: https://infinitegroup.com.do
 * Description: Sync Alegra with WooCommerce.
 * Version: 1.0.0
 * Author: Infinite Group
 * Author URI: https://infinitegroup.com.do
 */

// Check if WooCommerce is active
if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {


  if (!defined('WC_LOG_HANDLER')) {
    define('WC_LOG_HANDLER', 'WC_Log_Handler_DB');
  }

  //ILM Constants
  define('PLUGIN_DIR', dirname(__FILE__) . '/');
  define('ILM_PRODUCT_ID', 'alegra-wc-sync');
  define('ILM_PRODUCT_NAME', 'Alegra WC Sync');

  //Define Incompatibility with Woocommerce Cart Blocks
  add_action( 'before_woocommerce_init', function() {
    if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, false );
    }
} );

  // Include the main plugin class file and Initialize the plugin
  require_once plugin_dir_path(__FILE__) . 'includes/class-alegra-wc-sync.php';
  $alegra_woocommerce_sync = new AlegraWCSync();

  // Include the Alegra settings class file and Initialize the settings page
  require_once plugin_dir_path(__FILE__) . 'includes/class-alegra-wc-settings.php';
  $alegra_wc_sync_settings = new AlegraWCSyncSettings();

  // Include the Alegra checkout class file Initialize the checkout functions
  require_once plugin_dir_path(__FILE__) . 'includes/class-alegra-wc-checkout.php';
  $alegra_wc_checkout = new AlegraWCCheckout();

  require_once plugin_dir_path(__FILE__) . 'includes/class-ilm-client.php';


  if (is_admin()) {
    $ilm = new ILM_Client(
      ILM_PRODUCT_ID,
      ILM_PRODUCT_NAME,
      ILM_PRODUCT_ID,
      'https://api.infinitegroup.com.do/api/ilm/v1',
      'plugin',
      __FILE__
    );
  }

  register_activation_hook(__FILE__, 'alegra_wc_plugin_activation');
  register_deactivation_hook(__FILE__, 'alegra_wc_plugin_deactivation');

  //On activation, redirect to the plugin settings.
  function alegra_wc_plugin_activation()
  {
    if (
      (isset($_REQUEST['action']) && 'activate-selected' === $_REQUEST['action']) &&
      (isset($_POST['checked']) && count($_POST['checked']) > 1)
    ) {
      return;
    }
    add_option('alegra_activation_redirect', wp_get_current_user()->ID);

    if (!as_has_scheduled_action("alegra_wc_check_for_inventory_adjustments", [])) {

      $interval = (get_option('alegra_inventory_adjustment_delay') ? get_option('alegra_inventory_adjustment_delay') : 24 );

     as_schedule_recurring_action(date('U'), $interval * HOUR_IN_SECONDS, 'alegra_wc_check_for_inventory_adjustments');
    }
  }

  function alegra_wc_plugin_deactivation()
  {

    if (as_has_scheduled_action("alegra_wc_check_for_inventory_adjustments")) {
      as_unschedule_all_actions('alegra_wc_check_for_inventory_adjustments');
    }
  }
} else {
  // WooCommerce is not active, display a notice
  function alegra_wc_sync_activation_notice()
  {
    echo '<div class="error"><p>Please activate WooCommerce to use the Alegra WC Sync plugin.</p></div>';
  }
  add_action('admin_notices', 'alegra_wc_sync_activation_notice');
}
