<?php

/**
 * Plugin Name: Alegra WooCommerce Sync
 * Plugin URI: https://infinitegroup.com.do
 * Description: Sincronice sus productos e inventario fácilmente entre WooCommerce y Alegra.
 * Version: 1.0.0
 * Author: Infinite Group
 * Author URI: https://infinitegroup.com.do
 * Text Domain: alegra-wc-sync
 * Domain Path: /languages
 */

// Define the text domain as a constant

// Check if WooCommerce is active
if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {


  if (!defined('WC_LOG_HANDLER')) {

    define('WC_LOG_HANDLER', 'WC_Log_Handler_DB');
  }

  //ILM Constants
  define('PLUGIN_DIR', dirname(__FILE__) . '/');
  define('ILM_PRODUCT_ID', 'alegra-wc-sync');
  define('ILM_PRODUCT_NAME', 'Alegra WC Sync');


  // Load the plugin's text domain for translation
  add_action('init', function () {
    load_plugin_textdomain('alegra-wc-sync', false, dirname(plugin_basename(__FILE__)) . '/languages');
  });


  if (is_admin()) {
    add_filter('woocommerce_get_settings_pages', function ($settings) {
      $settings[] = include plugin_dir_path(__FILE__) . 'includes/class-alegra-wc-sync-settings.php';
      return $settings;
    });
  }

  //Define Incompatibility with Woocommerce Cart Blocks
  add_action('before_woocommerce_init', function () {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
      \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, false);
    }
  });

  // Include the Alegra Log class for logging
  //require_once plugin_dir_path(__FILE__) . 'includes/class-alegra-wc-logs.php';
  //$alegra_wc_logs = new Alegra_WC_Logs();

  // Include the main plugin class file and Initialize the plugin
  require_once plugin_dir_path(__FILE__) . 'includes/class-alegra-wc-sync.php';
  $alegra_woocommerce_sync = new Alegra_WC_Sync();

  // Include the Alegra settings class file and Initialize the settings page
  require_once plugin_dir_path(__FILE__) . 'includes/class-alegra-wc-admin-settings.php';
  $alegra_wc_sync_settings = new Alegra_WC_Admin_Settings(); 

  // Include the Alegra checkout class file Initialize the checkout functions
  require_once plugin_dir_path(__FILE__) . 'includes/class-alegra-wc-checkout.php';
  $alegra_wc_checkout = new Alegra_WC_Checkout();

  // Include the Alegra API class file to initialize API Functions
  require_once plugin_dir_path(__FILE__) . 'includes/class-alegra-wc-api.php';
  $alegra_wc_api = new Alegra_WC_API();

    // Include the Alegra Helper class file to initialize some helpful functions
    require_once plugin_dir_path(__FILE__) . 'includes/class-alegra-wc-helper.php';
    $Alegra_WC_Helper = new Alegra_WC_Helper();

    
    // Include the Alegra Tax Helper class file to initialize some taxes related functions
    require_once plugin_dir_path(__FILE__) . 'includes/class-alegra-wc-taxes.php';
    $Alegra_WC_Taxes = new Alegra_WC_Taxes();

  require_once plugin_dir_path(__FILE__) . 'includes/class-ilm-client.php';

//P1 Test the update mechanism

  if (is_admin()) {
    $ilm = new ILM_Client(
      ILM_PRODUCT_ID,
      ILM_PRODUCT_NAME,
      ILM_PRODUCT_ID,
      'https://api.infinitegroup.com.do/api/ilm/v1',
      'plugin',
      __FILE__
    );
  }

  register_activation_hook(__FILE__, 'alegra_wc_plugin_activation');
  register_deactivation_hook(__FILE__, 'alegra_wc_plugin_deactivation');

  //On activation, redirect to the plugin settings.
  function alegra_wc_plugin_activation()
  {
    if (
      (isset($_REQUEST['action']) && 'activate-selected' === $_REQUEST['action']) &&
      (isset($_POST['checked']) && count($_POST['checked']) > 1)
    ) {
      return;
    }

    add_option('alegra_activation_redirect', wp_get_current_user()->ID);

    //Create the ITBIS Tax Rate on plugin activation

    // Check if a tax rate with 18% already exists
    $tax_classes = WC_Tax::get_tax_classes();

    $rate_exists = false;

    foreach ($tax_classes as $tax_class) {
      $tax_rates = WC_Tax::get_rates_for_tax_class($tax_class);
      foreach ($tax_rates as $rate) {
        if ($rate->tax_rate == '18.0000') {
          $rate_exists = true;
          break;
        }
      }
    }


    // If no tax rate with 18% exists, insert a new tax rate
    if (!$rate_exists) {
      $tax_class = WC_Tax::create_tax_class("ITBIS", 'itbis');

      WC_Cache_Helper::invalidate_cache_group('taxes');
      WC_Cache_Helper::get_transient_version('shipping', true);


      $new_rate = array(
        'tax_rate_country'  => 'DO',
        'tax_rate_state'    => '*',
        'tax_rate'          => '18.0000',
        'tax_rate_name'     => 'ITBIS',
        'tax_rate_priority' => 1,
        'tax_rate_compound' => 0,
        'tax_rate_shipping' => 0,
        'tax_rate_order'    => 1,
        'tax_rate_class'    => 'itbis',       // Standard rate
      );

      WC_Tax::_insert_tax_rate($new_rate);
    }

    //Ultimately, enable Taxes in WooCommerce
    update_option('woocommerce_calc_taxes', 'yes');
  }

  function alegra_wc_plugin_deactivation()
  {
    if (as_has_scheduled_action("alegra_to_wc_inventory_sync")) {
      as_unschedule_all_actions('alegra_to_wc_inventory_sync');
    }
  }
} else {
  // WooCommerce is not active, display a notice
  function alegra_wc_sync_activation_notice()
  {
    echo '<div class="error"><p>' . __('Active WooCommerce para utilizar el complemento Alegra WC Sync.', 'alegra-wc-sync') . '</p></div>';
  }
  add_action('admin_notices', 'alegra_wc_sync_activation_notice');
}
