<?php

$document_types = ['CED' => 'Cédula', 'RNC' => 'RNC', 'IE' => 'Pasaporte'];

$order_types = [
    'INVOICE_B01' => 'Factura de Crédito Fiscal',
    'INVOICE_B02' => 'Factura de Consumo',
    'INVOICE_B14' => 'Regímenes Especiales',
    'INVOICE_B15' => 'Factura Gubernamental',
    'INVOICE_B16' => 'Comprobante para Exportaciones',
]


?>

<div id="alegra_modal" style="display:none;" title="Alegra Modal Details">
    <h2>Enter Alegra Order Data</h2>
    <table class="form-table">
        <tr>
            <th scope="row">
                <label for="wc_alegra_order_comprobante_fiscal">Orden Con Valor Fiscal?</label>
            </th>
            <td>
                <input id="wc_alegra_order_comprobante_fiscal" type="checkbox" name="wc_alegra_order_comprobante_fiscal" value="1" <?php
                                                                                                     echo ($wc_alegra_order_comprobante_fiscal == '1' ? 'checked' : ''); ?> />
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="alegra_modal_document_type">Tipo de Documento Fiscal</label>
            </th>
            <td>
                <select id="alegra_modal_document_type" class="small-text" <?php if (!empty($wc_alegra_order_invoice_id)) echo ('disabled') ?>>
                    <?php foreach ($document_types as $id => $label) : ?>
                        <?php $selected = $wc_alegra_order_doctype == $id ? "selected" : ''; ?>
                        <option value="<?php echo esc_attr($id); ?>" <?php echo esc_attr($selected); ?>><?php echo esc_html($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="alegra_modal_order_document_id">Documento Fiscal</label>
            </th>
            <td>
                <input type="text" id="alegra_modal_order_document_id" name='alegra_modal_order_document_id' value="<?php echo esc_attr($wc_alegra_order_document_id); ?>" <?php if (!empty($wc_alegra_order_invoice_id)) echo ('disabled') ?>>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="alegra_modal_order_type">Tipo de Comprobante</label>
            </th>
            <td>
                <select id="alegra_modal_order_type" class="small-text" <?php if (!empty($wc_alegra_order_invoice_id)) echo ('disabled') ?>>
                    <?php foreach ($order_types as $id => $label) : ?>
                        <?php $selected = $wc_alegra_order_type == $id ? "selected" : ''; ?>
                        <option value="<?php echo esc_attr($id); ?>" <?php echo esc_attr($selected); ?>><?php echo esc_html($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
    </table>
    <?php
    if (!empty($wc_alegra_order_invoice_id)) {
    ?>
        <p>Esta factura ya fue creada en Alegra y sus datos fiscales no pueden modificarse. Por favor edite los <a target="_blank" href="https://app.alegra.com/invoice/view/id/<?php echo $wc_alegra_order_invoice_id ?>">datos de la factura</a> o los <a target="_blank" href="https://app.alegra.com/client/view/id/<?php echo $alegra_order_alegra_contact_id ?>">datos del cliente</a> directamente en Alegra.</p><?php } else {                                                                                                                                             ?>
        <br />
        <button id="alegra_modal_save_button" class="button button-primary" style="margin-right:10px" data-order-id="<?php echo esc_attr($order_id); ?>">Save</button>

    <?php

                                                                                                                                                                                                                                                                                                                                                                                                            }

    ?>


    <button id="alegra_modal_close_button" class="button">Close</button>
</div>