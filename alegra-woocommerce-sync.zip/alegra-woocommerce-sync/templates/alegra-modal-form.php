<?php

$document_types = ['CED' => 'Cédula', 'RNC' => 'RNC', 'IE' => 'Pasaporte'];

$order_types = [
    'INVOICE_B01' => 'Factura de Crédito Fiscal',
    'INVOICE_B02' => 'Factura de Consumo',
    'INVOICE_B14' => 'Regímenes Especiales',
    'INVOICE_B15' => 'Factura Gubernamental',
    'INVOICE_B16' => 'Comprobante para Exportaciones',
]


?>

<div id="alegra_modal" style="display:none;" title="this is a test">
    <h2>Enter Alegra Order Data</h2>
    <table class="form-table">
        <tr>
            <th scope="row">
                <label for="alegra_modal_document_type">Tipo de Documento Fiscal</label>
            </th>
            <td>
                <select id="alegra_modal_document_type" class="small-text" >
                    <?php foreach ($document_types as $id => $label) : ?>
                        <?php $selected = $alegra_order_document_type == $id ? "selected" : ''; ?>
                        <option value="<?php echo esc_attr($id); ?>" <?php echo esc_attr($selected); ?>><?php echo esc_html($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="alegra_modal_order_document_id">Documento Fiscal</label>
            </th>
            <td>
                <input type="text" id="alegra_modal_order_document_id" name='alegra_modal_order_document_id' value="<?php echo esc_attr($alegra_order_document_id); ?>" >
            </td>
        </tr>
        <tr>
            <th scope="row">
                <label for="alegra_modal_order_type">Tipo de Comprobante</label>
            </th>
            <td>
                <select id="alegra_modal_order_type" class="small-text" >
                    <?php foreach ($order_types as $id => $label) : ?>
                        <?php $selected = $alegra_order_type == $id ? "selected" : ''; ?>
                        <option value="<?php echo esc_attr($id); ?>" <?php echo esc_attr($selected); ?>><?php echo esc_html($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
    </table>
    <?php
    if (!empty($alegra_invoice_id)) {
        ?>
             <p>Esta factura ya fue creada en Alegra y no puede modificarse. Por favor edite los datos en <a target="_blank" href="https://app.alegra.com/invoice/view/id/<?php echo $alegra_invoice_id ?>">Alegra</a>.</p><?php
        } else {

            ?>
            <br/>
            <button id="alegra_modal_save_button" class="button button-primary" data-order-id="'<?php echo esc_attr($post->ID); ?>">Save</button>

            <?php
        } 
        ?>
       
    
    <button id="alegra_modal_close_button" class="button">Close</button>
</div>